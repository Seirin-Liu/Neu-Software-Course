import java.io.*;
import java.nio.ByteBuffer;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.HashMap;
import java.util.Map;

public class Main2 {
    private static int size = 1024 * 1024 * 100;
    /**
     * 合并CSV
     * @param fileName
     * @param fileNameOut
     */
    public void  doCsv(String fileName,String fileNameOut){
        long startTime = System.currentTimeMillis();
        //建立Map存放对应的账户和金额
        Map<String, String> tMap = new HashMap();
        //使用RandomAccessFile
        RandomAccessFile file = null;
        try {
            file = new RandomAccessFile(new File(fileName), "rw");
            FileChannel fileChannelIn = file.getChannel();
            long readSize = 0;

            FileChannel fileChannelOut = FileChannel.open(Paths.get(fileNameOut), StandardOpenOption.READ,
                    StandardOpenOption.WRITE, StandardOpenOption.CREATE);
            //循环遍历整个文件
            while (readSize < fileChannelIn.size()) {
                int mSize = size;
                //裁剪
                if (readSize + size > fileChannelIn.size()) {
                    mSize = (int) (fileChannelIn.size() - readSize);
                }
                MappedByteBuffer buffer = fileChannelIn.map(FileChannel.MapMode.READ_WRITE, readSize, mSize);
                //使用StringBuffer,速度更快
                StringBuffer key = new StringBuffer();
                StringBuffer value = new StringBuffer();
                boolean findKey = true;
                while (buffer.hasRemaining()) {
                    byte snyc = buffer.get();
                    //如果是分隔符,需要进行操作
                    if (snyc == ',') {
                        findKey = false;
                    } else if (snyc == '\n') {
                        if (key.length() > 0 && value.length() > 0) {
                            //如果已经有该key 合并
                            if (tMap.containsKey(key)) {
                                double number = Double.parseDouble(tMap.get(key)) + Double.parseDouble(value.toString());
                                tMap.put(key.toString(), String.format("%d", number));
                            } else
                            //如果没有,新加
                            {
                                tMap.put(key.toString(), value.toString());
                            }
                        }
                        //操作完成后释放空间
                        key.setLength(0);
                        value.setLength(0);
                        findKey = true;
                    } else {
                        //不是分隔符,需要连接字符串
                        if (findKey) {
                            key.append(Character.toString(snyc)) ;
                        } else {
                            value.append(Character.toString(snyc));
                        }
                    }
                }
                buffer.flip();
                buffer.force();
                buffer.clear();
                readSize += mSize;
                ByteBuffer bufferOut = ByteBuffer.allocate(size);
                String eol = System.getProperty("line.separator");
                //写入新文件
                for (Map.Entry<String, String> entry : tMap.entrySet()) {
                    String line = entry.getKey() + "," + entry.getValue() + eol;
                    bufferOut.put(line.getBytes(StandardCharsets.UTF_8));
                }
                bufferOut.flip();
                fileChannelOut.write(bufferOut);
                bufferOut.clear();
                tMap.clear();
            }
            fileChannelOut.close();
            fileChannelIn.close();
            long endTime = System.currentTimeMillis();
            System.out.printf("合并完成,用时%ds", (endTime - startTime)/1000);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) throws InterruptedException {

    }
}
