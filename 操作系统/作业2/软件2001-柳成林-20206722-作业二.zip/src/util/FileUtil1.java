package util;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.channels.OverlappingFileLockException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.concurrent.atomic.AtomicBoolean;

public class FileUtil1 {

    private static AtomicBoolean realTime = new AtomicBoolean(false);

    /**
     * 文件更新实时
     * @param filename
     * @param updateMoney
     * @throws IOException
     */
    public  static boolean updateRealTime(String filename, long updateMoney) throws IOException  {
        long money = 0;
        FileLock lock = null; //初始状态lock为空
        FileChannel fileChannel = FileChannel.open(Paths.get(".\\data\\" + filename + ".txt"), StandardOpenOption.READ,
                StandardOpenOption.WRITE, StandardOpenOption.CREATE);
        if (lock == null) {
            try {
                lock = fileChannel.tryLock();
            }
            catch (OverlappingFileLockException e){ //如果当前文件被占，报异常
                fileChannel.close();
                System.out.println("实时操作失败，文件被占用");
                return false;
            }
        }
        if (lock != null) { //lock不为空，说明当前文件没有被占，可以正常写入
            realTime.set(true);
            System.out.println("实时操作开始，原子量："+realTime.get());
            //延迟时间 3秒
            long start = System.currentTimeMillis();
            while (System.currentTimeMillis()-start<=(3000)){}

            ByteBuffer byteBuffer = ByteBuffer.allocate(1024);
            fileChannel.read(byteBuffer);
            byteBuffer.flip();
            String moneyStr = StandardCharsets.UTF_8.decode(byteBuffer).toString();
            if (moneyStr.length() > 0) {
                //读出money
                money = Long.parseLong(moneyStr);
            }
            money = money + updateMoney;
            //写入
            moneyStr = String.valueOf(money);
            byteBuffer = ByteBuffer.allocate(1024);
            byteBuffer.put(moneyStr.getBytes(StandardCharsets.UTF_8));
            byteBuffer.flip();
            fileChannel.truncate(0);
            fileChannel.write(byteBuffer);

            byteBuffer.clear();
            lock.close();
            realTime.set(false);
            System.out.println("实时操作结束，原子量："+realTime.get());
            fileChannel.close();
            return true;

        }
        else{
            fileChannel.close();
            System.out.println("实时操作失败，文件被占用");
            return false;
        }


    }

    /**
     * 批处理文件更新
     * @param filename
     * @param updateMoney
     * @return
     * @throws IOException
     */
    public  static boolean upDateOrWait(String filename, long updateMoney) throws IOException {
        long money = 0;
        if (updateMoney == 0) {
            return false;
        }
        boolean flag = realTime.get();//如果实时操作进行中，暂停批量操作
        System.out.println("批处理操作开始，原子量："+flag);
        if (flag) {
            System.out.println("    发生实时操作，暂停批处理");
            return true;
        }
        boolean isWait = false;
        FileLock lock = null;
        FileChannel fileChannel = FileChannel.open(Paths.get(".\\data\\" + filename + ".txt"), StandardOpenOption.READ,
                StandardOpenOption.WRITE, StandardOpenOption.CREATE);
        if (lock == null) {
            try {
                lock = fileChannel.tryLock();
            }
            catch (OverlappingFileLockException e){ //如果当前文件被占，报异常
                fileChannel.close();
                System.out.println("批处理操作失败，文件被占用");
                return false;
            }
        }
        if (lock != null) { //lock不为空，说明当前文件没有被占，可以正常写入
            //延迟时间 3秒
            long start = System.currentTimeMillis();
            while (System.currentTimeMillis()-start<=(3000)){}

            ByteBuffer byteBuffer = ByteBuffer.allocate(1024);
            fileChannel.read(byteBuffer);
            byteBuffer.flip();
            String moneyStr = StandardCharsets.UTF_8.decode(byteBuffer).toString();
            if (moneyStr.length() > 0) {
                //读出money
                money = Long.parseLong(moneyStr);
            }
            money = money + updateMoney;
            byteBuffer = ByteBuffer.allocate(1024);
            moneyStr = String.valueOf(money);
            byteBuffer.put(moneyStr.getBytes(StandardCharsets.UTF_8));
            byteBuffer.flip();
            fileChannel.truncate(0);
            fileChannel.write(byteBuffer);
            byteBuffer.clear();
            lock.close();
            System.out.println("批处理操作结束");
        } else {
            isWait = true;
        }
        fileChannel.close();
        return isWait;
    }


    /**
     * 批处理发利息
     * @param countname
     * @param rate
     * @return
     * @throws IOException
     */
    public  static boolean upDateRateOrWait(String countname, double rate) throws IOException {
        long money = 0;
        if (rate == 0) {
            return false;
        }
        //如果实时操作进行中，暂定批量操作
        boolean flag = realTime.get();
        System.out.println("批处理操作开始，原子量："+flag);
        if (flag) {
            System.out.println("发生实时操作，暂停批处理");
            return true;
        }
        boolean isWait = false;
        FileLock lock = null;
        FileChannel fileChannel = FileChannel.open(Paths.get(".\\data\\" + countname + ".txt"), StandardOpenOption.READ,
                StandardOpenOption.WRITE, StandardOpenOption.CREATE);
        if (lock == null) {
            try {
                lock = fileChannel.tryLock();
            }
            catch (OverlappingFileLockException e){ //如果当前文件被占，报异常
                fileChannel.close();
                System.out.println("批处理操作失败，文件被占用");
                return false;
            }
        }
        if (lock != null) {
            //延迟时间 3秒
            long start = System.currentTimeMillis();
            while (System.currentTimeMillis()-start<=(3000)){}

            ByteBuffer byteBuffer = ByteBuffer.allocate(1024);
            fileChannel.read(byteBuffer);
            byteBuffer.flip();
            String moneyStr = StandardCharsets.UTF_8.decode(byteBuffer).toString();
            if (moneyStr.length() > 0) {
                //读出money
                money = Long.parseLong(moneyStr);
            }
            money *= (1 + rate);
            byteBuffer = ByteBuffer.allocate(1024);
            moneyStr = String.valueOf(money);
            byteBuffer.put(moneyStr.getBytes(StandardCharsets.UTF_8));
            byteBuffer.flip();
            fileChannel.truncate(0);
            fileChannel.write(byteBuffer);
            byteBuffer.clear();
            lock.close();
            System.out.println("批处理操作结束");
        } else {
            isWait = true;
        }
        fileChannel.close();
        return isWait;
    }

    //文件读取
    public synchronized static long read(String countname) throws IOException {
        long money = 0;
        FileChannel fileChannel = FileChannel.open(Paths.get(".\\data\\" + countname + ".txt"), StandardOpenOption.READ,
                StandardOpenOption.WRITE, StandardOpenOption.CREATE);
        ByteBuffer byteBuffer = ByteBuffer.allocate(1024);
        fileChannel.read(byteBuffer);
        byteBuffer.flip();
        String moneyStr = StandardCharsets.UTF_8.decode(byteBuffer).toString();
        if (moneyStr.length() > 0) {
            money = Long.parseLong(moneyStr);
        }
        byteBuffer.clear();
        fileChannel.close();
        return money;
    }







}
