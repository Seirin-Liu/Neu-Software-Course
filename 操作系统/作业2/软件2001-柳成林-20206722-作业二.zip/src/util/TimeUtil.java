package util;

public class TimeUtil{

    public static String getTime(long startTime,long endTime){
        if(endTime-startTime<1000){
            return endTime - startTime + "ms";
        }
        else {
            return (endTime - startTime)/1000 + "s";
        }
    }
}
