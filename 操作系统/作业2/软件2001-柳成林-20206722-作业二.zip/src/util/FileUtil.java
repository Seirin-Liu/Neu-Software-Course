package util;

import java.io.IOException;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.channels.OverlappingFileLockException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.concurrent.atomic.AtomicBoolean;

public class FileUtil {

    private static String fileName = "account(1).csv";
    private static int BlockSize = 1024 * 1024 * 100;
    private static AtomicBoolean realTime = new AtomicBoolean(false);


    public interface OperationInterface {
        double operation(double a, double b);
    }

    /**
     * 实时大文件存取款操作
     * @param countName
     * @param money
     * @param op
     * @return
     * @throws IOException
     */
    public synchronized static double dealMoney(String countName, double money, OperationInterface op) throws IOException {
        if (money == 0) {
            return 0;
        }
        FileLock lock = null;
        FileChannel fileChannel = FileChannel.open(Paths.get(fileName), StandardOpenOption.READ,
                StandardOpenOption.WRITE);
        if (lock == null) {
            try {
                lock = fileChannel.tryLock();
            }
            catch (OverlappingFileLockException e){ //如果当前文件被占，报异常
                fileChannel.close();
                System.out.println("系统异常");
            }
        }
        double curMoney = 0;
        boolean getMoneySuccess = false;
        boolean isAccountExist = false;
        if (lock != null) {
            realTime.set(true);
            System.out.println("实时操作开始，原子量："+realTime.get());
            long readSize = 0;
            while (readSize < fileChannel.size()) {
                int mSize = BlockSize;
                if (readSize + BlockSize > fileChannel.size()) {
                    mSize = (int) (fileChannel.size() - readSize);
                }
                MappedByteBuffer buffer = fileChannel.map(FileChannel.MapMode.READ_WRITE, readSize, mSize);
                StringBuffer value = new StringBuffer();
                byte[] nameByte = countName.getBytes();
                int num = 0;
                int moneyCount = 0;
                boolean hasAccount = false;
                while (buffer.hasRemaining()) {
                    byte a = buffer.get();
                    if (a == ',' && num == 10) {
                        num = 0;
                        buffer.mark();
                        hasAccount = true;
                        isAccountExist = true;
                    } else if (a == nameByte[num]) {
                        num ++;
                    } else {
                        num = 0;
                    }
                    if (a == '\n') {
                        if (hasAccount) {
                            buffer.reset();
                            for (int j = 0;j < moneyCount - 1; j++) {
                                value.append(Character.toString(buffer.get()));
                            }
                            curMoney = op.operation(Double.parseDouble(value.toString()), money);
                            if (curMoney >= 0) {
                                buffer.reset();
                                String newMoney = String.format("%d", (int)curMoney);
                                buffer.put(newMoney.getBytes(StandardCharsets.UTF_8), 0, newMoney.length());
                                buffer.force();
                                getMoneySuccess = true;
                                break;
                            }
                            value.setLength(0);
                        }
                        hasAccount = false;
                        num = moneyCount = 0;
                    }
                    if (hasAccount) {
                        moneyCount ++;
                    }
                }
                buffer.clear();
                readSize += mSize;
                System.out.println("查询进度: " + 100*readSize/fileChannel.size() + "%");
                if (hasAccount && getMoneySuccess) {
                    System.out.println("查询结束,账户存在");
                    break;
                }
            }
            lock.close();
            realTime.set(false);
            System.out.println("实时操作结束，原子量："+realTime.get());
        }
        fileChannel.close();
        if (!isAccountExist) {
            return -2;
        }
        return curMoney>=0?curMoney:-1;
    }



    /**
     * 转账操作
     * @param countName1
     * @param countName2
     * @param money
     * @return
     * @throws IOException
     */
    public synchronized static int transferMoney(String countName1, String countName2, double money) throws IOException {
        if (money == 0 || countName1.equals(countName2)) {
            return -1;
        }
        FileLock lock = null;
        FileChannel fileChannel = FileChannel.open(Paths.get(fileName), StandardOpenOption.READ,
                StandardOpenOption.WRITE);
        if (lock == null) {
            lock = fileChannel.tryLock();
        }
        MappedByteBuffer buffer1 = null;
        MappedByteBuffer buffer2 = null;
        int offset1 = 0;
        int offset2 = 0;
        double money1 = 0;
        double money2 = 0;
        int error = 0;
        if (lock != null) {
            realTime.set(true);
            long readSize = 0;
            while (readSize < fileChannel.size()) {
                int mSize = BlockSize;
                if (readSize + BlockSize > fileChannel.size()) {
                    mSize = (int) (fileChannel.size() - readSize);
                }
                MappedByteBuffer buffer = fileChannel.map(FileChannel.MapMode.READ_WRITE, readSize, mSize);
//                StringBuffer key = new StringBuffer();
                StringBuffer value = new StringBuffer();
                byte[] nameByte1 = countName1.getBytes();
                byte[] nameByte2 = countName2.getBytes();
                boolean findKey = true;
                boolean hasAccount1 = false;
                boolean hasAccount2 = false;
                int num1 = 0;
                int num2 = 0;
                int moneyCount = 0;
                while (buffer.hasRemaining()) {
                    byte a = buffer.get();
                    if (a == ',' && num1 == 10) {
                        num1 = 0;
                        buffer.mark();
                        hasAccount1 = true;
                    } else if (a == nameByte1[num1]) {
                        num1 ++;
                    } else {
                        num1 = 0;
                    }
                    if (a == ',' && num2 == 10) {
                        num2 = 0;
                        buffer.mark();
                        hasAccount2 = true;
                    } else if (a == nameByte1[num2]) {
                        num2 ++;
                    } else {
                        num2 = 0;
                    }
                    if (a == '\n') {
                        if (hasAccount1 && buffer1 == null) {
                            buffer.reset();
                            for (int j = 0;j < moneyCount - 1; j++) {
                                value.append(Character.toString(buffer.get()));
                            }
                            money1 = Double.parseDouble(value.toString());
                            if (money1 >= money) {

                                offset1 = buffer.position();
                                buffer1 = buffer;
                            }
                        }
                        if (hasAccount2 && buffer2 == null) {
                            buffer.reset();
                            for (int j = 0;j < moneyCount - 1; j++) {
                                value.append(Character.toString(buffer.get()));
                            }
                            money2 = Double.parseDouble(value.toString());
                            buffer.reset();
                            offset2 = buffer.position();
                            buffer2 = buffer;
                        }
                        if (buffer1 != null && buffer2 != null) {
                            break;
                        }
                        hasAccount1 = false;
                        hasAccount2 = false;
                        num1 = num2 = moneyCount = 0;
                    }
                    if (hasAccount1 || hasAccount2) {
                        moneyCount ++;
                    }
                }
                buffer.clear();
                readSize += mSize;
                System.out.println("查询进度: " + 100*readSize/fileChannel.size() + "%");
                if (buffer1 != null && buffer2 != null) {
                    buffer1.position(offset1);
                    String newMoney = String.format("%d", (int)(money1 - money));
                    buffer1.put(newMoney.getBytes(StandardCharsets.UTF_8), 0, newMoney.length());
                    buffer1.force();
                    buffer1.clear();

                    buffer2.position(offset2);
                    newMoney = String.format("%d", (int)(money2 + money));
                    buffer2.put(newMoney.getBytes(StandardCharsets.UTF_8), 0, newMoney.length());
                    buffer2.force();
                    buffer2.clear();
                    break;
                }
            }
            if (buffer1 == null) {
                error = -2;
            } else if (buffer2 == null) {
                error = -3;
            }
            lock.close();
            realTime.set(false);
        }
        fileChannel.close();
        return error;
    }

    /**
     * 批处理大文件存取款操作
     * @param countName
     * @param money
     * @param op
     * @return
     * @throws IOException
     */
    public synchronized static boolean addMoneyforBatch(String countName, double money, OperationInterface op) throws IOException {
        if (money == 0) {
            return false;
        }
        //如果实时操作进行中，暂定批量操作
        boolean flag = realTime.get();
        System.out.println("批处理操作开始，原子量："+flag);
        if (flag) {
            System.out.println("发生实时操作，暂停批处理");
            return true;
        }
        boolean isWait = false;
        FileLock lock = null;
        FileChannel fileChannel = FileChannel.open(Paths.get(fileName), StandardOpenOption.READ,
                StandardOpenOption.WRITE);
        if (lock == null) {
            lock = fileChannel.tryLock();
        }
        double curMoney = 0;
        if (lock != null) {
            long readSize = 0;
            while (readSize < fileChannel.size()) {
                int mSize = BlockSize;
                if (readSize + BlockSize > fileChannel.size()) {
                    mSize = (int) (fileChannel.size() - readSize);
                }
                MappedByteBuffer buffer = fileChannel.map(FileChannel.MapMode.READ_WRITE, readSize, mSize);
                StringBuffer value = new StringBuffer();
                byte[] nameByte = countName.getBytes();
                int num = 0;
                int moneyCount = 0;
                boolean hasAccount = false;
                while (buffer.hasRemaining()) {
                    byte a = buffer.get();
                    if (a == ',' && num == 10) {
                        num = 0;
                        buffer.mark();
                        hasAccount = true;
                    } else if (a == nameByte[num]) {
                        num ++;
                    } else {
                        num = 0;
                    }
                    if (a == '\n') {
                        if (hasAccount) {
                            buffer.reset();
                            for (int j = 0;j < moneyCount - 1; j++) {
                                value.append(Character.toString(buffer.get()));
                            }
                            curMoney = op.operation(Double.parseDouble(value.toString()), money);
                            if (curMoney >= 0) {
                                buffer.reset();
                                String newMoney = String.format("%d", (int)curMoney);
                                buffer.put(newMoney.getBytes(StandardCharsets.UTF_8), 0, newMoney.length());
                                buffer.force();
                                break;
                            }
                            value.setLength(0);
                        }
                        hasAccount = false;
                        num = moneyCount = 0;
                    }
                    if (hasAccount) {
                        moneyCount ++;
                    }
                }
                buffer.clear();
                readSize += mSize;
                System.out.println("查询进度: " + 100*readSize/fileChannel.size() + "%");
                if (hasAccount) {
                    break;
                }
            }
            lock.close();
        } else {
            isWait = true;
        }
        fileChannel.close();
        System.out.println("批处理操作结束");
        return isWait;
    }
}
