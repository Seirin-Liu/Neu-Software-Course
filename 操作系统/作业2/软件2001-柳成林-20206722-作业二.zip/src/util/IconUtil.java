package util;

import javax.swing.*;
import java.awt.*;

public class IconUtil {


    public static ImageIcon getImageIcon(String path, int width, int height) {
        if (width == 0 || height == 0) {
            return new ImageIcon(path);
        }
        ImageIcon icon = new ImageIcon(path);
        icon.setImage(icon.getImage().getScaledInstance(width, height,
                Image.SCALE_DEFAULT));
        return icon;
    }


}
