package test;


import dao.UserDao;
import org.junit.jupiter.api.Test;
import util.FileUtil;

import java.io.IOException;

import static java.lang.Math.abs;

public class TransferTest {

    @Test
    void transfer1() throws IOException {
        Thread thread1 = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    new UserDao().transferMoney("1","2",3);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        thread1.start();

    }

    @Test
    void transfer2() throws IOException {
        Thread thread1 = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    new UserDao().transferMoney("2","1",3);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        thread1.start();
    }

    @Test
    void test() throws IOException {


    }


}
