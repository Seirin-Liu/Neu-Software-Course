package test;

import dao.UserDao;
import org.junit.jupiter.api.Test;
import util.FileUtil;

import java.io.IOException;

import static java.lang.Math.abs;

class AllTest {

    String countName = "test";
    @Test
    void updateMoney() {
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String nowMoney = new UserDao().addMoney(countName, 1000);
                    System.out.println("updateMoney" + nowMoney);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        });
        thread.start();
    }

    @Test
    void getMoney() {
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    long money = 400;
                    String nowMoney = new UserDao().drawMoney(countName, money);
                    System.out.println("getMoney" + nowMoney);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        });
        thread.start();
    }

    @Test
    void transferMoney() {
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    long money = 400;
                    String nowMoney = new UserDao().transferMoney(countName, "test2", money);
                    System.out.println("transferMoney" + nowMoney);

                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        });
        thread.start();
    }

    @Test
    void paySalary() {
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    long money = 1000;
                    String[] namelist = new String[1];
                    namelist[0] = countName;
                    boolean result = new UserDao().paySalary(namelist, money);
                    System.out.println("paySalary" + result);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });
        thread.start();
    }

    @Test
    void payRates() {
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String[] namelist = new String[1];
                    namelist[0] = countName;
                    boolean result = new UserDao().payRates(namelist, 0.1);
                    System.out.println("paySalary" + result);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });
        thread.start();
    }
}