package view;

import util.IconUtil;
import util.NiceColors;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.*;

public class MenuFrame extends JFrame implements ActionListener {

	JButton jb1, jb2, jb3, jb4, jb5;  //创建按钮
	JLabel jlb1,jlb2;   //标签


	final JList<String> mlist = new JList<String>();
	ArrayList<String> dataList = new ArrayList<String>();

	Font font = new Font("黑体", Font.PLAIN, 20);

	final  static int width = 1000;
	final  static int height = 700;

	public MenuFrame() {
		jb1 = new JButton("  存款");
		jb2 = new JButton("  取款");
		jb3 = new JButton("  转账");
		jb4 = new JButton(" 发工资");
		jb5 = new JButton(" 发利息");

		jlb1 = new JLabel("银行记账系统");
		jlb2 = new JLabel("20206722 柳成林");
		jlb1.setForeground(Color.white);
		jlb2.setForeground(Color.white);
//		jlb1.setFont(new java.awt.Font("Dialog", 1, 23)); //设置字体类型， 是否加粗，字号

		jb1.addActionListener(this);
		jb2.addActionListener(this);
		jb3.addActionListener(this);
		jb4.addActionListener(this);
		jb5.addActionListener(this);

		this.setTitle("银行记账系统");  //设置窗体标题
		this.setSize(width, height);        //设置窗体大小
		this.setLocationRelativeTo(null);//在屏幕中间显示(居中显示)
		this.setLayout(null);            //设置布局，不采用布局

		//设置标签的位置和大小
		jlb1.setBounds(40, 10, 400, 50);
		jlb2.setBounds(800, 10, 400, 50);
		//设置按钮的位置和大小
		jb1.setBounds(30, 100, 150, 60);
		jb2.setBounds(30, 170, 150, 60);
		jb3.setBounds(30, 240, 150, 60);
		jb4.setBounds(30, 310, 150, 60);
		jb5.setBounds(30, 380, 150, 60);


//		jb1.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.blue));
//		jb2.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.blue));
//		jb3.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.blue));
//		jb4.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.blue));
//		jb5.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.blue));
//
//		jb1.setForeground(Color.white);
//		jb2.setForeground(Color.white);
//		jb3.setForeground(Color.white);
//		jb4.setForeground(Color.white);
//		jb5.setForeground(Color.white);

		jlb1.setFont(font);
		jlb2.setFont(font);
		jb1.setFont(font);
		jb2.setFont(font);
		jb3.setFont(font);
		jb4.setFont(font);
		jb5.setFont(font);

		jb1.setIcon(IconUtil.getImageIcon(".\\image\\save.png",28,28));
		jb2.setIcon(IconUtil.getImageIcon(".\\image\\draw.png",28,28));
		jb3.setIcon(IconUtil.getImageIcon(".\\image\\transfer.png",28,28));
		jb4.setIcon(IconUtil.getImageIcon(".\\image\\salary.png",28,28));
		jb5.setIcon(IconUtil.getImageIcon(".\\image\\rates.png",28,28));

		jb1.setFocusPainted(false);
		jb2.setFocusPainted(false);
		jb3.setFocusPainted(false);
		jb4.setFocusPainted(false);
		jb5.setFocusPainted(false);

		this.add(jb1);
		this.add(jb2);
		this.add(jb3);
		this.add(jb4);
		this.add(jb5);
		this.add(jlb1);
		this.add(jlb2);

		JPanel head = new JPanel();
		head.setBounds(0,0,width,60);
		head.setBackground(NiceColors.BLUE);
		this.add(head);



		JPanel panel = new JPanel();
		panel.setLayout(null);
		mlist.setPreferredSize(new Dimension(250, 250));
		mlist.setFont(new Font("黑体", Font.PLAIN, 17));
		JScrollPane scrollPane = new JScrollPane(mlist);
		scrollPane.setBounds(0,0,700,250);
		panel.add(scrollPane);
		panel.setBounds(250, 100, 700, 250);
		this.add(panel);

		JLabel back = new JLabel(IconUtil.getImageIcon(".\\image\\add2.png",400,280));
		back.setBounds(500,370,400,280);
		this.add(back);

		JPanel left = new JPanel();
		left.setBounds(0,60,width,height);
		left.setBackground(NiceColors.WHITE_BLUE);
		this.add(left);

		this.setDefaultCloseOperation(EXIT_ON_CLOSE);  //设置可关闭
		this.setVisible(true);  //设置可见
		this.setResizable(false);    //设置不可拉伸大小
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand() == "  存款") {
			SaveMoneyFrame frame = new SaveMoneyFrame();
			frame.setDataList(dataList);
			frame.setMlist(mlist);
		} else if (e.getActionCommand() == "  取款") {
			DrawMoneyFrame frame = new DrawMoneyFrame();
			frame.setDataList(dataList);
			frame.setMlist(mlist);
		} else if (e.getActionCommand() == "  转账") {
			TransferFrame frame =  new TransferFrame();
			frame.setDataList(dataList);
			frame.setMlist(mlist);
		} else if (e.getActionCommand() == " 发工资") {
			SalaryFrame frame =  new SalaryFrame();
			frame.setDataList(dataList);
			frame.setMlist(mlist);
		} else if (e.getActionCommand() == " 发利息") {
			RatesFrame frame =  new RatesFrame();
			frame.setDataList(dataList);
			frame.setMlist(mlist);
		} else if (e.getActionCommand() == " 退出") {
			System.exit(0);
		}
	}
}
