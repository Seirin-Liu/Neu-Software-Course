package view;

import dao.UserDao;
import util.Check;
import util.NiceColors;
import util.TimeUtil;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.*;


public class SaveMoneyFrame extends JFrame implements ActionListener {
	JButton jb1, jb2;
	JLabel jlb1, jlb2, jlb3;
	JTextField jta1, jta2;

	Font font = new Font("黑体", Font.PLAIN, 17);


	JList<String> mlist = new JList<String>();
	ArrayList<String> dataList = new ArrayList<String>();

	public void setDataList(ArrayList<String> dataList) {
		this.dataList = dataList;
	}

	public JList<String> getMlist() {
		return mlist;
	}

	public ArrayList<String> getDataList() {
		return dataList;
	}

	public void setMlist(JList<String> mlist) {
		this.mlist = mlist;
	}

	public SaveMoneyFrame() {

		//头panel
		JPanel head = new JPanel();
		head.setBounds(0,0,600,30);
		head.setBackground(NiceColors.BLUE);
		head.setLayout(null);
		JLabel headl = new JLabel(" 存钱");
		headl.setForeground(Color.white);
		headl.setFont(font);
		headl.setBounds(0,7,200,20);
		head.add(headl);
		this.add(head);

		//主pane
		JPanel content  = new JPanel();
		content.setBounds(0,30,600,470);
		content.setBackground(NiceColors.GHOST_WHITE);
		content.setLayout(null);


		jb1 = new JButton("确定");
		jb2 = new JButton("重置");
		//设置按钮监听
		jb1.addActionListener(this);
		jb2.addActionListener(this);

		jlb1 = new JLabel("请输入存入用户ID：");  //添加标签
		jlb2 = new JLabel("请输入存入金额：");  //添加标签
		jlb3 = new JLabel("");

		//创建文本框
		jta1 = new JTextField();
		jta2 = new JTextField();

		//设置布局
		this.setTitle("存钱");
		this.setLayout(null);
		this.setSize(600, 500);

		//存入标签和文本框
		jlb1.setBounds(175, 20, 200, 20);
		jta1.setBounds(175, 50, 250, 40);


		jlb2.setBounds(175, 110, 200, 20);
		jta2.setBounds(175, 140, 250, 40);


		//确定和重置按钮
		jb1.setBounds(195, 200, 62, 40);
		jb2.setBounds(315, 200, 62, 40);

		jlb3.setBounds(175, 260, 200, 20);

		jlb1.setFont(font);
		jlb2.setFont(font);
		jlb3.setFont(font);
		jta1.setFont(font);
		jta2.setFont(font);
		jb1.setFont(font);
		jb2.setFont(font);


		content.add(jlb1);
		content.add(jlb2);
		content.add(jlb3);
		content.add(jta1);
		content.add(jta2);
		content.add(jb1);
		content.add(jb2);


		this.add(content);

		this.setLocationRelativeTo(null);//在屏幕中间显示(居中显示)
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);  //设置仅关闭当前窗口

		this.setVisible(true);  //设置可见
		this.setResizable(false);    //设置不可拉伸大小

	}

	//清空账号和密码框
	private void clear() {
		jta1.setText("");    //设置为空
		jta2.setText("");
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand() == "确定") {
			try {
				savemoney();   //将存入金额传入判断是否合法
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		} else if (e.getActionCommand() == "重置") {
			clear();
		}
	}

	private void savemoney() throws IOException {
		if (jta1.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "用户ID为空！", "消息提示", JOptionPane.WARNING_MESSAGE);
		} else if (jta2.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "金额为空！", "消息提示", JOptionPane.WARNING_MESSAGE);
		} else if (Check.checkmoney(jta2.getText())) {//验证金额是否合法
			jlb3.setText("存钱中..");

			long startTime = System.currentTimeMillis();
			String countname = jta1.getText();
			//切换子线程操作
			Thread thread = new Thread(new Runnable() {
				@Override
				public void run() {
					//将账户和金额传入， 进行存储
					String nowmoney = null;
					try {
						nowmoney = new UserDao().addMoney(countname, Long.parseLong(jta2.getText()));
					} catch (Exception e) {
						e.printStackTrace();
					}
					final String finalNowmoney = nowmoney;
					SwingUtilities.invokeLater(new Runnable() {
						@Override
						public void run() {
							if (finalNowmoney != null && !finalNowmoney.equals("负数")) {
								//判断是查找用户失败还是执行成功
								if(finalNowmoney.equals("-2.0")) {
									jlb3.setText("");
									jta2.setText("");
									JOptionPane.showMessageDialog(null, "该用户不存在");
								}
								else {
									jlb3.setText("余额为:\n " + finalNowmoney);
									jta2.setText("");
									JOptionPane.showMessageDialog(null, "存钱成功！");
								}
							}
							DefaultListModel datos = new DefaultListModel();

							long endTime = System.currentTimeMillis();
							dataList.set(dataList.size()-1,dataList.get(dataList.size()-1) + " 已完成 " +new Date().toString() + "       用时：" + TimeUtil.getTime(startTime,endTime));
							for (int i = 0; i < dataList.size(); i++)
							{
								String str = dataList.get(i);
								datos.addElement(str);
							}
							mlist.setModel(datos);
						}
					});
				}
			});
			thread.start();
			dataList.add("存钱活动 "+thread.getName());
		} else {
			JOptionPane.showMessageDialog(null, "输入金额不正确!", "消息提示", JOptionPane.WARNING_MESSAGE);
		}
	}
}
