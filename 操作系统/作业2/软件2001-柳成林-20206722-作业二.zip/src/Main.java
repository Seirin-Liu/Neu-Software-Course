

import org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper;
import view.MenuFrame;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;

public class Main {
	public static void main(String[] args) throws IOException {
		BeautyEyeLNFHelper.frameBorderStyle = BeautyEyeLNFHelper.FrameBorderStyle.osLookAndFeelDecorated;
		try {
			BeautyEyeLNFHelper.launchBeautyEyeLNF();

			Font frameTitleFont = (Font) UIManager.get("InternalFrame.titleFont");
			frameTitleFont = frameTitleFont.deriveFont(Font.PLAIN);
			UIManager.put("InternalFrame.titleFont", frameTitleFont);
		} catch (Exception e) {
			e.printStackTrace();
		}
		new MenuFrame();
	}

}
