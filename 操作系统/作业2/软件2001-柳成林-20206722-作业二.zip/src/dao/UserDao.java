package dao;

import util.FileUtil;

import java.io.*;


public class UserDao {


	/**
	 * 存钱
	 * @param countName
	 * @param sMonney
	 * @return
	 * @throws IOException
	 */
	public String addMoney(String countName, long sMonney) throws IOException {
		double money = FileUtil.dealMoney(countName, sMonney, (a, b)->a + b);
		return String.valueOf(money);
	}

	/**
	 * 取钱
	 * @param countName
	 * @param gMonney
	 * @return
	 * @throws IOException
	 */
	public String drawMoney(String countName, long gMonney) throws IOException {
		double money = FileUtil.dealMoney(countName, gMonney, (a, b)->a - b);
		return String.valueOf(money);
	}


	/**
	 * 转账
	 * @param countName1
	 * @param countName2
	 * @param gMonney
	 * @return
	 * @throws IOException
	 */
	public String transferMoney(String countName1, String countName2, long gMonney) throws IOException {
		int result = FileUtil.transferMoney(countName1, countName2, gMonney);
		if (result == -1) {
			return "账户相同或转账金额不能为0";
		} else if (result == -2) {
			return "账户1用户不存在";
		} else if (result == -3) {
			return "账户2用户不存在";
		}
		return  String.format("已转账金额:%d", gMonney);
	}

	/**
	 * 发工资
	 * @param nameList
	 * @param sMonney
	 * @return
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public Boolean paySalary(String[] nameList, long sMonney) throws IOException, InterruptedException {
		int i = 0;
		while (i < nameList.length) {
			String countName = nameList[i];
			boolean result = FileUtil.addMoneyforBatch(countName, sMonney, (a, b)->a + b);
			if (result) {
				Thread.sleep(500);//如果文件被实时操作占用，等待0.5秒
			} else {
				i++;
			}
		}
		return true;
	}

	/**
	 * 发利息
	 * @param nameList
	 * @param rate
	 * @return
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public Boolean payRates(String[] nameList, double rate) throws IOException, InterruptedException {
		int i = 0;
		while (i < nameList.length) {
			String countName = nameList[i];
			boolean result = FileUtil.addMoneyforBatch(countName, rate, (a, b)->a * (1 + b));
			if (result) {
				Thread.sleep(500);//如果文件被实时操作占用，等待0.5秒
			} else {
				i++;
			}
		}
		return true;
	}
}
