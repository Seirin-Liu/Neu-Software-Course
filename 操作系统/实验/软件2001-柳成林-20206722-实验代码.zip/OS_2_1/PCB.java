package OS_2_1;

class PCB {
    public String pcbName;   //������
    public PCB next;         //ָ��
    public int time;         //Ҫ������ʱ��
    public int priority;     //������
    public char state = 'R'; //״̬

    public PCB(String pcbName, int time, int priority) {
        this.pcbName = pcbName;
        this.time = time;
        this.priority = priority;
    }



    @Override
    public String toString() {
        return "" + pcbName +  "        " + time + "        " + priority
                 + "        " + state;
    }


}

