package OS_3_4;

public class UFD_Item {

    private String fileName; //�ļ���
    private String address; //������ַ
    private int protectNumber; //������
    private double fileLength; //�ļ�����

    public UFD_Item(String fileName, String address, int protectNumber, double fileLength){
        this.fileName = fileName;
        this.address = address;
        this.protectNumber = protectNumber;
        this.fileLength = fileLength;
    }

    public String getFileName(){
        return fileName;
    }

    public String getAddress(){ return address; }

    public int getProtectNumber(){
        return protectNumber;
    }

    public double getFileLength(){
        return fileLength;
    }

    public void setFileName(String fileName){
        this.fileName = fileName;
    }

    public void setAddress(String address){
        this.address = address;
    }

    public void setProtectNumber(int protectNumber){
        this.protectNumber = protectNumber;
    }

    public void setFileLength(double fileLength){
        this.fileLength = fileLength;
    }


    @Override
    public String toString() {
        return "�ļ���:" + fileName + "\t������ַ:"+ address + "\t������:" + protectNumber + "\t�ļ�����:" + fileLength;
    }
}
