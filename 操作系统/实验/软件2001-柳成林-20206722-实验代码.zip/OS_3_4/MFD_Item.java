package OS_3_4;

import java.util.HashMap;

public class MFD_Item {

    private HashMap<String, UFD_Item> pairs = new HashMap<>();



    public void addPair(String name, UFD_Item pointer){
        pairs.put(name, pointer);
    }

    public boolean find(String name){
        return pairs.containsKey(name);
    }

    public UFD_Item get(String name){
        return pairs.get(name);
    }

    public void remove(String fileName) {
        pairs.remove(fileName);
    }

    public void show(){
        for(String i : pairs.keySet()) {
            System.out.println(pairs.get(i).toString());
        }
    }
}
