package OS_3_4;
import java.util.Scanner;
import java.util.TreeMap;

public class OS_3_4_Main {

    private static TreeMap<String, MFD_Item> mainDir = new TreeMap<>();

    public OS_3_4_Main() {
        Scanner sc = new Scanner(System.in);
        System.out.println("�������û�����");
        String str = sc.next();

        if (str.equals("admin")){
            System.out.println("���������룺");
            sc = new Scanner(System.in);
            String password = sc.next();
            if (password.equals("123456")){
                System.out.println("��ӭ��" + str);
                Menu test = new Menu(str, mainDir);
            }
            else{
                System.out.println("����������������룡");
                new OS_3_4_Main();
            }
        }
        else{
            System.out.println("�û��������ڣ����������룡");
            new OS_3_4_Main();
        }
    }

    public static void createDirectory(){
        UFD_Item aaa = new UFD_Item("123", "851dB520",111, 1);
        UFD_Item ccc = new UFD_Item("ccc", "851dB700",111, 150);
        UFD_Item bbb = new UFD_Item("bbb", "851dB590",111, 16);
        UFD_Item ddd = new UFD_Item("ddd", "851dB7e0",111, 17685);
        UFD_Item eee = new UFD_Item("eee", "851dB500",111, 645);

        MFD_Item admin = new MFD_Item();
        admin.addPair("123", aaa);
        admin.addPair("bbb",bbb);
        admin.addPair("ccc", ccc);
        admin.addPair("ddd", ddd);
        admin.addPair("eee", eee);

        mainDir.put("admin", admin);

    }

    public static void main(String[] args) {
        createDirectory();
        new OS_3_4_Main();
    }
}
