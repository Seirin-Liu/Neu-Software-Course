package OS_1;

public class Producer extends Thread{
	private Buffer buffer;

	public Producer(Buffer buffer){
		this.buffer = buffer;
	}
	
	//������Ʒ
	public void run() {	
		while(true) {
				buffer.add();
				try {
					Thread.sleep(500); //�ӳ�0.5��
				} catch (InterruptedException e) {
					e.printStackTrace();
				}				
			}
	}
}
