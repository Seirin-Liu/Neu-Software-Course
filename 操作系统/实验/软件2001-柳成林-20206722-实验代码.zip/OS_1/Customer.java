package OS_1;

public class Customer extends Thread{
	private Buffer buffer;

	public Customer(Buffer t) {
		this.buffer = t;
	}

	// ������������Ʒ
	public void run() {
		while (true) {
				buffer.delete();
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
	}
}
