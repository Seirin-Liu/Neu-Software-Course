#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>

#define block_size 128

typedef struct
{
    int pagenum; //ҳ��
    int flag; //��־
    int blocknum;//������
    int location;//����λ��
} table; //ҳ��

table p[7] =
{
    { 0, 1, 5, 11 },
    { 1, 1, 8, 12 },
    { 2, 1, 9, 13 },
    { 3, 1, 1, 21 },
    { 4, 0, 0, 22 },
    { 5, 0, 0, 23 },
    { 6, 0, 0, 121 }
};//��ʼ����ҵҳ��

int main(void)
{
    int page;
    int offset;
    int memaddress;
    printf("\n---Input (-1 -1) to exit---\n\n");

    while (1)
    {
        setbuf(stdin, NULL);
        printf("Please input page number and page address: ");
        scanf("%d %d", &page, &offset);
        if (page == -1 && offset == -1)
        {
            printf("\n");
            exit(1);
        }
        else if (page < 0 || page > 6 || offset < 0)
        {
            printf("Out of range! Please input again!\n\n");
        }
        else
        {

            if (p[page].flag != 0)   //��ҳ�Ѿ�װ������
            {
                memaddress = p[page].blocknum * block_size + offset;
                printf("page_address: %d\tabsolute_address: %d\n\n", offset, memaddress);
            }
            else
            {
                printf("*%d Page Fault\n\n", page);
            }

        }
    }

    return 0;
}
