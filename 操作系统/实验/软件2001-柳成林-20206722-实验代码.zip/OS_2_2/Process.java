package OS_2_2;

public class Process {
    private String processName; //名称
    private double arriveTime;  //到达时间
    private double serviceTime;  //服务时间，即总共需要运行的时间
    private double lastRunTime;  //剩下的运行时间
    private double overTime;    //完成时间
    private double turnaroundTime;  //周转时间
    private double turnaroundWeightTime; //带权周转时间

    public Process(String processName, double arriveTime, double serviceTime,double lastRunTime) {
        this.processName = processName;
        this.arriveTime = arriveTime;
        this.serviceTime = serviceTime;
        this.lastRunTime = lastRunTime;
    }

    public void setProcessName(String processName) {
        this.processName = processName;
    }

    public String getProcessName() {
        return processName;
    }

    public double getArriveTime() {
        return arriveTime;
    }

    public double getServiceTime() {
        return serviceTime;
    }


    public double getTurnaroundWeightTime() {
        return turnaroundWeightTime;
    }

    public void setTurnaroundWeightTime(double turnaroundWeightTime) {
        this.turnaroundWeightTime = turnaroundWeightTime;
    }

    public double getLastRunTime() {
        return lastRunTime;
    }

    public void setLastRunTime(double lastRunTime) {
        this.lastRunTime = lastRunTime;
    }

    public double getOverTime() {
        return overTime;
    }

    public void setOverTime(double overTime) {
        this.overTime = overTime;
    }

    public double getTurnaroundTime() {
        return turnaroundTime;
    }

    public void setTurnaroundTime(double turnaroundTime) {
        this.turnaroundTime = turnaroundTime;
    }
}

