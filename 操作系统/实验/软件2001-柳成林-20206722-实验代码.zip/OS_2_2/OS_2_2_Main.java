package OS_2_2;

import java.util.Queue;
import java.util.Scanner;
import java.util.concurrent.LinkedBlockingQueue;

public class OS_2_2_Main {
    public static void main(String[] args) throws InterruptedException {
        System.out.println("����ʱ��Ƭ���ȣ�");
        Scanner scanner = new Scanner(System.in);
        int timeSlice = scanner.nextInt();
        Queue<Process> processQueue = RR.getProcess();
        RR rr = new RR(20,processQueue,timeSlice);
        System.err.println("*******************Process overview*****************");
        Thread.sleep(1000);
        RR.printAll(new LinkedBlockingQueue<>(processQueue));
        Thread.sleep(1000);

        System.err.println("********************Running*******************");
        Thread.sleep(1000);
        rr.RRAlgorithm();
        Thread.sleep(1000);

        System.err.println("*******************Running Result*****************");
        Thread.sleep(1000);
        rr.showResult();

    }
}
