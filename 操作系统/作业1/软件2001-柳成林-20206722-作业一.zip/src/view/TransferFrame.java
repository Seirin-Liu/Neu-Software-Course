package view;

import dao.UserDao;
import util.Check;
import util.NiceColors;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.*;


public class TransferFrame extends JFrame implements ActionListener {
	JButton jb1, jb2;  //按钮
	JLabel jlb1, jlb2, jlb3, jlb4; //标签
	JTextField jta1, jta2, jta3;    //文本框

	Font font = new Font("黑体", Font.PLAIN, 17);

	JList<String> mlist = new JList<String>();
	ArrayList<String> dataList = new ArrayList<String>();

	public void setDataList(ArrayList<String> dataList) {
		this.dataList = dataList;
	}

	public JList<String> getMlist() {
		return mlist;
	}

	public ArrayList<String> getDataList() {
		return dataList;
	}

	public void setMlist(JList<String> mlist) {
		this.mlist = mlist;
	}
	public TransferFrame() {

		//头panel
		JPanel head = new JPanel();
		head.setBounds(0,0,600,30);
		head.setBackground(NiceColors.BLUE);
		head.setLayout(null);
		JLabel headl = new JLabel(" 转账");
		headl.setForeground(Color.white);
		headl.setFont(font);
		headl.setBounds(0,7,200,20);
		head.add(headl);
		this.add(head);

		//主pane
		JPanel content  = new JPanel();
		content.setBounds(0,30,600,470);
		content.setBackground(NiceColors.GHOST_WHITE);
		content.setLayout(null);

		jb1 = new JButton("确定");
		jb2 = new JButton("重置");
		//设置按钮监听
		jb1.addActionListener(this);
		jb2.addActionListener(this);

		jlb1 = new JLabel("请输入转出的用户ID：");  //添加标签
		jlb2 = new JLabel("请输入转入的用户ID：");  //添加标签
		jlb3 = new JLabel("请输入转账金额：");  //添加标签
		jlb4 = new JLabel("");

		//创建文本框
		jta1 = new JTextField();
		jta2 = new JTextField();
		jta3 = new JTextField();

		//设置布局
		this.setTitle("转账");
		this.setLayout(null);
		this.setSize(600, 500);

		//转出标签和文本框
		//存入标签和文本框
		jlb1.setBounds(175, 20, 200, 20);
		jta1.setBounds(175, 50, 250, 40);


		jlb2.setBounds(175, 110, 200, 20);
		jta2.setBounds(175, 140, 250, 40);


		jlb3.setBounds(175, 200, 200, 20);
		jta3.setBounds(175, 230, 250, 40);



		//确定和重置按钮
		jb1.setBounds(195, 290, 62, 40);
		jb2.setBounds(315, 290, 62, 40);

		jlb4.setBounds(175, 350, 200, 20);

		jlb1.setFont(font);
		jlb2.setFont(font);
		jlb3.setFont(font);
		jta1.setFont(font);
		jta2.setFont(font);
		jlb4.setFont(font);
		jta3.setFont(font);
		jb1.setFont(font);
		jb2.setFont(font);

		content.add(jlb1);
		content.add(jlb2);
		content.add(jlb3);
		content.add(jlb4);
		content.add(jta1);
		content.add(jta2);
		content.add(jta3);
		content.add(jb1);
		content.add(jb2);

		this.add(content);

		this.setLocationRelativeTo(null);//在屏幕中间显示(居中显示)
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);  //设置仅关闭当前窗口

		this.setVisible(true);  //设置可见
		this.setResizable(false);    //设置不可拉伸大小

	}

	//清空账号和密码框
	private void clear() {
		jta1.setText("");
		jta2.setText("");    //设置为空
		jta3.setText("");
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand() == "确定") {
			try {
				transfer();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		} else if (e.getActionCommand() == "重置") {
			clear();
		}
	}

	private void transfer() throws IOException {
		if (jta1.getText().isEmpty() || jta2.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "转入或转出账号为空！", "消息提示", JOptionPane.WARNING_MESSAGE);
		} else if (jta3.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "金额为空！", "消息提示", JOptionPane.WARNING_MESSAGE);
		} else if (Check.checkmoney(jta3.getText())) { //验证金额是否合法
			jlb4.setText("转账中..");
			String countname1 = jta1.getText();
			String countname2 = jta2.getText();
			Thread thread = new Thread(new Runnable() {
				@Override
				public void run() {
					//将账户和金额传入， 进行存储
					String nowmoney = null;
					try {
						nowmoney = new UserDao().transferMoney(countname1, countname2, Long.parseLong(jta3.getText()));
					} catch (Exception e) {
						e.printStackTrace();
					}
					final String finalNowmoney = nowmoney;
					SwingUtilities.invokeLater(new Runnable() {
						@Override
						public void run() {
							if (!finalNowmoney.equals("-1")) {
								jlb4.setText(countname2 + "的余额为: " + finalNowmoney);
								jta3.setText("");
							} else {
								JOptionPane.showMessageDialog(null, "余额不足", "消息提示", JOptionPane.WARNING_MESSAGE);
								jta3.setText("");
							}
							DefaultListModel datos = new DefaultListModel();
							for (int i = 0; i < dataList.size(); i++)
							{
								String str = dataList.get(i) + " 已完成 " +new Date().toString();
								datos.addElement(str);
							}
							mlist.setModel(datos);
						}
					});
				}
			});
			thread.start();
			dataList.add("转账活动 "+thread.getName());
		} else {
			JOptionPane.showMessageDialog(null, "输入金额不正确!", "消息提示", JOptionPane.WARNING_MESSAGE);
			clear();
		}
	}
}
