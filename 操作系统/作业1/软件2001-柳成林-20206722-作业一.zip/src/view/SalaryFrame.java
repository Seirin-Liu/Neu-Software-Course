package view;

import dao.UserDao;
import util.Check;
import util.NiceColors;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Date;

public class SalaryFrame extends JFrame implements ActionListener {
    JButton jb1, jb2;  //按钮
    JLabel jlb1, jlb2, jlb3, jlb4; //标签
    JTextArea jta1, jta2, jta3;    //文本框

    Font font = new Font("黑体", Font.PLAIN, 17);

    JList<String> mlist = new JList<String>();
    ArrayList<String> dataList = new ArrayList<String>();

    public void setDataList(ArrayList<String> dataList) {
        this.dataList = dataList;
    }

    public JList<String> getMlist() {
        return mlist;
    }

    public ArrayList<String> getDataList() {
        return dataList;
    }

    public void setMlist(JList<String> mlist) {
        this.mlist = mlist;
    }
    public SalaryFrame() {

        //头panel
        JPanel head = new JPanel();
        head.setBounds(0,0,600,30);
        head.setBackground(NiceColors.BLUE);
        head.setLayout(null);
        JLabel headl = new JLabel(" 发工资");
        headl.setForeground(Color.white);
        headl.setFont(font);
        headl.setBounds(0,7,200,20);
        head.add(headl);
        this.add(head);

        //主pane
        JPanel content  = new JPanel();
        content.setBounds(0,30,600,470);
        content.setBackground(NiceColors.GHOST_WHITE);
        content.setLayout(null);

        jb1 = new JButton("确定");
        jb2 = new JButton("重置");
        //设置按钮监听
        jb1.addActionListener(this);
        jb2.addActionListener(this);

        jlb1 = new JLabel("请输入多个用户ID");  //添加标签
        jlb2 = new JLabel("请输入工资金额：");  //添加标签
        jlb3 = new JLabel("");

        //创建文本框
        jta1 = new JTextArea();
        jta2 = new JTextArea();

        //设置布局
        this.setTitle("发工资");
        this.setLayout(null);
        this.setSize(600, 500);

        //存入标签和文本框
        jlb1.setBounds(175, 20, 200, 20);
        jta1.setBounds(175, 50, 250, 40);


        jlb2.setBounds(175, 110, 200, 20);
        jta2.setBounds(175, 140, 250, 40);


        //确定和重置按钮
        jb1.setBounds(195, 200, 62, 40);
        jb2.setBounds(315, 200, 62, 40);

        jlb3.setBounds(175, 260, 200, 20);

        jlb1.setFont(font);
        jlb2.setFont(font);
        jlb3.setFont(font);
        jta1.setFont(font);
        jta2.setFont(font);
        jb1.setFont(font);
        jb2.setFont(font);


        content.add(jlb1);
        content.add(jlb2);
        content.add(jlb3);
        content.add(jta1);
        content.add(jta2);
        content.add(jb1);
        content.add(jb2);


        this.add(content);


        this.setLocationRelativeTo(null);//在屏幕中间显示(居中显示)
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);  //设置仅关闭当前窗口

        this.setVisible(true);  //设置可见
        this.setResizable(false);    //设置不可拉伸大小
    }

    private void clear() {
        jta1.setText("");
        jta2.setText("");    //设置为空
        jta3.setText("");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand() == "确定") {
            salary();
        } else if (e.getActionCommand() == "重置") {
            clear();
        }
    }

    private void salary() {
        if (jta1.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "用户ID为空！", "消息提示", JOptionPane.WARNING_MESSAGE);
        } else if (jta2.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "金额为空！", "消息提示", JOptionPane.WARNING_MESSAGE);
        } else if (Check.checkmoney(jta2.getText())) {
            jlb3.setText("发工资中..");
            String[] nameList = jta1.getText().split(" ");
            Thread thread = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        //将账户和金额传入， 发工资
                        boolean result = new UserDao().paySalary(nameList, Long.parseLong(jta2.getText()));
                        SwingUtilities.invokeLater(new Runnable() {
                            @Override
                            public void run() {
                                if (result) {
                                    jlb3.setText("发工资完成");
                                    jta2.setText("");
                                }
                                DefaultListModel datos = new DefaultListModel();
                                for (int i = 0; i < dataList.size(); i++)
                                {
                                    String str = dataList.get(i) + " 已完成 " +new Date().toString();
                                    datos.addElement(str);
                                }
                                mlist.setModel(datos);
                            }
                        });
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });
            thread.start();
            dataList.add("发工资活动 "+thread.getName());
        } else {
            JOptionPane.showMessageDialog(null, "输入金额不正确!", "消息提示", JOptionPane.WARNING_MESSAGE);
        }
    }
}
