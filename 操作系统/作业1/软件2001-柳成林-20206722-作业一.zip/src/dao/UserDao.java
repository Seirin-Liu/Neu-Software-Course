package dao;

import util.FileUtil;

import java.io.*;


public class UserDao {


	/**
	 * 存钱
	 * @param countName
	 * @param m 钱
	 * @return
	 * @throws IOException
	 */
	public String addMoney(String countName, long m) throws IOException, InterruptedException {
		int i =0;
		while (i==0) {
			boolean flag = FileUtil.updateRealTime(countName, m);
			if(flag){ //当前文件空闲
				i++;
			}
			else{ //当前文件被占
				Thread.sleep(3000); //如果文件被占用，等待3秒
			}
		}
		long money = FileUtil.read(countName);
		return String.valueOf(money);
	}

	/**
	 * 取钱
	 * @param countName
	 * @param m 钱
	 * @return
	 * @throws IOException
	 */
	public String drawMoney(String countName, long m) throws IOException, InterruptedException {
		int i =0;
		while (i==0) {
			boolean flag = FileUtil.updateRealTime(countName, -m);
			if(flag){ //当前文件空闲
				i++;
			}
			else{ //当前文件被占
				Thread.sleep(3000); //如果文件被占用，等待3秒
			}
		}
		long money = FileUtil.read(countName);
		return String.valueOf(money);
	}

	/**
	 * 转账
	 * @param countName1
	 * @param countName2
	 * @param m 钱
	 * @return
	 * @throws IOException
	 */
	public String transferMoney(String countName1, String countName2, long m) throws IOException {

		try {
			drawMoney(countName1,m);
			addMoney(countName2,m);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		long money = FileUtil.read(countName2);
		return String.valueOf(money);
	}

	/**
	 * 发工资
	 * @param nameList
	 * @param m
	 * @return
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public Boolean paySalary(String[] nameList, long m) throws IOException, InterruptedException {
		int i = 0;
		while (i < nameList.length) {
			String countName = nameList[i];
			boolean result = FileUtil.upDateOrWait(countName, m);
			if (result) {
				Thread.sleep(3000);//如果文件被实时操作占用，等待3秒
			} else {
				i++;
			}
		}
		return true;
	}

	/**
	 *
	 * @param nameList
	 * @param rate
	 * @return
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public Boolean payRates(String[] nameList, double rate) throws IOException, InterruptedException {
		int i = 0;
		while (i < nameList.length) {
			String countName = nameList[i];
			boolean result = FileUtil.upDateRateOrWait(countName, rate);
			if (result) {
				Thread.sleep(3000);//如果文件被实时操作占用，等待3秒
			} else {
				i++;
			}
		}
		return true;
	}
}
