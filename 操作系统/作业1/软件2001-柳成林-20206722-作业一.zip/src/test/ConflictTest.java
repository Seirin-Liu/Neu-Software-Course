package test;

import dao.UserDao;
import org.junit.jupiter.api.Test;
import util.FileUtil;

import java.io.IOException;

public class ConflictTest {

    @Test
    public void test() throws InterruptedException {
        Thread thread1 = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    new UserDao().drawMoney("1",1);
                } catch (IOException | InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
        Thread thread2 = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    new UserDao().paySalary(new String[] {"1","2"},1);
                } catch (IOException | InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
        thread1.start();
        Thread.sleep(1000);
        thread2.start();
    }
}
