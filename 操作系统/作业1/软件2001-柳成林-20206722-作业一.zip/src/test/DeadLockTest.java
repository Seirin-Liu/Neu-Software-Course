package test;

import dao.UserDao;
import org.junit.jupiter.api.Test;
import util.FileUtil;

import java.io.IOException;

public class DeadLockTest {
    @Test
    public void test(){
        Thread thread1 = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    new UserDao().drawMoney("1",1);
                } catch (IOException | InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
        Thread thread2 = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    new UserDao().drawMoney("1",1);
                } catch (IOException | InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
        thread1.start();
        thread2.start();
    }
}
