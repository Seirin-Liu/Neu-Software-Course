function y=f(x)
y=- 6.1*x^2 + 94.0*x - 45.0;
end