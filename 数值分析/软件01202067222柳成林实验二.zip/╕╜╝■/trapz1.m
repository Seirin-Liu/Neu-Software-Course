function[result] = trapz1(a,b,epsilon)
    %% 已知条件
    syms x 
    Fx(x) = - 6.1*x^2 + 94.0*x - 45.0;
    e = 1;
    T = []; % 存放Tf的值
    h = b-a;
    Xk1 = [a, b];  % 存放已选的 xk
    Xk2 = [];      % 存放将要使用的 x(k+1/2)
    sumfx = 0;     % sum( fx(k+1/2) )

    %% 计算
    digits(8)
    format long
    k = 0;
    Tf = vpa( b - a ) / 2 * ( Fx(a) + Fx(b) );
    T = [T, Tf];
    fprintf('k=%d, 2^k=%d, Tk=%0.8f\n',k,2^k,Tf) 

    while(e>epsilon)
        for i=1:length(Xk1)-1
            temp = ( Xk1(i) + Xk1(i+1) ) / 2;
            sumfx = sumfx + Fx(temp);
            Xk2 = [Xk2,temp];
        end
        Xk1 = [Xk1,Xk2];
        Xk1 = sort(Xk1);

        k = k + 1;
        Tf = vpa( 0.5 * ( Tf + h * sumfx ) );
        T = [T, Tf];
        e = abs(Tf - T(end-1))/3;
        fprintf('k=%d, 2^k=%d, Tk=%0.8f, e=%0.8f\n',k,2^k,Tf,e) 

        % 更新值
        h = h / 2;
        sumfx = 0;
        Xk2 = [];
    end

    result = Tf;
    fprintf('复化梯形求积公式的结果为：%0.8f\n',result)
end
