package entity;

import javafx.scene.control.Label;
import javafx.scene.paint.Color;

public class FiveChess {

	public static final int black = 1;
	public static final int white = 2;

	private double width; // ���̿�
	private double height; // ���̸�
	private double cellLen; // ���ӳ���
	private int currentSide = black;
	private int[][] chess;

	private Label currentSideLabel;

	public double getWidth() {
		return width;
	}

	public void setWidth(double width) {
		this.width = width;
	}

	public double getHeight() {
		return height;
	}

	public void setHeight(double height) {
		this.height = height;
	}

	public double getCellLen() {
		return cellLen;
	}

	public void setCellLen(double cellLen) {
		this.cellLen = cellLen;
	}

	public int[][] getChess() {
		return chess;
	}

	public void setChess(int[][] chess) {
		this.chess = chess;
	}

	public int getCurrentSide() {
		return currentSide;
	}

	public void setCurrentSide(int currentSide) {
		this.currentSide = currentSide;
	}

	public Label getCurrentSideLabel() {
		return currentSideLabel;
	}

	public void setCurrentSideLabel(Label currentSideLabel) {
		this.currentSideLabel = currentSideLabel;
		if (currentSide == black) {
			currentSideLabel.setTextFill(Color.BLACK);
			currentSideLabel.setText("��ǰ��" + "����");
		}
		if (currentSide == white) {
			currentSideLabel.setTextFill(Color.WHITE);
			currentSideLabel.setText("��ǰ��" + "����");
		}
	}

	public FiveChess() {
		this.width = 16;
		this.height = 16;
		this.cellLen = 30;
		chess = new int[16][16];
		for (int i = 0; i < 16; i++) {
			for (int j = 0; j < 16; j++)
				{chess[i][j] = 0;}}
	}

	/**
	 * @param currentSide
	 * @param chess
	 */
	public FiveChess(int currentSide, int[][] chess) {
		super();
		this.width = 16;
		this.height = 16;
		this.cellLen = 30;
		this.currentSide = currentSide;
		this.chess = chess;
	}

	public boolean play(int x, int y) {

		// ����ǰ�����ӷ��õ���x,y��
		if (x >= 0 && x <= 15 && y >= 0 && y <= 15) {
			if (chess[x][y] == 0) {
				chess[x][y] = currentSide;
				return true;
			}
		}
		return false;
	}

	/**
	 * �ı����巽
	 */
	public void changeSide() {
		// �������巽
		setCurrentSide(currentSide == black ? white : black);
		if (currentSide == black) {
			currentSideLabel.setTextFill(Color.BLACK);
			currentSideLabel.setText("��ǰ��" + "����");
		}
		if (currentSide == white) {
			currentSideLabel.setTextFill(Color.WHITE);
			currentSideLabel.setText("��ǰ��" + "����");
		}

	}

	/**
	 * ����ʱɾ�������е��壬�����ؾ���
	 * 
	 * @param move
	 * @return
	 */
	public void deletChess(Move move) {

		chess[move.getX()][move.getY()] = 0;
		changeSide();

	}

	public boolean judgeGame(int row, int col, int chessColor) {

		// �ж���Ϸ�Ƿ����
		if (rowJudge(row, col, chessColor) && colJudge(row, col, chessColor) && mainDiagonalJudge(row, col, chessColor)
				&& DeputyDiagonalJudge(row, col, chessColor))
			{return true;}
		return false;

	}

	public boolean rowJudge(int row, int col, int chessColor) {
		// �ж�һ���Ƿ���������
		int count = 0;
		if (row >= 0 && row <= 15 && col >= 0 && col <= 15) {
			for (int j = col; j < width; j++) {
				if (chess[row][j] != chessColor) {
					break;}
				count++;
			}
			for (int j = col - 1; j >= 0; j--) {
				{if (chess[row][j] != chessColor)
					break;}
				count++;
			}
			if (count >= 5)
				{return false;}
		}
		return true;
	}

	public boolean colJudge(int row, int col, int chessColor) {
		// �ж�һ���Ƿ���������
		int count = 0;
		if (row >= 0 && row <= 15 && col >= 0 && col <= 15) {
			for (int i = row; i < height; i++) {
				if (chess[i][col] != chessColor)
					{break;}
				count++;
			}
			for (int i = row - 1; i >= 0; i--) {
				if (chess[i][col] != chessColor)
					{break;}
				count++;
			}
			if (count >= 5)
				{return false;}
		}
		return true;
	}

	public boolean mainDiagonalJudge(int row, int col, int chessColor) {
		// �ж����Խ����Ƿ���������
		int count = 0;
		if (row >= 0 && row <= 15 && col >= 0 && col <= 15) {
			for (int i = row, j = col; i < height && j < width; i++, j++) {
				if (chess[i][j] != chessColor)
					{break;}
				count++;
			}

			for (int i = row - 1, j = col - 1; i >= 0 && j >= 0; i--, j--) {
				if (chess[i][j] != chessColor)
					{break;}
				count++;
			}

			if (count >= 5)
				{return false;}
		}
		return true;
	}

	public boolean DeputyDiagonalJudge(int row, int col, int chessColor) {
		// �жϸ��Խ����Ƿ���������
		int count = 0;
		if (row >= 0 && row <= 15 && col >= 0 && col <= 15) {
			for (int i = row, j = col; i >= 0 && j < width; i--, j++) {
				if (chess[i][j] != chessColor)
					{break;}
				count++;
			}
			for (int i = row + 1, j = col - 1; i < height && j >= 0; i++, j--) {
				if (chess[i][j] != chessColor)
					{break;}
				count++;
			}

			if (count >= 5)
				{return false;}
		}
		return true;
	}
}