package entity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Game {

	private boolean isComplete;

	private int winner;

	private int[][] chess;

	private String username;

	private String blackPlayer;

	private String whitePlayer;

	private ArrayList<Move> moves;

	private String time;

	public String getBlackPlayer() {
		return blackPlayer;
	}

	public void setBlackPlayer(String blackPlayer) {
		this.blackPlayer = blackPlayer;
	}

	public String getWhitePlayer() {
		return whitePlayer;
	}

	public void setWhitePlayer(String whitePlayer) {
		this.whitePlayer = whitePlayer;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public boolean isComplete() {
		return isComplete;
	}

	public void setComplete(boolean isComplete) {
		this.isComplete = isComplete;
	}

	public int getWinner() {
		return winner;
	}

	public void setWinner(int winner) {
		this.winner = winner;
	}

	public int[][] getChess() {
		return chess;
	}

	public void setChess(int[][] chess) {
		this.chess = chess;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public ArrayList<Move> getMoves() {
		return moves;
	}

	public void setMoves(ArrayList<Move> moves) {
		this.moves = moves;
	}

	/**
	 * @param isComplete
	 * @param winner
	 * @param chess
	 * @param username
	 * @param blackPlayer
	 * @param whitePlayer
	 * @param moves
	 */
	public Game(boolean isComplete, int winner, int[][] chess, String username, String blackPlayer, String whitePlayer,
			ArrayList<Move> moves) {
		super();
		this.isComplete = isComplete;
		this.winner = winner;
		this.chess = chess;
		this.username = username;
		this.blackPlayer = blackPlayer;
		this.whitePlayer = whitePlayer;
		this.moves = moves;
		Date now = new Date();
		SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd-hh-mm");
		this.time = ft.format(now);
	}

	/**
	 * 
	 */
	public Game() {
		super();
	}

}
