package entity;

public class Move {

	private int color;
	private int x;
	private int y;
	private int time;

	public int getTime() {
		return time;
	}

	public void setTime(int time) {
		this.time = time;
	}

	public int getColor() {
		return color;
	}

	public void setColor(int color) {
		this.color = color;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	/**
	 * @param color
	 * @param x
	 * @param y
	 * @param time
	 */
	public Move(int color, int x, int y, int time) {
		super();
		this.color = color;
		this.x = x;
		this.y = y;
		this.time = time;
	}

	/**
	 * 
	 */
	public Move() {
		super();
	}

}
