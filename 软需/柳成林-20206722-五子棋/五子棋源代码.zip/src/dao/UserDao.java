package dao;

import java.util.List;

import entity.User;

public class UserDao {

	private List<User> userData;

	public UserDao() {
		setUserData(util.FileUtils.readUserData("Users"));

	}

	public List<User> getUserData() {
		return userData;
	}

	public void setUserData(List<User> userData) {
		this.userData = userData;
	}

	public User getUser(String username, String password) {

		for (User e : userData) {
			if (e.getUsername().equals(username) && e.getPassword().equals(password)) {
				return e;
			}
		}
		return null;

	}

}
