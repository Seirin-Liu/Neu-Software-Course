package dao;

import java.util.ArrayList;

import entity.Game;
import util.FileUtils;

public class GameDao {
	private ArrayList<Game> gameData;

	public ArrayList<Game> getGameData() {
		return gameData;
	}

	public void setGameData(ArrayList<Game> gameData) {
		this.gameData = gameData;
	}

	public GameDao() {
		gameData = FileUtils.readGameData("Games");
	}

	public ArrayList<Game> getUserGameData(String username, boolean isComplete) {
		if (gameData == null) {
			return null;
		}
		ArrayList<Game> games = new ArrayList<>();
		for (Game g : gameData) {
			if (g.getUsername().equals(username) && g.isComplete() == isComplete) {
				games.add(g);
			}
		}
		return games;
	}

	public ArrayList<Game> getUserGameData(boolean isComplete) {
		ArrayList<Game> games = new ArrayList<>();
		for (Game g : gameData) {
			if (g.isComplete() == isComplete) {
				games.add(g);
			}
		}
		return games;
	}

}
