package view;

import controller.RecordPlayer;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.util.Duration;

public class Clock extends Pane {

	private Timeline animation;
	private int tmp;
	private Label label = new Label("");

	private RecordPlayer recordPlayer;

	// private float f;
	//
	//
	//
	//
	// public float getF() {
	// return f;
	// }
	// public void setF(float f) {
	// this.f = f;
	// }
	public RecordPlayer getRecordPlayer() {
		return recordPlayer;
	}

	public void setRecordPlayer(RecordPlayer recordPlayer) {
		this.recordPlayer = recordPlayer;
	}

	public int getTmp() {
		return tmp;
	}

	public void setTmp(int tmp) {
		this.tmp = tmp;
	}

	public Clock() {
		tmp = 300;
		label.setFont(javafx.scene.text.Font.font(20));
		getChildren().add(label);
	}

	public void on() {
		animation = new Timeline(new KeyFrame(Duration.millis(1000), e -> timelabel()));
		animation.setCycleCount(Timeline.INDEFINITE);
		animation.play();
	}

	public void timelabel() {
		tmp--;
		label.setText(tmp + "");
	}

	public void setclockAndStart(int temp) {
		tmp = temp;
		if (animation == null) {
			playerOn();
		} else {
			animation.play();
		}

	}

	public void playerCount() {
		tmp--;
		label.setText("����һ����" + tmp);
		if (tmp == 0) {
			animation.pause();
			recordPlayer.drawOne();
		}
	}

	public void playerOn() {
		animation = new Timeline(new KeyFrame(Duration.millis(1000), e -> playerCount())); // ÿ��һ��ִ��һ��
		animation.setCycleCount(Timeline.INDEFINITE);
		animation.play();
	}

	/**
	 * ��ͣ����ʱ
	 */
	public void clockPause() {
		if (animation != null) {
			animation.pause();
		}
	}

	/**
	 * ��ʼ����ʱ
	 */
	public void clockStart() {

		animation.play();
	}

	/**
	 * �����趨ʱ�䲢��ʼ����ʱ
	 * 
	 */
	public void clockResetAndStart() {
		label.setText("300");
		tmp = 300;
		animation.play();
	}

	// public void ChangeSpeed(Float f) {
	// if(animation!=null) {
	// KeyFrame keyFrame=new KeyFrame(Duration.millis(1000/f), e -> playerCount());
	//
	// animation=new Timeline(keyFrame);
	// //animation.play();
	// }
	//
	//
	// else {return;}
	// }

}
