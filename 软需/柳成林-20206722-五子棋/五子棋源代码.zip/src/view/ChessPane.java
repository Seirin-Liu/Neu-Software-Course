package view;

import entity.FiveChess;
import entity.Move;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;

public class ChessPane extends Pane {

	public GraphicsContext gc;
	public Canvas canvas;
	public FiveChess fiveChess;

	public Canvas getCanvas() {
		return canvas;
	}

	public GraphicsContext getGc() {
		return gc;
	}

	public FiveChess getFiveChess() {
		return fiveChess;
	}

	public void setFiveChess(FiveChess fiveChess) {
		this.fiveChess = fiveChess;
	}

	public ChessPane(FiveChess fiveChess) {
		this.fiveChess = fiveChess;
		double cell = fiveChess.getCellLen();
		drawPane(cell);
		drawChess(cell);
		getChildren().add(canvas);
	}

	public void drawPane(double cell) {
		canvas = new Canvas(550, 550);
		gc = canvas.getGraphicsContext2D();
		gc.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
		// ��������
		gc.setStroke(Color.BLACK);
		for (int i = 0; i < fiveChess.getWidth() - 1; i++)
			{for (int j = 0; j < fiveChess.getHeight() - 1; j++) {
				gc.strokeRect(50 + i * cell, 50 + cell * j, cell, cell);// ����һ������ȡ���������
			}
		}
		for (int i = 0; i < fiveChess.getHeight(); i++) {
			for (int j = 0; j < fiveChess.getWidth(); j++) {
				if ((i == 3 && j == 3) || (i == 3 && j == 12) || (i == 12 && j == 3) || (i == 12 && j == 12)
						|| (i == 8 && j == 8)) {
					gc.setFill(Color.BLACK);// �������ɫ
					gc.fillOval(62 + i * cell - cell / 2, 62 + j * cell - cell / 2, 6, 6);
				}
			}
		}
	}

	public void drawChess(double cell) {

		int[][] chess = fiveChess.getChess();
		for (int i = 0; i < fiveChess.getHeight(); i++) {
			for (int j = 0; j < fiveChess.getWidth(); j++) {
				if (chess[i][j] == 1) {
					gc.setFill(Color.BLACK);// �������ɫ

					gc.fillOval(50 + i * cell - cell / 2, 50 + j * cell - cell / 2, cell, cell);
				} else if (chess[i][j] == 2) {
					gc.setFill(Color.WHITE);

					gc.fillOval(50 + i * cell - cell / 2, 50 + j * cell - cell / 2, cell, cell);// �����Բ
					gc.strokeOval(50 + i * cell - cell / 2, 50 + j * cell - cell / 2, cell, cell);// ��������
				}
			}
			}

	}

	/***
	 * ֱ�ӻ��������ϵ�������
	 * 
	 * @param chess
	 * @param cell
	 */
	public void drawChess(int[][] chess, double cell) {

		for (int i = 0; i < fiveChess.getHeight(); i++) {
			for (int j = 0; j < fiveChess.getWidth(); j++) {
				if (chess[i][j] == 1) {
					gc.setFill(Color.BLACK);// �������ɫ

					gc.fillOval(50 + i * cell - cell / 2, 50 + j * cell - cell / 2, cell, cell);
				} else if (chess[i][j] == 2) {
					gc.setFill(Color.WHITE);

					gc.fillOval(50 + i * cell - cell / 2, 50 + j * cell - cell / 2, cell, cell);// �����Բ
					gc.strokeOval(50 + i * cell - cell / 2, 50 + j * cell - cell / 2, cell, cell);// ��������
				}
			}
		}
	}

	/**
	 * һ��һ������,����ǵڼ���
	 * 
	 * @param move
	 * @param cell
	 */
	public void drawOneChess(Move move, int count) {
		int color = move.getColor();
		int i = move.getX();
		int j = move.getY();
		int cell = 30;
		if (color == 1) {
			gc.setFill(Color.BLACK);// �������ɫ
			gc.fillOval(50 + i * cell - cell / 2, 50 + j * cell - cell / 2, cell, cell);
			gc.setFill(Color.WHITE);
			gc.fillText(count + 1 + "", i * cell + 47, j * cell + 53);
		} else if (color == 2) {
			gc.setFill(Color.WHITE);
			gc.fillOval(50 + i * cell - cell / 2, 50 + j * cell - cell / 2, cell, cell);// �����Բ
			gc.strokeOval(50 + i * cell - cell / 2, 50 + j * cell - cell / 2, cell, cell);// ��������
			gc.setFill(Color.BLACK);
			gc.fillText(count + 1 + "", i * cell + 47, j * cell + 53);
		}
	}

	public void withDrawChess(Move move) {

		fiveChess.deletChess(move);
	}

}