package util;

import java.util.Stack;

import javafx.scene.Scene;
import javafx.stage.Stage;


public class SceneManager {
	
	private static Stack<Scene> Scenes=new Stack<Scene>();
	
	
	public static void addScene(Scene scene) {
		Scenes.add(scene);
	}
	
	public static void back(Stage stage) {
		
		Scenes.pop();
		stage.setScene(Scenes.peek());
		
	}

}
