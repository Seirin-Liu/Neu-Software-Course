package util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import entity.Game;
import entity.User;
import javafx.collections.ObservableList;

public class FileUtils {
	public static String getAllJson(String filename) {
		StringBuilder sb = new StringBuilder();
		File file = new File(".\\documents\\" + filename + ".txt");
		if (!file.exists()) {
			try {
				file.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		try {
			BufferedReader br = new BufferedReader(new FileReader(file));
			String line = null;
			while ((line = br.readLine()) != null) {
				sb.append(line + "/");
			}
			br.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sb.toString();
	}

	/**
	 * 
	 * @param filename
	 * @return
	 */
	public static List<User> readUserData(String filename) {
		String allJson = FileUtils.getAllJson(filename);
		if (allJson.length() == 0) {
			return null;
		} else {
			String[] Users = allJson.split("/");
			List<User> UserList = new ArrayList<User>();
			for (String mJson : Users) {
				User m = JSON.parseObject(mJson, new User().getClass());
				UserList.add(m);
			}
			return UserList;
		}
	}

	public static ArrayList<Game> readGameData(String filename) {
		String allJson = FileUtils.getAllJson(filename);
		if (allJson.length() == 0) {
			return null;
		} else {
			String[] Games = allJson.split("/");
			ArrayList<Game> GameList = new ArrayList<Game>();
			for (String mJson : Games) {
				Game m = JSON.parseObject(mJson, new Game().getClass());
				GameList.add(m);
			}
			return GameList;
		}
	}

	/**
	 * ���ļ���д��һ��json�����ı��ļ�ԭ��������
	 * 
	 * @param filename
	 * @param line
	 */
	public static void writeJson(String filename, String line) {

		File file = new File(".\\documents\\" + filename + ".txt");
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(file, true));
			bw.write(line + "\n");
			bw.flush();
			bw.close();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static void saveGameData(Game game, String fileName) {
		JSONObject po = (JSONObject) JSONObject.toJSON(game);
		writeJson(fileName, po.toString());
	}

	public static void writeGameData(String filename, ObservableList<Game> gameList) {
		File file = new File(".\\documents\\" + filename + ".txt");

		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(file, false));
			StringBuilder sb = new StringBuilder();
			for (Game m : gameList) {
				JSONObject mj = (JSONObject) JSONObject.toJSON(m);
				sb.append(mj.toString() + "\n");
			}
			bw.write(sb.toString());
			bw.flush();
			bw.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void writeUserData(String filename, ObservableList<User> userList) {
		File file = new File(".\\documents\\" + filename + ".txt");

		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(file, false));
			StringBuilder sb = new StringBuilder();
			for (User m : userList) {
				JSONObject mj = (JSONObject) JSONObject.toJSON(m);
				sb.append(mj.toString() + "\n");
			}
			bw.write(sb.toString());
			bw.flush();
			bw.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
