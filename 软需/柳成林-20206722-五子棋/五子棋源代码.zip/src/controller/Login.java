package controller;

import dao.UserDao;
import entity.User;

public class Login {

	private UserDao userDao;

	public Login() {
		userDao = new UserDao();
	}

	public UserDao getUserDao() {
		return userDao;
	}

	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}

	public User checkUser(String username, String password) {

		User user;
		user = userDao.getUser(username, password);
		if (user != null) {
			return user;
		}
		return null;
	}

}
