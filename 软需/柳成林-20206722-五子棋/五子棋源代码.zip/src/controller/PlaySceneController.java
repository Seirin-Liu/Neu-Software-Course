package controller;

import entity.FiveChess;
import entity.Game;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import util.PlayState;
import view.ChessPane;
import view.Clock;

public class PlaySceneController implements Controller {

	private Stage stage;
	private ChessPane pane;
	private FiveChess fiveChess;
	private Clock clock;

	private PlayGame newGame;

	public Stage getStage() {
		return stage;
	}

	public void setStage(Stage stage) {
		this.stage = stage;
	}

	@FXML
	private Button pauseButton;

	@FXML
	private Label timerLabel;

	@FXML
	private Button saveButton;

	@FXML
	private Button returnButton;

	@FXML
	private Button withdrawButton;

	@FXML
	private Label currentSideLabel;

	@FXML
	private Pane chessPane;

	@FXML
	private Pane timerPane;

	@FXML
	private Label userIdLabel;

	@FXML
	private Label blackPlayer;

	@FXML
	private Label whitePlayer;

	@FXML
	void initialize() {

		userIdLabel.setText("�û���" + util.PlayState.username);
		blackPlayer.setText(PlayState.blackPlayer);
		whitePlayer.setText(PlayState.whitePlayer);
		whitePlayer.setTextFill(Color.WHITE);

	}

	/**
	 * ��ͣ�Ϳ�ʼ
	 * 
	 * @param event
	 */
	@FXML
	void pauseButtonEvent(ActionEvent event) {

		if (util.PlayState.isPause) {
			clock.clockStart();
			util.PlayState.isPause = false;
			pauseButton.setText("��ͣ");
		} else {
			clock.clockPause();
			util.PlayState.isPause = true;
			pauseButton.setText("��ʼ");
		}
	}

	@FXML
	void saveButtonEvent(ActionEvent event) {

		newGame.saveGame(false);

		pane.setOnMouseClicked(null);
		saveButton.setDisable(true);// ���ñ��水ť
		pauseButton.setDisable(true);
		withdrawButton.setDisable(true);
		clock.clockPause();

	}

	@FXML
	void returnButtonEvent(ActionEvent event) {
		util.SceneManager.back(stage);

	}

	@FXML
	void withdrawButtonEvent(ActionEvent event) {
		if (newGame.getMoves().size() != 0) {
			newGame.withDraw(); // ɾ��move,ͬʱ�ı�fiveChess

			chessPane.getChildren().clear();// �������

			// ���¼�������
			pane = new ChessPane(fiveChess); // �����޸ĺ��fiveChess����,���»�������
			newGame.setChessPane(pane);
			pane.setOnMouseClicked(newGame);// �¼�Դ�󶨴�����
			chessPane.getChildren().add(pane);

			clock.clockResetAndStart();

		}

	}

	public void drawChessPane() {

		fiveChess = new FiveChess(); // �����µ��������
		fiveChess.setCurrentSide(util.PlayState.first);// ����������
		fiveChess.setCurrentSideLabel(currentSideLabel);// ����label���������ָı�
		// fiveChess.setTimerLabel(timerLabel);

		pane = new ChessPane(fiveChess);// ��ʼ������
		newGame = new PlayGame(fiveChess, pane, clock);
		newGame.setPlaySceneController(this);
		pane.setOnMouseClicked(newGame);// �¼�Դ�󶨴�����
		chessPane.getChildren().add(pane);

	}

	public void drawChessPane(Game game) {

		fiveChess = new FiveChess(); // �����µ��������
		fiveChess.setChess(game.getChess());
		fiveChess.setCurrentSide(game.getWinner());// ����������
		fiveChess.setCurrentSideLabel(currentSideLabel);// ����label���������ָı�

		pane = new ChessPane(fiveChess);// ��ʼ������
		newGame = new PlayGame(fiveChess, pane, clock, game.getMoves());
		newGame.setPlaySceneController(this);
		pane.setOnMouseClicked(newGame);// �¼�Դ�󶨴�����
		chessPane.getChildren().add(pane);
	}

	public void newGame() {
		clock = new Clock();
		timerPane.getChildren().add(clock);
		clock.on();
		drawChessPane();

	}

	public void endGame() {
		pane.setOnMouseClicked(null);
		saveButton.setDisable(true);// ���ñ��水ť
		pauseButton.setDisable(true);
		clock.clockPause();
	}

	public void continueGame(Game game) {
		clock = new Clock();
		timerPane.getChildren().add(clock);
		clock.on();
		drawChessPane(game);

	}

}
