package controller;

import java.io.IOException;

import dao.GameDao;
import entity.FiveChess;
import entity.Game;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.util.Callback;
import util.AlertUtils;
import util.PlayState;
import util.SceneManager;
import view.ChessPane;

public class GameLoaderSceneController implements Controller {

	private Stage stage;

	private ChessPane chessPane;
	private FiveChess fiveChess;

	private ObservableList<Game> gameData;

	private Game game;

	// private RecordPlayerSceneController recordPlayerSceneController;
	private PlaySceneController playSceneController;

	public Stage getStage() {
		return stage;
	}

	public void setStage(Stage stage) {
		this.stage = stage;
	}

	@FXML
	private Pane pane;

	@FXML
	private Button continueButton;

	@FXML
	private TableColumn<Game, String> gameColumn;
	@FXML
	private Pane timerPane;

	@FXML
	private TableColumn<Game, String> blackPlayerColumn;

	@FXML
	private TableColumn<Game, String> whitePlayerColumn;

	@FXML
	private TableView<Game> gameTable;

	@FXML
	private Button returnButton;

	@FXML
	void initialize() {
		gameData = FXCollections.observableArrayList(new GameDao().getUserGameData(PlayState.username, false));
		loadGameList();
		drawChessPane();

		gameTable.setOnMouseClicked(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent mouseEvent) {
				if (mouseEvent.getClickCount() == 1) {
					chessPane.getChildren().clear();
					drawChessPane();// �������
					game = gameTable.getSelectionModel().getSelectedItem(); // ��ȡ�������

					if (game != null) {
						chessPane.drawChess(game.getChess(), 30);
					}
				}
			}
		});
	}

	@FXML
	void continueButtonEvent(ActionEvent event) {
		if (game == null) {
			AlertUtils.newErrorAlert("error:δѡ��", "δѡ����Ϸ�浵", stage);
			return;
		}
		loadPlayScene();

	}

	@FXML
	void returnButtonEvent(ActionEvent event) {

		SceneManager.back(stage);

	}

	void loadGameList() {
		gameTable.setItems(gameData);
		gameColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Game, String>, ObservableValue<String>>() {
					@Override
					public ObservableValue<String> call(CellDataFeatures<Game, String> param) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty(param.getValue().getTime());
						return name;
					}
				});

		blackPlayerColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Game, String>, ObservableValue<String>>() {
					@Override
					public ObservableValue<String> call(CellDataFeatures<Game, String> param) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty(param.getValue().getBlackPlayer());
						return name;
					}
				});

		whitePlayerColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Game, String>, ObservableValue<String>>() {
					@Override
					public ObservableValue<String> call(CellDataFeatures<Game, String> param) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty(param.getValue().getWhitePlayer());
						return name;
					}
				});

	}

	void drawChessPane() {
		fiveChess = new FiveChess();
		chessPane = new ChessPane(fiveChess);// ��ʼ������
		pane.getChildren().add(chessPane);

	}

	/**
	 * ������Ϸ����
	 */
	void loadPlayScene() {
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(getClass().getResource("PlayScene.fxml"));
		try {
			AnchorPane root = (AnchorPane) loader.load();
			// drawChessPane(root);
			Scene scene = new Scene(root);

			util.SceneManager.addScene(scene);

			playSceneController = loader.getController();
			stage.setScene(scene);
			playSceneController.setStage(stage);
			playSceneController.continueGame(game);

			stage.setTitle("��Ϸ����");

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
