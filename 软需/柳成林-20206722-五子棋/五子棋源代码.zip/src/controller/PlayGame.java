package controller;
import java.util.ArrayList;

import entity.FiveChess;
import entity.Game;
import entity.Move;
import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;
import util.AlertUtils;
import util.FileUtils;
import util.PlayState;
import view.ChessPane;
import view.Clock;

public class PlayGame implements EventHandler<MouseEvent> {

	private FiveChess fiveChess;

	private ChessPane chessPane;

	public Clock clock;

	private ArrayList<Move> moves; // ÿһ��

	private PlaySceneController playSceneController;

	private boolean isEnd = false;

	public PlaySceneController getPlaySceneController() {
		return playSceneController;
	}

	public void setPlaySceneController(PlaySceneController playSceneController) {
		this.playSceneController = playSceneController;
	}

	public ArrayList<Move> getMoves() {
		return moves;
	}

	public void setMoves(ArrayList<Move> moves) {
		this.moves = moves;
	}

	public Clock getClock() {
		return clock;
	}

	public void setClock(Clock clock) {
		this.clock = clock;
	}

	public FiveChess getFiveChess() {
		return fiveChess;
	}

	public void setFiveChess(FiveChess fiveChess) {
		this.fiveChess = fiveChess;
	}

	public ChessPane getChessPane() {
		return chessPane;
	}

	public void setChessPane(ChessPane chessPane) {
		this.chessPane = chessPane;
	}

	public PlayGame(FiveChess fiveChess, ChessPane chessPane, Clock clock) {

		this.chessPane = chessPane;
		this.fiveChess = fiveChess;
		this.clock = clock;
		moves = new ArrayList<Move>();
	}

	public PlayGame(FiveChess fiveChess, ChessPane chessPane, Clock clock, ArrayList<Move> moves) {

		this.chessPane = chessPane;
		this.fiveChess = fiveChess;
		this.clock = clock;
		this.moves = moves;
	}

	@Override
	public void handle(MouseEvent event) {

		double cell = fiveChess.getCellLen();

		double x = event.getX();
		double y = event.getY();

		int i = (int) ((x - 50 + cell / 2) / cell);
		int j = (int) ((y - 50 + cell / 2) / cell);
		// i��j�������µ�λ��

		if (fiveChess.play(i, j)) { // �ı��̨��ά�����ֵ

			chessPane.drawChess(cell);

			// ��¼ÿһ��
			Move move = new Move(fiveChess.getCurrentSide(), i, j, 1 + 300 - clock.getTmp());
			moves.add(move);
			// System.err.println(moves);

			fiveChess.changeSide();

			// ���ж���û��ʤ��
			if (!fiveChess.judgeGame(i, j, fiveChess.getCurrentSide() == 1 ? 2 : 1)) {

				AlertUtils.newRmindAlert((fiveChess.getCurrentSide() == 1 ? "����" : "����") + "��ʤ����", "��������", null);

				fiveChess.changeSide();
				fiveChess.getCurrentSideLabel().setText(" ");
				clock.clockPause();

				saveGame(true); // ����
				playSceneController.endGame();
				isEnd = true;
			}
			// ���¼�ʱ
			if (!isEnd) {
				clock.clockResetAndStart();
			}

		}

	}

	/**
	 * ����
	 */
	public void withDraw() {
		Move move = moves.get(moves.size() - 1);
		chessPane.withDrawChess(move);
		moves.remove(move);

	}

	public void saveGame(boolean isComplete) {
		// System.out.println(moves.size());
		// Game game=new Game(isComplete, fiveChess.getCurrentSide(),
		// fiveChess.getChess(), PlayState.username,PlayState.opponent, moves);
		Game game = new Game(isComplete, fiveChess.getCurrentSide(), fiveChess.getChess(), PlayState.username,
				PlayState.blackPlayer, PlayState.whitePlayer, moves);
		FileUtils.saveGameData(game, "Games");
	}

}