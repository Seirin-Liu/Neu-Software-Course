package controller;

import java.util.ArrayList;

import entity.Game;
import entity.Move;
import view.ChessPane;
import view.Clock;

public class RecordPlayer {

	private ChessPane chessPane;

	public Clock clock;

	private ArrayList<Move> moves;

	private Game currentGame;

	private int count = 0;

	private RecordPlayerSceneController recordPlayerSceneController;

	public void setRecordPlayerSceneController(RecordPlayerSceneController recordPlayerSceneController) {
		this.recordPlayerSceneController = recordPlayerSceneController;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public Game getCurrentGame() {
		return currentGame;
	}

	public void setCurrentGame(Game currentGame) {
		this.currentGame = currentGame;
	}

	public ChessPane getChessPane() {
		return chessPane;
	}

	public void setChessPane(ChessPane chessPane) {
		this.chessPane = chessPane;
	}

	public Clock getClock() {
		return clock;
	}

	public void setClock(Clock clock) {
		this.clock = clock;
		this.clock.setRecordPlayer(this);
	}

	public ArrayList<Move> getMoves() {
		return moves;
	}

	public void setMoves(ArrayList<Move> moves) {
		this.moves = moves;
	}

	/**
	 * 
	 */
	public RecordPlayer() {
		super();
		clock = new Clock();
		clock.setRecordPlayer(this);
	}

	/**
	 * @param chessPane
	 * @param moves
	 */
	public RecordPlayer(ChessPane chessPane, ArrayList<Move> moves) {
		super();
		this.chessPane = chessPane;
		this.moves = moves;

	}

	/**
	 * ��ʼ�ط�
	 */
	public void play() {
		// clock=new Clock();
		clock.setclockAndStart(moves.get(count).getTime());
	}

	public void drawOne() {

		if (count == moves.size() - 1) {
			clock.clockPause();
			chessPane.drawOneChess(moves.get(count), count);
			recordPlayerSceneController.endPlay();
			return;
		}
		chessPane.drawOneChess(moves.get(count), count);
		count++;
		// System.out.println(count);
		clock.setclockAndStart(moves.get(count).getTime());

	}

	public void closePlayer() {
		count = 0;
		clock.clockPause();

	}

}
