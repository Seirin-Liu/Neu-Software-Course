package controller;

import dao.GameDao;
import entity.FiveChess;
import entity.Game;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.util.Callback;
import util.AlertUtils;
import util.FileUtils;
import util.SceneManager;
import view.ChessPane;

public class RecordManageSceneController implements Controller {

	private Stage stage;

	private ObservableList<Game> gameData;

	private ChessPane chessPane;
	private FiveChess fiveChess;
	private Game game;

	public Stage getStage() {
		return stage;
	}

	public void setStage(Stage stage) {
		this.stage = stage;
	}

	@FXML
	private Label blackPlayer;

	@FXML
	private TableColumn<Game, String> gameColumn;

	@FXML
	private TableColumn<Game, String> gameStateColumn;

	@FXML
	private Pane pane;

	@FXML
	private TableView<Game> gameTable;

	@FXML
	private Label resultLabel;

	@FXML
	private Button returnButton;

	@FXML
	private Button searchButton;

	@FXML
	private TextField searchField;

	@FXML
	private TableColumn<Game, String> usernameColumn;

	@FXML
	private Label whitePlayer;

	@FXML
	private TableColumn<Game, String> deleteButtonC;

	@FXML
	void initialize() {
		gameData = FXCollections.observableArrayList(new GameDao().getGameData());
		loadGameList(gameData);
		drawChessPane();

		gameTable.setOnMouseClicked(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent mouseEvent) {
				if (mouseEvent.getClickCount() == 1) {
					chessPane.getChildren().clear();
					drawChessPane();// �������
					game = gameTable.getSelectionModel().getSelectedItem(); // ��ȡ�������

					if (game != null) {
						chessPane.drawChess(game.getChess(), 30);
						blackPlayer.setText(game.getBlackPlayer());
						whitePlayer.setText(game.getWhitePlayer());
						if (game.isComplete()) {
							resultLabel.setText(game.getWinner() == 1 ? "����ʤ" : "����ʤ");
						} else {
							resultLabel.setText("");
						}

					}
				}
			}
		});
	}

	void loadGameList(ObservableList<Game> gameData) {
		gameTable.setItems(gameData);
		gameColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Game, String>, ObservableValue<String>>() {
					@Override
					public ObservableValue<String> call(CellDataFeatures<Game, String> param) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty(param.getValue().getTime());
						return name;
					}
				});

		gameStateColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Game, String>, ObservableValue<String>>() {
					@Override
					public ObservableValue<String> call(CellDataFeatures<Game, String> param) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty(
								param.getValue().isComplete() ? "�����" : "δ���");
						return name;
					}
				});
		/**
		 * �Զ��嵥Ԫ��
		 */
		gameStateColumn.setCellFactory(new Callback<TableColumn<Game, String>, TableCell<Game, String>>() {

			@Override
			public TableCell<Game, String> call(TableColumn<Game, String> param) {
				// TODO Auto-generated method stub

				TableCell<Game, String> cell = new TableCell<Game, String>() {

					@Override
					protected void updateItem(String item, boolean empty) {
						// TODO Auto-generated method stub

						super.updateItem(item, empty);
						if (empty == false && item != null) {

							HBox hBox = new HBox();
							hBox.setAlignment(Pos.CENTER);
							Label label = new Label(item);
							if (item.equals("�����")) {
								hBox.setStyle("-fx-background-color:#7FFF00");
							} else {
								hBox.setStyle("-fx-background-color:#FFA500");
							}
							hBox.getChildren().add(label);
							this.setGraphic(hBox);
						}

					}

				};
				return cell;
			}
		});

		usernameColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Game, String>, ObservableValue<String>>() {
					@Override
					public ObservableValue<String> call(CellDataFeatures<Game, String> param) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty(param.getValue().getUsername());
						return name;
					}
				});

		deleteButtonC.setCellFactory(new Callback<TableColumn<Game, String>, TableCell<Game, String>>() {

			@Override
			public TableCell<Game, String> call(TableColumn<Game, String> param) {
				// TODO Auto-generated method stub

				TableCell<Game, String> cell = new TableCell<Game, String>() {

					@Override
					protected void updateItem(String item, boolean empty) {
						// TODO Auto-generated method stub

						super.updateItem(item, empty);
						if (empty == false) {

							HBox hBox = new HBox();
							hBox.setAlignment(Pos.CENTER);
							Label label = new Label("ɾ��");
							label.setOnMouseClicked(new EventHandler<MouseEvent>() {

								@Override
								public void handle(MouseEvent event) {
									// TODO Auto-generated method stub

									deleteRecord();
								}
							});

							hBox.getChildren().add(label);
							hBox.setStyle("-fx-background-color:#DC143C");
							hBox.setOnMouseEntered(new EventHandler<MouseEvent>() {
								@Override
								public void handle(MouseEvent event) {
									setCursor(Cursor.HAND);
									hBox.setStyle("-fx-background-color:#F08080");
								}
							});
							hBox.setOnMouseExited(new EventHandler<MouseEvent>() {
								@Override
								public void handle(MouseEvent event) {
									setCursor(Cursor.HAND);
									hBox.setStyle("-fx-background-color:#DC143C");
								}
							});

							this.setGraphic(hBox);
						}

					}

				};
				return cell;
			}
		});

	}

	void drawChessPane() {
		fiveChess = new FiveChess();
		chessPane = new ChessPane(fiveChess);// ��ʼ������
		pane.getChildren().add(chessPane);

	}

	@FXML
	void returnButtonEvent(ActionEvent event) {

		SceneManager.back(stage);
	}

	@FXML
	void searchEvent(ActionEvent event) {

		if (gameData != null) {
			String key = searchField.getText();
			if (key == null || key.length() == 0) {
				loadGameList(gameData);
				return;
			}
			ObservableList<Game> games = FXCollections.observableArrayList();

			for (Game g : gameData) {
				if (g.getTime().indexOf(key) != -1 || g.getBlackPlayer().indexOf(key) != -1
						|| g.getWhitePlayer().indexOf(key) != -1 || g.getUsername().indexOf(key) != -1) {
					games.add(g);
				}
			}
			if (games.size() == 0) {
				AlertUtils.newErrorAlert("�����Ÿı������ؼ���", "���Ҳ�����Ϣ", stage);
				return;
			}
			loadGameList(games);
		}
	}

	void deleteRecord() {
		Game game = gameTable.getSelectionModel().getSelectedItem();
		if (game == null) {
			return;
		} else {
			if (AlertUtils.newQureAlert("�Ƿ�ɾ����", "ɾ����¼", stage))// ��������ѯ���Ƿ�ɾ��
			{
				gameData.remove(game);
				loadGameList(gameData);
				saveData();
			}

		}
	}

	void saveData() {
		FileUtils.writeGameData("Games", gameData);
	}

}
