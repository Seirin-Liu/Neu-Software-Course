package controller;

import java.io.IOException;

import entity.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class LoginSceneController implements Controller {

	private Stage stage;

	private PlayerSceneController playerSceneController;
	private AdminSceneController adminSceneController;

	public Stage getStage() {
		return stage;
	}

	public void setStage(Stage stage) {
		this.stage = stage;
	}

	@FXML
	private Button loginButton;

	@FXML
	private PasswordField passwordTextField;

	@FXML
	private TextField usernameTextField;

	@FXML
	private Hyperlink newLink;

	@FXML
	void initialize() {

		usernameTextField.setPromptText("�û���");
		passwordTextField.setPromptText("����");
	}

	@FXML
	void newLinkEvent(ActionEvent event) {

		openNewUserStage();
	}

	@FXML
	void loginButtonEvent(ActionEvent event) {

		String username = usernameTextField.getText();
		String password = passwordTextField.getText();
		User user;
		if (isInputValid()) {
			if ((user = new Login().checkUser(username, password)) != null) {
				if (!user.isAdmin()) {
					loadPlayerScene();
					util.PlayState.username = user.getUsername(); // ���õ�ǰϵͳ��¼�û���
				} else {
					loadAdminScene();
					util.PlayState.username = user.getUsername();
				}
			} else {
				util.AlertUtils.newErrorAlert("�˺Ż���������", "��¼ʧ��", stage);
			}

		}

	}

	public void loadPlayerScene() {
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(getClass().getResource("PlayerScene.fxml"));
		try {
			AnchorPane root = (AnchorPane) loader.load();
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("Scene.css").toExternalForm());
			util.SceneManager.addScene(scene);
			playerSceneController = loader.getController();
			stage.setScene(scene);
			playerSceneController.setStage(stage);
			stage.setTitle("ѡ�����");

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void loadAdminScene() {
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(getClass().getResource("AdminScene.fxml"));
		try {
			AnchorPane root = (AnchorPane) loader.load();
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("Scene.css").toExternalForm());
			util.SceneManager.addScene(scene);
			adminSceneController = loader.getController();
			stage.setScene(scene);
			adminSceneController.setStage(stage);
			stage.setTitle("����Ա����");

			// ControllerManager.addController(adminSceneController);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void openNewUserStage() {
		NewUserStageController newUserStageController;
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(getClass().getResource("NewUserStage.fxml"));
		try {
			AnchorPane root = (AnchorPane) loader.load();
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("Scene.css").toExternalForm());
			// util.SceneSelecter.addScene(scene);
			newUserStageController = loader.getController();
			Stage stage = new Stage();
			stage.setScene(scene);
			newUserStageController.setStage(stage);
			stage.initOwner(this.stage);
			stage.initModality(Modality.WINDOW_MODAL); // ��������Ժ���벻�ܵ�ԭ����stage
			stage.setTitle("ע�����");
			stage.setResizable(false);
			stage.setWidth(400.0);
			stage.setHeight(300.0);// ���ô�С���ɸı�
			stage.showAndWait();

			// ControllerManager.addController(adminSceneController);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public boolean isInputValid() {
		// TODO Auto-generated method stub

		String errorMessage = "";

		if (usernameTextField.getText() == null || usernameTextField.getText().length() == 0) {
			errorMessage += "�û���Ϊ��\n";
		}

		if (passwordTextField.getText() == null || passwordTextField.getText().length() == 0) {
			errorMessage += "����Ϊ��\n";
		}

		if (errorMessage.length() == 0) {
			return true;
		} else {
			// Show the error message.
			util.AlertUtils.newErrorAlert(errorMessage, "��¼ʧ��", stage);

			return false;
		}

	}

}