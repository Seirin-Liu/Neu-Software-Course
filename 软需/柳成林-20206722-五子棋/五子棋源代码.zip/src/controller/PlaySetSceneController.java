package controller;

import java.io.IOException;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import util.PlayState;

public class PlaySetSceneController implements Controller {

	private Stage stage;
	private PlaySceneController playSceneController;

	public Stage getStage() {
		return stage;
	}

	public void setStage(Stage stage) {
		this.stage = stage;
	}

	@FXML
	private Button startGameButton;
	@FXML
	private Button returnButton;

	@FXML
	private TextField blackPlayer;

	@FXML
	private TextField whitePlayer;

	@FXML
	private Label UerIdLabel;

	@FXML
	private ComboBox<String> comboBox;

	@FXML
	void startGemeButtonEvent(ActionEvent event) {
		if (comboBox.getValue() == "��������") {
			util.PlayState.first = 1;
		}
		if (comboBox.getValue() == "��������") {
			util.PlayState.first = 2;
		}

		PlayState.blackPlayer = blackPlayer.getText();
		PlayState.whitePlayer = whitePlayer.getText();
		loadPlayScene();

	}

	@FXML
	void returnButtonEvent(ActionEvent event) {
		util.SceneManager.back(stage);

	}

	/**
	 * ��ʼ��
	 */
	@FXML
	void initialize() {
		ObservableList<String> options = FXCollections.observableArrayList("��������", "��������");
		comboBox.setItems(options);
		comboBox.setValue("��������");

		UerIdLabel.setText(util.PlayState.username);

	}

	/**
	 * ������Ϸ����
	 */
	void loadPlayScene() {
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(getClass().getResource("PlayScene.fxml"));
		try {
			AnchorPane root = (AnchorPane) loader.load();
			// drawChessPane(root);
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("Scene.css").toExternalForm());
			util.SceneManager.addScene(scene);

			playSceneController = loader.getController();
			stage.setScene(scene);
			playSceneController.setStage(stage);

			PlayState.isPause = false;

			playSceneController.newGame();

			stage.setTitle("��Ϸ����");

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// void drawChessPane(AnchorPane root){
	//
	// FiveChess fiveChess=new FiveChess(); //�����µ��������
	//
	// //���ݵ�ǰ״̬ѡ��˭����

	//
	// ChessPane chessPane= new ChessPane(fiveChess);//��ʼ������
	// chessPane.setOnMouseClicked(new PlayGame(fiveChess, chessPane));// �¼�Դ�󶨴�����
	//
	// root.getChildren().add(chessPane);//��������
	//
	// }

}
