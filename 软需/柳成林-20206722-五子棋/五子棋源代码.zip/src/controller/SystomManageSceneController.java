package controller;

import dao.UserDao;
import entity.User;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import javafx.util.Callback;
import util.AlertUtils;
import util.FileUtils;
import util.PlayState;
import util.SceneManager;

public class SystomManageSceneController {

	private Stage stage;
	private ObservableList<User> userData;

	public Stage getStage() {
		return stage;
	}

	public void setStage(Stage stage) {
		this.stage = stage;
	}

	@FXML
	private TableColumn<User, String> ChangeColumn;

	@FXML
	private Button addButton;

	@FXML
	private TableColumn<User, String> authorityColumn;

	@FXML
	private TableView<User> UserTable;

	@FXML
	private TableColumn<User, String> passwordColumn;

	@FXML
	private Button returnButton;

	@FXML
	private Button searchButton;

	@FXML
	private TextField searchField;

	@FXML
	private TableColumn<User, String> usernameColumn;

	@FXML
	private TextField usernameTextField;
	@FXML
	private TextField passwordTextField;

	@FXML
	private CheckBox AdminCheckBox;

	@FXML
	void initialize() {

		userData = FXCollections.observableArrayList(new UserDao().getUserData());
		loadUserList(userData);

	}

	@FXML
	void returnButtonEvent(ActionEvent event) {

		SceneManager.back(stage);
	}

	@FXML
	void addButtonEvent(ActionEvent event) {

		if (isInputValid()) {
			User user = new User(usernameTextField.getText(), passwordTextField.getText(), AdminCheckBox.isSelected());
			userData.add(user);
			AlertUtils.newRmindAlert("�����û��ɹ�", "��ʾ", stage);
			usernameTextField.setText("");
			passwordTextField.setText("");
			AdminCheckBox.setSelected(false);
			loadUserList(userData);
			saveData();

		}
	}

	@FXML
	void searchEvent(ActionEvent event) {

		if (userData != null) {
			String key = searchField.getText();
			if (key == null || key.length() == 0) {
				loadUserList(userData);
				return;
			}
			ObservableList<User> users = FXCollections.observableArrayList();

			for (User g : userData) {
				if (g.getUsername().indexOf(key) != -1) {
					users.add(g);
				}
			}
			if (users.size() == 0) {
				AlertUtils.newErrorAlert("�����Ÿı������ؼ���", "���Ҳ�����Ϣ", stage);
				return;
			}
			loadUserList(users);
		}
	}

	public void loadUserList(ObservableList<User> userData) {

		UserTable.setItems(userData);
		usernameColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<User, String>, ObservableValue<String>>() {

					@Override
					public ObservableValue<String> call(CellDataFeatures<User, String> param) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty(param.getValue().getUsername());
						return name;
					}
				});
		passwordColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<User, String>, ObservableValue<String>>() {

					@Override
					public ObservableValue<String> call(CellDataFeatures<User, String> param) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty(param.getValue().getPassword());
						return name;
					}
				});
		authorityColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<User, String>, ObservableValue<String>>() {

					@Override
					public ObservableValue<String> call(CellDataFeatures<User, String> param) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty(
								param.getValue().isAdmin() ? "����Ա" : "��ͨ�û�");
						return name;
					}
				});

		ChangeColumn.setCellFactory(new Callback<TableColumn<User, String>, TableCell<User, String>>() {

			@Override
			public TableCell<User, String> call(TableColumn<User, String> param) {
				TableCell<User, String> cell = new TableCell<User, String>() {

					@Override
					protected void updateItem(String item, boolean empty) {
						// TODO Auto-generated method stub

						super.updateItem(item, empty);
						if (empty == false) {

							HBox hBox = new HBox();
							hBox.setAlignment(Pos.CENTER);
							Label label = new Label("�޸�Ȩ��");

							label.setOnMouseClicked(new EventHandler<MouseEvent>() {

								@Override
								public void handle(MouseEvent event) {
									// TODO Auto-generated method stub
									Change();
								}
							});

							hBox.getChildren().add(label);
							hBox.setStyle("-fx-background-color:FFD700");
							hBox.setOnMouseEntered(new EventHandler<MouseEvent>() {
								@Override
								public void handle(MouseEvent event) {
									setCursor(Cursor.HAND);
									hBox.setStyle("-fx-background-color:#F4A460");
								}
							});

							hBox.setOnMouseExited(new EventHandler<MouseEvent>() {
								@Override
								public void handle(MouseEvent event) {
									hBox.setStyle("-fx-background-color:FFD700");
								}
							});
							this.setGraphic(hBox);
						}

					}

				};
				return cell;
			}
		});

		authorityColumn.setCellFactory(new Callback<TableColumn<User, String>, TableCell<User, String>>() {

			@Override
			public TableCell<User, String> call(TableColumn<User, String> param) {
				// TODO Auto-generated method stub
				TableCell<User, String> cell = new TableCell<User, String>() {

					@Override
					protected void updateItem(String item, boolean empty) {
						// TODO Auto-generated method stub

						super.updateItem(item, empty);
						if (empty == false) {

							HBox hBox = new HBox();
							hBox.setAlignment(Pos.CENTER);

							Label label = new Label(item);

							hBox.getChildren().add(label);
							if (item.equals("����Ա")) {
								hBox.setStyle("-fx-background-color:#FFA500");
							} else {
								hBox.setStyle("-fx-background-color:#00FF7F");
							}

							this.setGraphic(hBox);
						}

					}

				};
				return cell;
			}
		});

	}

	public void Change() {
		User user = UserTable.getSelectionModel().getSelectedItem();
		if (user == null) {
			return;
		} else if (user.getUsername().equals(PlayState.username)) {
			AlertUtils.newErrorAlert("���ܸı�������Ȩ��", "����", stage);
		} else {
			if (user.isAdmin()) {
				user.setAdmin(false);
			} else {
				user.setAdmin(true);
			}
			loadUserList(userData);
			saveData();
		}
	}

	public void saveData() {
		FileUtils.writeUserData("Users", userData);
	}

	public boolean isInputValid() {
		// TODO Auto-generated method stub

		String errorMessage = "";

		if (usernameTextField.getText() == null || usernameTextField.getText().length() == 0) {
			errorMessage += "�û���Ϊ��\n";
		}

		if (passwordTextField.getText() == null || passwordTextField.getText().length() == 0) {
			errorMessage += "����Ϊ��\n";
		}
		for (User u : userData) {
			if (u.getUsername().equals(usernameTextField.getText())) {
				errorMessage += "���û����Ѵ���\n";
			}
		}
		if (errorMessage.length() == 0) {
			return true;
		} else {
			// Show the error message.
			util.AlertUtils.newErrorAlert(errorMessage, "����ʧ��", stage);

			return false;
		}

	}

}
