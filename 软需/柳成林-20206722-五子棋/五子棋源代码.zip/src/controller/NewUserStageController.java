package controller;

import dao.UserDao;
import entity.User;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import util.AlertUtils;
import util.FileUtils;

public class NewUserStageController {

	private Stage stage;

	public Stage getStage() {
		return stage;
	}

	public void setStage(Stage stage) {
		this.stage = stage;
	}

	private ObservableList<User> userData;

	@FXML
	private Button addButton;

	@FXML
	private TextField passwordTextField;

	@FXML
	private Button returnButton;

	@FXML
	private TextField usernameTextField;

	@FXML
	void initialize() {

		userData = FXCollections.observableArrayList(new UserDao().getUserData());

	}

	@FXML
	void addButtonEvent(ActionEvent event) {

		if (isInputValid()) {
			User user = new User(usernameTextField.getText(), passwordTextField.getText(), false);
			userData.add(user);
			AlertUtils.newRmindAlert("�����û��ɹ�", "��ʾ", stage);

			saveData();
			stage.close();

		}

	}

	@FXML
	void returnButtonEvent(ActionEvent event) {
		stage.close();
	}

	public boolean isInputValid() {
		// TODO Auto-generated method stub

		String errorMessage = "";

		if (usernameTextField.getText() == null || usernameTextField.getText().length() == 0) {
			errorMessage += "�û���Ϊ��\n";
		}

		if (passwordTextField.getText() == null || passwordTextField.getText().length() == 0) {
			errorMessage += "����Ϊ��\n";
		}
		for (User u : userData) {
			if (u.getUsername().equals(usernameTextField.getText())) {
				errorMessage += "���û����Ѵ���\n";
			}
		}
		if (errorMessage.length() == 0) {
			return true;
		} else {
			// Show the error message.
			util.AlertUtils.newErrorAlert(errorMessage, "ע��ʧ��", stage);

			return false;
		}

	}

	public void saveData() {
		FileUtils.writeUserData("Users", userData);
	}

}
