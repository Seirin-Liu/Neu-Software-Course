package controller;

import dao.GameDao;
import entity.FiveChess;
import entity.Game;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.util.Callback;
import util.AlertUtils;
import util.PlayState;
import view.ChessPane;

public class RecordPlayerSceneController implements Controller {

	private Stage stage;
	private ChessPane pane;
	private FiveChess fiveChess;

	@FXML
	private Pane timerPane;
	@FXML
	private TableColumn<Game, String> gameColumn;

	@FXML
	private TableColumn<Game, String> blackPlayerColumn;

	@FXML
	private TableColumn<Game, String> whitePlayerColumn;

	@FXML
	private TableView<Game> gameTable;

	// @FXML
	// private ComboBox<String> speedComboBox;

	@FXML
	private Label resultLabel;

	// private Clock clock;
	private RecordPlayer recordPlayer;

	private ObservableList<Game> gameData;

	@FXML
	private TableColumn<Game, String> playColumn;

	public Stage getStage() {
		return stage;
	}

	public void setStage(Stage stage) {
		this.stage = stage;
	}

	@FXML
	private Button returnButton;

	@FXML
	private Button startButton;

	@FXML
	private Button searchButton;

	@FXML
	private Button pauseButton;

	@FXML
	private TextField searchField;

	@FXML
	private Pane chessPane;

	@FXML
	void initialize() {

		// ObservableList<String> options = FXCollections.observableArrayList("0.5",
		// "1.0","2.0");
		// speedComboBox.setItems(options);
		// speedComboBox.setValue("1.0");
		pauseButton.setDisable(true);

		recordPlayer = new RecordPlayer();
		recordPlayer.setRecordPlayerSceneController(this);

		// recordPlayer.setClock(new Clock());
		if (new GameDao().getUserGameData(PlayState.username, true) != null) {
			gameData = FXCollections.observableArrayList(new GameDao().getUserGameData(PlayState.username, true));
		}
		loadGameList(gameData);
		drawChessPane();

		gameTable.setOnMouseClicked(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent mouseEvent) {
				if (mouseEvent.getClickCount() == 1) {
					chessPane.getChildren().clear();
					drawChessPane();
					recordPlayer.closePlayer();
					Game game = gameTable.getSelectionModel().getSelectedItem(); // ��ȡ�������
					if (game != null) {
						pane.drawChess(game.getChess(), 30);
						pauseButton.setDisable(true);
						PlayState.isPause = false;
						pauseButton.setText("��ͣ");
						resultLabel.setText("ʤ��: " + (game.getWinner() == 1 ? "����" : "����"));
					}
				}
			}
		});

		// speedComboBox.getSelectionModel().selectedItemProperty().addListener(new
		// ChangeListener<String>() {
		// @Override
		// public void changed(ObservableValue<? extends String> observable, String
		// oldValue, String newValue) {
		// // TODO Auto-generated method stub
		// recordPlayer.getClock().ChangeSpeed(Float.parseFloat(newValue));
		//
		//
		// }
		// });
	}

	@FXML
	void returnButtonEvent(ActionEvent event) {
		util.SceneManager.back(stage);

		recordPlayer = null;

	}

	@FXML
	void pauseButtonEvent(ActionEvent event) {

		if (util.PlayState.isPause) {
			recordPlayer.getClock().clockStart();
			util.PlayState.isPause = false;
			pauseButton.setText("��ͣ");
		} else {
			recordPlayer.getClock().clockPause();
			util.PlayState.isPause = true;
			pauseButton.setText("��ʼ");
		}
	}

	@FXML
	void searchEvent(ActionEvent event) {
		if (gameData != null) {
			String key = searchField.getText();
			if (key == null || key.length() == 0) {
				loadGameList(gameData);
				return;
			}
			ObservableList<Game> games = FXCollections.observableArrayList();
			for (Game g : gameData) {
				if (g.getTime().indexOf(key) != -1 || g.getBlackPlayer().indexOf(key) != -1
						|| g.getWhitePlayer().indexOf(key) != -1) {
					games.add(g);
				}
			}
			if (games.size() == 0) {
				AlertUtils.newErrorAlert("�����Ÿı������ؼ���", "���Ҳ�����Ϣ", stage);
				return;
			}
			loadGameList(games);
		}
	}

	@FXML
	void startButtonEvent(ActionEvent event) {

		timerPane.getChildren().clear();
		Game p = gameTable.getSelectionModel().getSelectedItem();
		if (p == null) {
			util.AlertUtils.newErrorAlert("error��δѡ��", "��ѡ�񲥷ż�¼", stage);
			return;
		}
		// int index = gameTable.getItems().indexOf(p);]
		// timerPane.getChildren().clear();

		chessPane.getChildren().clear();
		drawChessPane();

		recordPlayer.setChessPane(pane);
		recordPlayer.setMoves(p.getMoves());
		recordPlayer.setCount(0);

		recordPlayer.play();

		pauseButton.setDisable(false);

		timerPane.getChildren().add(recordPlayer.getClock());
	}

	void drawChessPane() {
		fiveChess = new FiveChess();
		pane = new ChessPane(fiveChess);// ��ʼ������
		chessPane.getChildren().add(pane);

	}

	void loadGameList(ObservableList<Game> gameData) {
		gameTable.setItems(gameData);
		gameColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Game, String>, ObservableValue<String>>() {
					@Override
					public ObservableValue<String> call(CellDataFeatures<Game, String> param) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty(param.getValue().getTime());
						return name;
					}
				});

		blackPlayerColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Game, String>, ObservableValue<String>>() {
					@Override
					public ObservableValue<String> call(CellDataFeatures<Game, String> param) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty(param.getValue().getBlackPlayer());
						return name;
					}
				});

		whitePlayerColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Game, String>, ObservableValue<String>>() {
					@Override
					public ObservableValue<String> call(CellDataFeatures<Game, String> param) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty(param.getValue().getWhitePlayer());
						return name;
					}
				});
		playColumn.setCellFactory(new Callback<TableColumn<Game, String>, TableCell<Game, String>>() {

			@Override
			public TableCell<Game, String> call(TableColumn<Game, String> param) {
				TableCell<Game, String> cell = new TableCell<Game, String>() {

					@Override
					protected void updateItem(String item, boolean empty) {
						// TODO Auto-generated method stub

						super.updateItem(item, empty);
						if (empty == false) {

							HBox hBox = new HBox();
							hBox.setAlignment(Pos.CENTER);
							Label label = new Label("˫���ط�");

							label.setOnMouseClicked(new EventHandler<MouseEvent>() {

								@Override
								public void handle(MouseEvent event) {
									// TODO Auto-generated method stub
									if (event.getClickCount() == 2) {
										startButtonEvent(null);
									}
								}
							});

							hBox.getChildren().add(label);
							hBox.setStyle("-fx-background-color:FFD700");
							hBox.setOnMouseEntered(new EventHandler<MouseEvent>() {
								@Override
								public void handle(MouseEvent event) {
									setCursor(Cursor.HAND);
									hBox.setStyle("-fx-background-color:#F4A460");
								}
							});

							hBox.setOnMouseExited(new EventHandler<MouseEvent>() {
								@Override
								public void handle(MouseEvent event) {
									hBox.setStyle("-fx-background-color:FFD700");
								}
							});
							this.setGraphic(hBox);
						}

					}

				};
				return cell;
			}
		});

	}

	public void endPlay() {
		pauseButton.setDisable(true);
		PlayState.isPause = false;
		pauseButton.setText("��ͣ");
		// AlertUtils.newRmindAlert("�ط��ѽ���", "�طŽ���", stage);
	}

}
