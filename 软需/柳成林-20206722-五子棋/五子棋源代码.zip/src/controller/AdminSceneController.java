package controller;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import util.SceneManager;

public class AdminSceneController implements Controller {

	private Stage stage;

	private RecordManageSceneController recordManagerSceneController;
	private SystomManageSceneController systomManageSceneController;
	private PlaySetSceneController playSetSceneController;
	private RecordPlayerSceneController recordPlayerSceneController;
	private GameLoaderSceneController gameLoaderSceneController;

	public Stage getStage() {
		return stage;
	}

	public void setStage(Stage stage) {
		this.stage = stage;
	}

	@FXML
	private Label loginLabel;

	@FXML
	private Button recordButton;

	@FXML
	private Button returnButton;

	@FXML
	private Button systomButton;

	@FXML
	private Button loadButton;

	@FXML
	private Button startButton;

	@FXML
	private Button watchButton;

	@FXML
	void loadButtonEvent(ActionEvent event) {

		loadGameLoaderScene();
	}

	@FXML
	void startButtonEvent(ActionEvent event) {
		loadPlaySetScene();

	}

	@FXML
	void watchButtonEvent(ActionEvent event) {
		loadRecordPlayerScene();

	}

	@FXML
	void recordButtonEvent(ActionEvent event) {

		loadRecordManagerScene();
	}

	@FXML
	void systomhButtonEvent(ActionEvent event) {

		loadSystomManagerScene();
	}

	@FXML
	void returnButtonEvent(ActionEvent event) {

		SceneManager.back(stage);
	}

	public void loadRecordManagerScene() {
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(getClass().getResource("RecordManageScene.fxml"));
		try {
			AnchorPane root = (AnchorPane) loader.load();
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("Scene.css").toExternalForm());
			util.SceneManager.addScene(scene);
			recordManagerSceneController = loader.getController();
			stage.setScene(scene);
			recordManagerSceneController.setStage(stage);
			stage.setTitle("��ּ�¼��������");

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void loadSystomManagerScene() {
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(getClass().getResource("SystomManageScene.fxml"));
		try {
			AnchorPane root = (AnchorPane) loader.load();
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("Scene.css").toExternalForm());
			util.SceneManager.addScene(scene);
			systomManageSceneController = loader.getController();
			stage.setScene(scene);
			systomManageSceneController.setStage(stage);
			stage.setTitle("��ּ�¼��������");

			// ControllerManager.addController(recordManagerSceneController);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	void loadPlaySetScene() {
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(getClass().getResource("PlaySetScene.fxml"));
		try {
			AnchorPane root = (AnchorPane) loader.load();

			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("Scene.css").toExternalForm());
			util.SceneManager.addScene(scene);
			playSetSceneController = loader.getController();
			stage.setScene(scene);
			playSetSceneController.setStage(stage);
			stage.setTitle("��Ϸ���ý���");

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	void loadRecordPlayerScene() {
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(getClass().getResource("RecordPlayerScene.fxml"));
		try {
			AnchorPane root = (AnchorPane) loader.load();

			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("Scene.css").toExternalForm());
			util.SceneManager.addScene(scene);
			recordPlayerSceneController = loader.getController();
			stage.setScene(scene);
			recordPlayerSceneController.setStage(stage);
			stage.setTitle("��ֻطŽ���");

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * �浵����
	 */
	void loadGameLoaderScene() {
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(getClass().getResource("GameLoaderScene.fxml"));
		try {
			AnchorPane root = (AnchorPane) loader.load();

			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("Scene.css").toExternalForm());
			util.SceneManager.addScene(scene);
			gameLoaderSceneController = loader.getController();
			stage.setScene(scene);
			gameLoaderSceneController.setStage(stage);
			stage.setTitle("�浵ѡ�����");

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
