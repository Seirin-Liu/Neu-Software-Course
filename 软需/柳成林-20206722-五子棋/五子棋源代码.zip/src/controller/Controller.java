package controller;

public interface Controller {

}
