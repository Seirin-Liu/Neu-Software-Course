package application;

import java.io.IOException;

import controller.LoginSceneController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * ���������
 * 
 * @author Seirin
 *
 */
public class Main extends Application {

	private Stage primaryStage;
	private Scene scene;

	private LoginSceneController loginScenecontroller;

	@Override
	public void start(Stage primaryStage) {

		this.primaryStage = primaryStage;
		initLoginScene();

	}

	public static void main(String[] args) {

		launch(args);
	}

	/**
	 * ���ص�¼����
	 * 
	 * @param primaryStage
	 */
	public void initLoginScene() {

		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(getClass().getResource("LoginScene.fxml"));
		try {
			AnchorPane root = (AnchorPane) loader.load();
			// initChessPane(root);
			scene = new Scene(root);
			util.SceneManager.addScene(scene);
			scene.getStylesheets().add(getClass().getResource("Scene.css").toExternalForm());
			loginScenecontroller = loader.getController();
			primaryStage.setScene(scene);
			primaryStage.setTitle("��¼����");
			primaryStage.setWidth(840.0);
			primaryStage.setHeight(600.0);
			primaryStage.setResizable(false); // ���ô�С���ɸı�

			loginScenecontroller.setStage(primaryStage);

			primaryStage.show();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void initChessPane(AnchorPane root) {
		// FiveChess fiveChess=new FiveChess(16, 16, 30);
		// ChessPane chessPane= new ChessPane(fiveChess);
		// root.getChildren().add(chessPane);

	}

}
