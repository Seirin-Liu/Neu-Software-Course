package com.seirin.settings;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.text.TextUtils;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class UserDao extends SQLiteOpenHelper {

    private String tableName="users";

    private  Context context;

    SettingDao settingDao;

    public UserDao(@Nullable Context context) {
        super(context, "Settings.db", null, 1);

        this.context=context;
        settingDao = new SettingDao(context);

    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String CREAT_USER ="create table users ("
                + "_id integer primary key autoincrement,"
                + "account text,"
                + "password text,"
                + "name text,"
                + "gender text,"
                + "born_date text,"
                + "home text,"
                + "head text,"
                + "tags text,"
                + "setting_id integer)";
        db.execSQL(CREAT_USER);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {


    }

    public long insertUser(User user){
        SQLiteDatabase database = getWritableDatabase();
        ContentValues values = new ContentValues();
        if(!TextUtils.isEmpty(user.getAccount())){
            values.put("account", user.getAccount());
        }
        if(!TextUtils.isEmpty(user.getPassword())){
            values.put("password", user.getPassword());
        }
        if(!TextUtils.isEmpty(user.getName())){
            values.put("name", user.getName());
        }
        if(!TextUtils.isEmpty(user.getGender())){
            values.put("gender", user.getGender());
        }
        if(!TextUtils.isEmpty(user.getBornDate())){
            values.put("born_date", user.getBornDate());
        }
        if(!TextUtils.isEmpty(user.getHome())){
            values.put("home", user.getHome());
        }
        if(!TextUtils.isEmpty(user.getHead())){
            values.put("head", user.getHead());
        }
        if(!TextUtils.isEmpty(user.getTags())){
            values.put("tags", user.getTags());
        }

        long settingId = settingDao.insertSetting(new Setting());
        values.put("setting_id", settingId);

        long count = database.insert(tableName, null, values);
        database.close();
        return count;
    }


    public long updateUser(User user){
        SQLiteDatabase database = getWritableDatabase();
        ContentValues values = new ContentValues();
        if(!TextUtils.isEmpty(user.getAccount())){
            values.put("account", user.getAccount());
        }
        if(!TextUtils.isEmpty(user.getPassword())){
            values.put("password", user.getPassword());
        }
        if(!TextUtils.isEmpty(user.getName())){
            values.put("name", user.getName());
        }
        if(!TextUtils.isEmpty(user.getGender())){
            values.put("gender", user.getGender());
        }
        if(!TextUtils.isEmpty(user.getBornDate())){
            values.put("born_date", user.getBornDate());
        }
        if(!TextUtils.isEmpty(user.getHome())){
            values.put("home", user.getHome());
        }
        if(!TextUtils.isEmpty(user.getHead())){
            values.put("head", user.getHead());
        }
        if(!TextUtils.isEmpty(user.getTags())){
            values.put("tags", user.getTags());
        }
        if(!TextUtils.isEmpty(user.getSettingId()+"")){
            values.put("setting_id", user.getSettingId());
        }
        int count = database.update(tableName, values, "_id=?", new String[]{String.valueOf(user.getId())});
        database.close();
        return count;
    }


    public List<User> listAll(){
        List<User> list = new ArrayList<>();
        SQLiteDatabase database = getWritableDatabase();
        Cursor data = database.query(tableName, null, null, null, null, null, null);
        if(data.getCount() > 0){
            while(data.moveToNext()) {
                User course = new User();
                course.setId(data.getInt(0));
                course.setAccount(data.getString(1));
                course.setPassword(data.getString(2));
                course.setName(data.getString(3));
                course.setGender(data.getString(4));
                course.setBornDate(data.getString(5));
                course.setHome(data.getString(6));
                course.setHead(data.getString(7));
                course.setTags(data.getString(8));
                course.setSettingId(data.getInt(9));
                list.add(course);
            }
        }
        database.close();
        return list;
    }


}
