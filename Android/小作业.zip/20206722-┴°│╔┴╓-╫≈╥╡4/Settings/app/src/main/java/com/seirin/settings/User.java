package com.seirin.settings;

import java.io.Serializable;

public class User implements Serializable {
    private int id;
    private String account;
    private String password;
    private String name;
    private String gender;
    private String bornDate;
    private String home;
    private String head;
    private String tags;
    private int settingId;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getBornDate() {
        return bornDate;
    }

    public void setBornDate(String bornDate) {
        this.bornDate = bornDate;
    }

    public String getHome() {
        return home;
    }

    public void setHome(String home) {
        this.home = home;
    }

    public String getHead() {
        return head;
    }

    public void setHead(String head) {
        this.head = head;
    }

    public int getSettingId() {
        return settingId;
    }

    public void setSettingId(int settingId) {
        this.settingId = settingId;
    }

    public String getTags() {
        return tags;
    }

    public void setTags(String tags) {
        this.tags = tags;
    }

    public User(String account, String password) {
        this.account = account;
        this.password = password;
        name="name";
        gender="未知";
        bornDate="2000-1-1";
        home="北京";
        head="default";
        tags="无";
        settingId=0;

    }

    public User(){

    }
}
