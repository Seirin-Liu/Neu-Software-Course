package com.seirin.settings.settings;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.icu.util.Calendar;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.seirin.settings.User;
import com.seirin.settings.view.FlowLayout;
import com.seirin.settings.adapter.Infor;
import com.seirin.settings.R;
import com.seirin.settings.ui.home.HomeViewModel;
import com.seirin.settings.utils.LQRPhotoSelectUtils;
import com.seirin.settings.utils.ToastUtil;

import java.io.File;
import java.util.ArrayList;



public class InforModifyActivity extends AppCompatActivity implements DatePickerDialog.OnDateSetListener {


    private EditText editName;
    private ImageView dateButton;
    private TextView bornDate;
    private ImageView portrait;
    private Button completeButton;
    private RadioGroup sexGroup;
    private EditText editHome;
    private Button portraitButton;
    private ArrayList<Infor> infors;
    private String headSource;

    LQRPhotoSelectUtils mLqrPhotoSelectUtils;
    private static final int REQUEST_CODE = 0x001;

    FlowLayout tag_vessel;
    ImageView add_tag;
    ArrayList<String> tagList;
    int screenWidth = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_infor_modify);

        overridePendingTransition(R.anim.slide_in_left,
                R.anim.slide_out_righ);


        editName =findViewById(R.id.editName);
        dateButton= findViewById(R.id.dateButton);
        bornDate=findViewById(R.id.bornDate);
        completeButton=findViewById(R.id.completeButton);
        dateButton.setImageResource(R.drawable.calender);
        portrait =findViewById(R.id.portrait);

        sexGroup= findViewById(R.id.sexGroup);
        editHome=findViewById(R.id.editHome);
        portraitButton=findViewById(R.id.portraitButton);


        dateButton= findViewById(R.id.dateButton);
        dateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                initCalender();
            }
        });

        screenWidth = getWindowManager().getDefaultDisplay().getWidth(); // 屏幕宽（像素
        tag_vessel = (FlowLayout) findViewById(R.id.tagvessel);
        add_tag = (ImageView) findViewById(R.id.add_tag);
        add_tag.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AddTagDialog();
            }
        });

        completeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                completeModify();
                finish();
            }
        });

        portraitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                showPhotoMenu(portraitButton);
            }
        });

        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }


        init();
        initPhotoSelecter();



    }

    public void init(){

        infors =HomeViewModel.getInforList().getValue();
        tagList= HomeViewModel.getTagList().getValue();

        editName.setText(infors.get(0).getContent());
        bornDate.setText(infors.get(2).getContent());

        switch(infors.get(1).getContent()){
            case "男":
                RadioButton radioButton =findViewById(R.id.man);
                radioButton.setChecked(true);
                break;
            case "女":
                RadioButton radioButton1 =findViewById(R.id.fale);
                radioButton1.setChecked(true);
                break;
            case "未知":
                RadioButton radioButton2 =findViewById(R.id.none);
                radioButton2.setChecked(true);
                break;
            default:
                break;
        }
        editHome.setText(infors.get(3).getContent());

        if (HomeViewModel.getHeadId().getValue()!= null){
            headSource = HomeViewModel.getHeadId().getValue();
            portrait.setImageURI(Uri.fromFile(new File(headSource)));}
        else{
            portrait.setImageResource(R.drawable.head);
        }

        int i= 0;
        for (String s: tagList){
            AddTag(s,i);
            i++;
        }

    }

    @Override
    public void onDateSet(DatePicker datePicker, int year, int month, int day) {
        String date = String.format("%d-%d-%d",year,month+1,day);
        bornDate.setText(date);

    }

    public void initCalender(){
        Calendar calendar = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            calendar = Calendar.getInstance();
        }
        DatePickerDialog dialog = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            dialog = new DatePickerDialog(InforModifyActivity.this,InforModifyActivity.this,

                    calendar.get(Calendar.YEAR),
                    calendar.get(Calendar.MARCH),
                    calendar.get(Calendar.DAY_OF_MONTH));
        }
        dialog.show();
    }



    /**
     * 添加标签的对话框
     */
    public void AddTagDialog() {
        final Dialog dlg = new Dialog(InforModifyActivity.this, R.style.dialog);
        dlg.show();
        dlg.getWindow().setGravity(Gravity.CENTER);
        dlg.getWindow().setLayout((int) (screenWidth * 0.8), android.view.WindowManager.LayoutParams.WRAP_CONTENT);
        dlg.getWindow().setContentView(R.layout.setting_add_tags_dialg);
        TextView add_tag_dialg_title = (TextView) dlg.findViewById(R.id.add_tag_dialg_title);
        final EditText add_tag_dialg_content = (EditText) dlg.findViewById(R.id.add_tag_dialg_content);
        TextView add_tag_dialg_no = (TextView) dlg.findViewById(R.id.add_tag_dialg_no);
        TextView add_tag_dialg_ok = (TextView) dlg.findViewById(R.id.add_tag_dialg_ok);
        add_tag_dialg_title.setText("添加个人标签");
        add_tag_dialg_no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dlg.dismiss();
            }
        });
        add_tag_dialg_ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //
                InputMethodManager imm = (InputMethodManager) InforModifyActivity.this.getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.toggleSoftInput(InputMethodManager.SHOW_IMPLICIT, InputMethodManager.HIDE_NOT_ALWAYS);

                tagList.add(add_tag_dialg_content.getText().toString());
                AddTag(tagList.get(tagList.size() - 1), tagList.size() - 1);
                dlg.dismiss();
            }
        });
    }

    /**
     * 添加标签
     * @param tag
     * @param i
     */
    @SuppressLint("NewApi")
    public void AddTag(String tag, int i) {
        final TextView mTag = new TextView(InforModifyActivity.this);
        mTag.setText(" "+tag+" ");
        mTag.setGravity(Gravity.CENTER);
        mTag.setTextSize(22);
//        mTag.setBackground(getResources().getDrawable(R.drawable.img).);
        mTag.setBackgroundResource(R.drawable.text);
        mTag.setTextColor(Color.WHITE);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, 80);//标签的高度
        params.setMargins(20, 10, 0, 10);

        tag_vessel.addView(mTag, i, params);

        mTag.setOnLongClickListener(new View.OnLongClickListener() {

            @Override
            public boolean onLongClick(View v) {
                // 长按标签删除操作
                final AlertDialog dlg = new AlertDialog.Builder(InforModifyActivity.this).create();
                dlg.show();
                dlg.getWindow().setGravity(Gravity.CENTER);
                dlg.getWindow().setLayout((int) (screenWidth * 0.8), android.view.WindowManager.LayoutParams.WRAP_CONTENT);
                dlg.getWindow().setContentView(R.layout.setting_add_tags_dialg);
                TextView add_tag_dialg_title = (TextView) dlg.findViewById(R.id.add_tag_dialg_title);
                EditText add_tag_dialg_content = (EditText) dlg.findViewById(R.id.add_tag_dialg_content);
                TextView add_tag_dialg_no = (TextView) dlg.findViewById(R.id.add_tag_dialg_no);
                TextView add_tag_dialg_ok = (TextView) dlg.findViewById(R.id.add_tag_dialg_ok);
                add_tag_dialg_title.setText("标签删除确认");
                add_tag_dialg_content.setText("您确定要删除“" + mTag.getText().toString() + "”这个标签吗？");
                add_tag_dialg_no.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dlg.dismiss();
                    }
                });
                add_tag_dialg_ok.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        tag_vessel.removeView(mTag);
                        for (int j = 0; j < tagList.size(); j++) {
                            Log.v("==", mTag.getText().toString() + "==" + tagList.get(j).toString());
                            if (mTag.getText().toString().replaceAll(" ", "")
                                    .equals(tagList.get(j).toString().replaceAll(" ", ""))) {
                                tagList.remove(j);
                            }
                        }
                        dlg.dismiss();
                    }
                });

                return true;
            }
        });
    }

    public  void showPhotoMenu(View view){
        // View当前PopupMenu显示的相对View的位置
        PopupMenu popupMenu = new PopupMenu(this,view);
        // menu布局
        popupMenu.getMenuInflater().inflate(R.menu.photo_button_menu, popupMenu.getMenu());
        // menu的item点击事件
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {

                if(item.getTitle().equals("拍照")){
                    //拍照
                    mLqrPhotoSelectUtils.takePhoto();
                }
                if(item.getTitle().equals("从相册选择")){
                    //选择照片
                    mLqrPhotoSelectUtils.selectPhoto();
                }
                return true;
            }
        });
//        // PopupMenu关闭事件
//        popupMenu.setOnDismissListener(new PopupMenu.OnDismissListener() {
//            @Override
//            public void onDismiss(PopupMenu menu) {
//                Toast.makeText(getApplicationContext(), "关闭PopupMenu", Toast.LENGTH_SHORT).show();
//            }
//        });

        popupMenu.show();
    }

    public void initPhotoSelecter(){
        //初始化
        //创建LQRPhotoSelectUtils（一个Activity对应一个LQRPhotoSelectUtils）
         mLqrPhotoSelectUtils = new LQRPhotoSelectUtils(this, new LQRPhotoSelectUtils.PhotoSelectListener() {

            @Override
            public void onFinish(File outputFile, Uri outputUri) {
                //当拍照或从图库选取图片成功后回调
//                mTvPath.setText(outputFile.getAbsolutePath());//显示图片路径
//                mTvUri.setText(outputUri.toString());//显示图片uri
//                //System.out.println(outputUri.toString());
//                Glide.with(InforModifyActivity.this).load(outputUri).into(mIvPic);//使用Glide进行图片展示
                ToastUtil.showMsg(InforModifyActivity.this, "选择完成");
                headSource = outputFile.getAbsolutePath();

                portrait.setImageURI(Uri.fromFile(new File(headSource)));
            }
        }, true);//是否裁剪。true裁剪，false不裁剪

        //检查权限
        if (ContextCompat.checkSelfPermission(InforModifyActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE)!= PackageManager.PERMISSION_GRANTED||
                ContextCompat.checkSelfPermission(InforModifyActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE)!= PackageManager.PERMISSION_GRANTED||
                ContextCompat.checkSelfPermission(InforModifyActivity.this, Manifest.permission.CAMERA)!= PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(InforModifyActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.CAMERA}, REQUEST_CODE);
        }else{
            ToastUtil.showMsg(InforModifyActivity.this, "已经获得了所有权限");
        }


    }



    public void completeModify(){
        infors.get(0).setContent(editName.getText().toString());
        infors.get(1).setContent(((RadioButton)findViewById(sexGroup.getCheckedRadioButtonId())).getText().toString());

        infors.get(2).setContent(bornDate.getText().toString());
        infors.get(3).setContent(editHome.getText().toString());
        HomeViewModel.setData(infors,tagList,headSource);
        HomeViewModel.updateUser();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode,  Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        //在Activity中的onActivityResult()方法里与LQRPhotoSelectUtils关联
        mLqrPhotoSelectUtils.attachToActivityForResult(requestCode, resultCode, data);
    }

}