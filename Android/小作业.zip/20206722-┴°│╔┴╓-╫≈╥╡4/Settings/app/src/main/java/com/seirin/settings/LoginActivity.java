package com.seirin.settings;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

import com.seirin.settings.ui.home.HomeViewModel;
import com.seirin.settings.utils.DialogUtil;

import java.util.List;

public class LoginActivity extends AppCompatActivity {

    EditText accountEdit;
    EditText passwordEdit;
    CheckBox remenberPass;
    Button loginButton;

    User loginUser;
    Setting loginUserSetting;
    UserDao userDao;
    SettingDao settingDao;


    Button button;

    private SharedPreferences pref;
    private SharedPreferences.Editor editor;
    private List<User> users;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null){
            actionBar.hide();
        }
        accountEdit = findViewById(R.id.account);
        passwordEdit = findViewById(R.id.password);
        remenberPass = findViewById(R.id.remberPass);
        loginButton = findViewById(R.id.login_button);
        loginButton.setEnabled(false);

        userDao =new UserDao(this);
        settingDao = new SettingDao(this);
        HomeViewModel.setUserDao(userDao);
        HomeViewModel.setSettingDao(settingDao);
        users = userDao.listAll();
        for(User user :users){
            Log.i("aaaa",user.getAccount()+" "+user.getPassword()+" "+user.getTags()+" "+user.getSettingId());
        }


        pref= PreferenceManager.getDefaultSharedPreferences(this);
        boolean isRemember = pref.getBoolean("remember_pass",false);
        if(isRemember){
            String account = pref.getString("account","");
            String password = pref.getString("password","");
            accountEdit.setText(account);
            passwordEdit.setText(password);
            remenberPass.setChecked(isRemember);
            loginButton.setEnabled(true);

        }

        accountEdit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                if(s.length()>0&&passwordEdit.getText().length()>0){
                    loginButton.setEnabled(true);
                }
                if(s.length()==0){
                    loginButton.setEnabled(false);
                }
            }
        });

        passwordEdit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                if(s.length()>0&&accountEdit.getText().length()>0){
                    loginButton.setEnabled(true);
                }
                if(s.length()==0){
                    loginButton.setEnabled(false);
                }
            }
        });

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                users = userDao.listAll();
                String account = accountEdit.getText().toString();
                String password = passwordEdit.getText().toString();
                if(check(account,password)){
                    editor=pref.edit();
                    if(remenberPass.isChecked()){
                        editor.putBoolean("remember_pass",true);
                        editor.putString("account",account);
                        editor.putString("password",password);
                    }
                    else{
                        editor.putString("account",account);
                        editor.putString("password",password);
                        editor.clear();
                    }
                    editor.apply();
                    Intent intent = new Intent(LoginActivity.this,MainActivity.class);
//                    intent.putExtra("loginUser",loginUser);
                    startActivity(intent);
                }
                else{
                    DialogUtil.showDialog(LoginActivity.this,"账号或密码错误！");
                }
            }
        });

        button = findViewById(R.id.add_button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(LoginActivity.this,TestActivity.class);
                startActivity(intent);
            }
        });

    }

    public boolean check(String account,String password){
        for (User user : users){
            if (user.getAccount().equals(account)){
                if(user.getPassword().equals(password)){
                    loginUser = user;
                    loginUserSetting = settingDao.searchSetting(user.getSettingId());
                    Log.i("aaaa",loginUserSetting.getId()+" "+loginUserSetting.getTagVisible());
                    HomeViewModel.setUserDate(loginUser,loginUserSetting);
                    return true;
                }
                return  false;
            }
        }
        return  false;

    }
}