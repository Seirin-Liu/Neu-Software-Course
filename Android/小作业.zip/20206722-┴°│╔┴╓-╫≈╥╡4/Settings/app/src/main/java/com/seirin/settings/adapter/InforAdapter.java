package com.seirin.settings.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.seirin.settings.R;

import java.util.List;

public class InforAdapter extends ArrayAdapter<Infor> {

    private int resourceId;

    public InforAdapter(@NonNull Context context, int textViewResourceId, @NonNull List<Infor> objects) {
        super(context, textViewResourceId, objects);
        resourceId = textViewResourceId;
    }

    @SuppressLint("ResourceAsColor")
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        Infor infor =getItem(position);
        View view = LayoutInflater.from(getContext()).inflate(resourceId,parent,false);

        ImageView icoImage = view.findViewById(R.id.setting_icon);
        TextView tagName = view.findViewById(R.id.t1);
        TextView Content = view.findViewById(R.id.content);
        icoImage.setImageResource(infor.getIcoId());

        tagName.setText(infor.getTagName()+":");
        if (infor.isVisible()){
        Content.setText(infor.getContent());
        }
        else{
            Content.setText("保密");
            Content.setBackgroundColor(R.color.black);
            Content.setTextColor(R.color.white);

        }


        return view;
    }
}
