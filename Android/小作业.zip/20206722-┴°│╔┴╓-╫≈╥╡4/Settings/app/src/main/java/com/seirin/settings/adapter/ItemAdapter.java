package com.seirin.settings.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.seirin.settings.R;

import java.util.List;


public class ItemAdapter extends ArrayAdapter<Item> {

    private int resourceId;

    public ItemAdapter(@NonNull Context context, int textViewResourceId, @NonNull List<Item> objects) {
        super(context, textViewResourceId, objects);
        resourceId = textViewResourceId;
    }
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        Item item =getItem(position);
        View view = LayoutInflater.from(getContext()).inflate(resourceId,parent,false);

        ImageView icoImage = view.findViewById(R.id.setting_icon);
        TextView name = view.findViewById(R.id.t1);
        ImageView i =view.findViewById(R.id.i);

        icoImage.setImageResource(item.getIcoId());
        name.setText(item.getName());
        i.setImageResource(R.drawable.i);


        return view;
    }
}
