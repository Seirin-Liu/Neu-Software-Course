package com.seirin.settings;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.text.TextUtils;

import androidx.annotation.Nullable;

public class SettingDao extends SQLiteOpenHelper {

    private String tableName="settings";

    public SettingDao(@Nullable Context context) {
        super(context, "UserSettings.db",null , 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String CREAT_SETTING ="create table settings ("
                + "_id integer primary key autoincrement,"
                + "nameVisible integer,"
                + "genderVisible integer,"
                + "bornDateVisible integer,"
                + "homeVisible integer,"
                + "TagVisible integer)";

        db.execSQL(CREAT_SETTING);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public long insertSetting(Setting setting){
        SQLiteDatabase database = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("nameVisible", setting.getNameVisible());
        values.put("genderVisible", setting.getGenderVisible());
        values.put("bornDateVisible", setting.getBornDateVisible());
        values.put("homeVisible", setting.getHomeVisible());
        values.put("TagVisible", setting.getTagVisible());

        long count = database.insert(tableName, null, values);
        database.close();
        return count;
    }

    public long upDateSetting(Setting setting){
        SQLiteDatabase database = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("nameVisible", setting.getNameVisible());
        values.put("genderVisible", setting.getGenderVisible());
        values.put("bornDateVisible", setting.getBornDateVisible());
        values.put("homeVisible", setting.getHomeVisible());
        values.put("TagVisible", setting.getTagVisible());

        int count = database.update(tableName, values, "_id=?", new String[]{String.valueOf(setting.getId())});
        database.close();
        return count;
    }

    public Setting searchSetting(int id){
        SQLiteDatabase database = getWritableDatabase();
        Cursor data = database.query(tableName, null, "_id =?",  new String[]{""+id}, null, null, null);
        Setting setting = new Setting();
        if(data.getCount() > 0){
            data.moveToFirst();
            setting.setId(data.getInt(0));
            setting.setNameVisible(data.getInt(1));
            setting.setGenderVisible(data.getInt(2));
            setting.setBornDateVisible(data.getInt(3));
            setting.setHomeVisible(data.getInt(4));
            setting.setTagVisible(data.getInt(5));

        }
        database.close();
        return setting;
    }
}
