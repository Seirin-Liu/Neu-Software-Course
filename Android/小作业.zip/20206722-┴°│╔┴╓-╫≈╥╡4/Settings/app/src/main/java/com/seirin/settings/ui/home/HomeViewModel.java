package com.seirin.settings.ui.home;

import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.seirin.settings.MainActivity;
import com.seirin.settings.Setting;
import com.seirin.settings.SettingDao;
import com.seirin.settings.User;
import com.seirin.settings.UserDao;
import com.seirin.settings.adapter.Infor;
import com.seirin.settings.R;

import java.util.ArrayList;
import java.util.Arrays;

public class HomeViewModel extends ViewModel {


    private  static MutableLiveData<ArrayList<Infor>> inforList =new MutableLiveData<>();
    private  static MutableLiveData<ArrayList<String>> tagList = new MutableLiveData<>();
    private  static MutableLiveData<String> headId = new MutableLiveData<>();
    private  static MutableLiveData<Boolean> tagVisible = new MutableLiveData<>();
    private  static MutableLiveData<User> loginUser = new MutableLiveData<>();
    private  static MutableLiveData<Setting> loginUserSetting = new MutableLiveData<>();
    private  static UserDao userDao;
    private  static SettingDao settingDao;

    public HomeViewModel() {

        tagVisible.setValue(true);
    }


    public static LiveData<ArrayList<Infor>> getInforList(){ return inforList;}

    public static LiveData<ArrayList<String>> getTagList(){ return tagList;}

    public static LiveData<String> getHeadId(){ return headId;}

    public static LiveData<Boolean> getTagVisible(){ return tagVisible;}

    public static void setData(ArrayList<Infor> infors, ArrayList<String> tags, String head){
        inforList.setValue(infors);
        tagList.setValue(tags);
        headId.setValue(head);
    }

    public static void setData(ArrayList<Infor> infors, ArrayList<String> tags){
        inforList.setValue(infors);
        tagList.setValue(tags);
    }

    public static void setData(ArrayList<Infor> infors,boolean tagVis){
        inforList.setValue(infors);
        tagVisible.setValue(tagVis);
    }

    public static void setUserDate(User user,Setting setting){
        loginUser.setValue(user);
        loginUserSetting.setValue(setting);

        inforList.setValue(new ArrayList<Infor>());
        Infor infor = new Infor("昵称", user.getName(), R.drawable.tag,setting.getNameVisible()!=0);
        inforList.getValue().add(infor);
        Infor infor1 = new Infor("性别", user.getGender(), R.drawable.tag,setting.getGenderVisible()!=0);
        inforList.getValue().add(infor1);
        Infor infor2 = new Infor("出生日期", user.getBornDate(), R.drawable.tag,setting.getBornDateVisible()!=0);
        inforList.getValue().add(infor2);
        Infor infor3 = new Infor("家乡", user.getHome(), R.drawable.tag,setting.getHomeVisible()!=0);
        inforList.getValue().add(infor3);

        tagVisible.setValue(setting.getTagVisible()!=0);
        Log.i("aaaa", 1+" "+String.valueOf(getTagVisible().getValue()));

        if (!user.getTags().equals("无")){
            String [] tags = user.getTags().split(",");
            Log.i("aaaa", String.valueOf(tags));
            tagList.setValue(new ArrayList<String>(Arrays.asList(tags)));
        }
        else {
            tagList.setValue(new ArrayList<String>());
        }

        headId.setValue(user.getHead());

    }

    public static void  updateUser(){

        User user = loginUser.getValue();
        user.setName(inforList.getValue().get(0).getContent());
        user.setGender(inforList.getValue().get(1).getContent());
        user.setBornDate(inforList.getValue().get(2).getContent());
        user.setHome(inforList.getValue().get(3).getContent());

        String tags="";
        for (String s : tagList.getValue()){
            tags +=s+",";
        }
        user.setTags(tags);
        user.setHead(headId.getValue());

        Setting setting =loginUserSetting.getValue();
        setting.setNameVisible(inforList.getValue().get(0).isVisible()? 1:0 );
        setting.setGenderVisible(inforList.getValue().get(1).isVisible()? 1:0 );
        setting.setBornDateVisible(inforList.getValue().get(2).isVisible()? 1:0 );
        setting.setHomeVisible(inforList.getValue().get(3).isVisible()? 1:0 );
        setting.setTagVisible(tagVisible.getValue()? 1:0 );
        userDao.updateUser(user);
        settingDao.upDateSetting(setting);


    }
    public  static  void setUserDao(UserDao auserDao){
        userDao =auserDao;
    }
    public  static  void setSettingDao(SettingDao asettingDao){
        settingDao =asettingDao;
    }

}