package com.seirin.settings.adapter;

public class Item {

    private String name;
    private int icoId;

    public Item(String name) {
        this.name = name;
    }

    public Item(String name, int icoId) {
        this.name = name;
        this.icoId = icoId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getIcoId() {
        return icoId;
    }

    public void setIcoId(int icoId) {
        this.icoId = icoId;
    }
}
