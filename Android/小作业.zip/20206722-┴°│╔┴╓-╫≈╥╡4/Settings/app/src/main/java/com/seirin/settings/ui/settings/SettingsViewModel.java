package com.seirin.settings.ui.settings;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.seirin.settings.adapter.Item;
import com.seirin.settings.R;

import java.util.ArrayList;

public class SettingsViewModel extends ViewModel {
    // TODO: Implement the ViewModel

    private  MutableLiveData<ArrayList<Item>> settingsList = new MutableLiveData<>();

    public SettingsViewModel() {
        settingsList.setValue(new ArrayList<Item>());
        settingsList.getValue().add(new Item("修改个人信息", R.drawable.person));
        settingsList.getValue().add(new Item("修改隐私",R.drawable.secuity_ico));
        settingsList.getValue().add(new Item("修改软件主题",R.drawable.theme_ico));
        settingsList.getValue().add(new Item("修改账户信息",R.drawable.account_ico));
        settingsList.getValue().add(new Item("其他设置",R.drawable.other_ico));
        settingsList.getValue().add(new Item("帮助",R.drawable.help_ico));



    }

    public LiveData<ArrayList<Item>> getSettingsList(){ return settingsList;}



}