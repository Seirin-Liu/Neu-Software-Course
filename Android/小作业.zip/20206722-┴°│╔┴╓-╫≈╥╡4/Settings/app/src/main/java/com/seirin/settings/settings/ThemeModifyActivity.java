package com.seirin.settings.settings;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.widget.CompoundButton;
import android.widget.Switch;

import com.seirin.settings.R;
import com.seirin.settings.utils.ToastUtil;

public class ThemeModifyActivity extends AppCompatActivity {


    Switch deepSwitch;
    Switch reverseSwitch;
    Switch englishSwitch;
    Switch bigSwitch;

    private SharedPreferences pref;
    private SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_theme_modify);

        deepSwitch = findViewById(R.id.deep);
        reverseSwitch = findViewById(R.id.reverse);
        englishSwitch = findViewById(R.id.english);
        bigSwitch = findViewById(R.id.big);

        pref = PreferenceManager.getDefaultSharedPreferences(this);


        deepSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    ToastUtil.showMsg(ThemeModifyActivity.this,"切换为深色模式啦！");
                    editor = pref.edit();
                    editor.putBoolean("deepModel",true);
                    editor.apply();
                }
            }
        });
        reverseSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    ToastUtil.showMsg(ThemeModifyActivity.this,"切换为负色模式啦！");
                    editor = pref.edit();
                    editor.putBoolean("reverseModel",true);
                    editor.apply();
                }
            }
        });
        englishSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    ToastUtil.showMsg(ThemeModifyActivity.this,"切换为英文模式啦！");
                    editor = pref.edit();
                    editor.putBoolean("englishModel",true);
                    editor.apply();
                }
            }
        });
        bigSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    ToastUtil.showMsg(ThemeModifyActivity.this,"切换为大字体模式啦！");
                    editor = pref.edit();
                    editor.putBoolean("bigModel",true);
                    editor.apply();
                }
            }
        });

        init();


    }

    public void init(){
        if(pref.getBoolean("deepModel",false)){
            deepSwitch.setChecked(true);
        }
        if(pref.getBoolean("reverseModel",false)){
            reverseSwitch.setChecked(true);
        }
        if(pref.getBoolean("englishModel",false)){
            englishSwitch.setChecked(true);
        }
        if(pref.getBoolean("bigModel",false)){
            bigSwitch.setChecked(true);
        }

    }






}