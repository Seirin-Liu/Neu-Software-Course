package com.seirin.settings.adapter;

public class Infor {
    private  String tagName;
    private  String content;
    private  int icoId;
    private  boolean visible = true;

    public Infor(String tag, String content, int icoId) {
        this.tagName = tag;
        this.content = content;
        this.icoId = icoId;
    }

    public Infor(String tagName, String content, int icoId, boolean visible) {
        this.tagName = tagName;
        this.content = content;
        this.icoId = icoId;
        this.visible = visible;
    }

    public boolean isVisible() {
        return visible;
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }

    public String getTagName() {
        return tagName;
    }

    public void setTagName(String tagName) {
        this.tagName = tagName;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getIcoId() {
        return icoId;
    }

    public void setIcoId(int icoId) {
        this.icoId = icoId;
    }
}
