package com.seirin.settings.settings;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.media.MediaMetadataCompat;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.seirin.settings.R;
import com.seirin.settings.utils.DialogUtil;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class AccountModifyActivity extends AppCompatActivity {

    private String password;

    private SharedPreferences pref;
    private SharedPreferences.Editor editor;

    private EditText initialPassword;
    private EditText newPassword;
    TextView remindText1;
    TextView remindText2;
    Button completeButton;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_modify);
        pref = PreferenceManager.getDefaultSharedPreferences(this);

        password = pref.getString("password","");
        dialog();


        Log.i("aaaa",password);

        initialPassword=findViewById(R.id.initial_password);
        newPassword = findViewById(R.id.new_password);
        remindText1= findViewById(R.id.remind_text1);
        remindText2= findViewById(R.id.remind_text2);
        completeButton = findViewById(R.id.complete_button);


        initialPassword.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                if(!charSequence.toString().equals(password)){
                }
                else{
                    remindText1.setTextColor(Color.RED);
                    remindText1.setText("密码与原密码一致，请更换密码");
                }
            }
            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        newPassword.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                if(!charSequence.toString().equals(initialPassword.getText().toString())){
                    remindText2.setTextColor(Color.RED);
                    remindText2.setText("俩次密码不一致");

                }
                else{
                    remindText2.setTextColor(Color.GREEN);
                    remindText2.setText("俩次密码一致");
                }
            }
            @Override
            public void afterTextChanged(Editable editable) {
            }
        });

        completeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (initialPassword.getText().toString().length()>0&&initialPassword.getText().toString().equals(newPassword.getText().toString())){
                    editor=pref.edit();
                    editor.putString("password",newPassword.getText().toString());
                    editor.apply();
                    DialogUtil.showDialog(AccountModifyActivity.this,"修改成功");

                }
                else {
                    DialogUtil.showDialog(AccountModifyActivity.this,"密码格式错误，修改失败");
                }
            }
        });



    }

    public void dialog() {
        final Dialog dlg = new Dialog(AccountModifyActivity.this, R.style.dialog);
        dlg.show();
        dlg.getWindow().setGravity(Gravity.CENTER);
        dlg.getWindow().setLayout((int) (getWindowManager().getDefaultDisplay().getWidth() * 0.8), android.view.WindowManager.LayoutParams.WRAP_CONTENT);
        dlg.getWindow().setContentView(R.layout.setting_add_tags_dialg);
        TextView dialg_title = dlg.findViewById(R.id.add_tag_dialg_title);
        final EditText dialg_content = dlg.findViewById(R.id.add_tag_dialg_content);
        TextView dialg_no =dlg.findViewById(R.id.add_tag_dialg_no);
        TextView dialg_ok =dlg.findViewById(R.id.add_tag_dialg_ok);
        dialg_title.setText("请输入原密码：");
        dialg_no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dlg.dismiss();
                finish();
            }
        });
        dialg_ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InputMethodManager imm = (InputMethodManager) AccountModifyActivity.this.getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.toggleSoftInput(InputMethodManager.SHOW_IMPLICIT, InputMethodManager.HIDE_NOT_ALWAYS);
                if(dialg_content.getText().toString().length()>0)
                {
                    if(dialg_content.getText().toString().equals(password)){
                        dlg.dismiss();
                    }
                    else{
                        DialogUtil.showDialog(AccountModifyActivity.this,"密码错误");
                    }

                }
                else{

                    dlg.dismiss();
                    finish();
                }

            }
        });
    }



}