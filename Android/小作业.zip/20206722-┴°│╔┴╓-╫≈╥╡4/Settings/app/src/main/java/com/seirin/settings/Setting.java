package com.seirin.settings;

public class Setting {

    private int id;
    private int nameVisible;
    private int genderVisible;
    private int bornDateVisible;
    private int homeVisible;
    private int TagVisible;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getNameVisible() {
        return nameVisible;
    }

    public void setNameVisible(int nameVisible) {
        this.nameVisible = nameVisible;
    }

    public int getGenderVisible() {
        return genderVisible;
    }

    public void setGenderVisible(int genderVisible) {
        this.genderVisible = genderVisible;
    }

    public int getBornDateVisible() {
        return bornDateVisible;
    }

    public void setBornDateVisible(int bornDateVisible) {
        this.bornDateVisible = bornDateVisible;
    }

    public int getHomeVisible() {
        return homeVisible;
    }

    public void setHomeVisible(int homeVisible) {
        this.homeVisible = homeVisible;
    }

    public int getTagVisible() {
        return TagVisible;
    }

    public void setTagVisible(int tagVisible) {
        TagVisible = tagVisible;
    }


    public Setting() {
        nameVisible = 1;
        genderVisible = 1;
        bornDateVisible = 1;
        homeVisible = 1;
        TagVisible = 1;

    }
}
