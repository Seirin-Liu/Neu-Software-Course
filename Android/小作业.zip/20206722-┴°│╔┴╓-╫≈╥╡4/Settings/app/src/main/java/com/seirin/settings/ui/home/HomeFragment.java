package com.seirin.settings.ui.home;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.seirin.settings.view.FlowLayout;
import com.seirin.settings.adapter.Infor;
import com.seirin.settings.adapter.InforAdapter;
import com.seirin.settings.R;
import com.seirin.settings.databinding.FragmentHomeBinding;

import java.io.File;
import java.util.ArrayList;

public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;

    private FlowLayout tag_vessel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {


        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        ImageView imageView=binding.imageView;
        if (!HomeViewModel.getHeadId().getValue().equals("default")){
            imageView.setImageURI(Uri.fromFile(new File(HomeViewModel.getHeadId().getValue())));}
        else{
            imageView.setImageResource(R.drawable.head);
        }

        ListView listView = binding.list;
        ArrayList<Infor> infors =HomeViewModel.getInforList().getValue();
        InforAdapter adapter = new InforAdapter(container.getContext(),R.layout.list_item, infors);
        listView.setAdapter(adapter);


        tag_vessel = binding.tagvessel;
        showTags(HomeViewModel.getTagVisible().getValue());
        Log.i("aaaa", String.valueOf(HomeViewModel.getTagVisible().getValue()));



        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    /**
     * 添加标签
     * @param tag
     * @param i
     */
    @SuppressLint("NewApi")
    public void AddTag(String tag, int i) {
        final TextView mTag = new TextView(getContext());
        mTag.setText(" "+tag+" ");
        mTag.setGravity(Gravity.CENTER);
        mTag.setTextSize(25);
//        mTag.setBackground(getResources().getDrawable(R.drawable.img).);
        mTag.setBackgroundResource(R.drawable.text);
        mTag.setTextColor(Color.WHITE);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, 80);//标签的高度
        params.setMargins(20, 10, 0, 10);

        tag_vessel.addView(mTag, i, params);

    }

    public void showTags( boolean visible){
        Log.i("aaaa","show");
        if(visible) {
            int i = 0;
            for (String s : HomeViewModel.getTagList().getValue()) {
                AddTag(s, i);
                i++;
            }
        }
        else{
            final TextView mTag = new TextView(getContext());
            mTag.setText("  标签已隐藏  ");
            mTag.setGravity(Gravity.CENTER);
            mTag.setTextSize(25);
            mTag.setBackgroundColor(Color.RED);
            mTag.setTextColor(Color.WHITE);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, 80);//标签的高度
            params.setMargins(20, 10, 0, 10);

            tag_vessel.addView(mTag, 0, params);
        }
    }



}