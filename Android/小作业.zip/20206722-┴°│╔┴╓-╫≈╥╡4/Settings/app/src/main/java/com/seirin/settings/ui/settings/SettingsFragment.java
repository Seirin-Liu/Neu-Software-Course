package com.seirin.settings.ui.settings;

import androidx.lifecycle.ViewModelProvider;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import com.seirin.settings.adapter.Item;
import com.seirin.settings.adapter.ItemAdapter;
import com.seirin.settings.R;
import com.seirin.settings.databinding.SettingsFragmentBinding;
import com.seirin.settings.settings.AccountModifyActivity;
import com.seirin.settings.settings.InforModifyActivity;
import com.seirin.settings.settings.PrivateModifyActivity;
import com.seirin.settings.settings.ThemeModifyActivity;

import java.util.ArrayList;


public class SettingsFragment extends Fragment {

    private SettingsFragmentBinding binding;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        SettingsViewModel settingsViewModel =
                new ViewModelProvider(getActivity()).get(SettingsViewModel.class);

        binding = SettingsFragmentBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        ListView settingsList = binding.settingsList;
        ArrayList<Item> settings =settingsViewModel.getSettingsList().getValue();
        ItemAdapter adapter = new ItemAdapter(container.getContext(),R.layout.setting_item,settings );
        settingsList.setAdapter(adapter);

        settingsList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                switch (position){
                    case 0:

                        Intent intent = new Intent(getContext(), InforModifyActivity.class);
                        startActivity(intent);
                        break;
                    case 1:

                        Intent intent1 = new Intent(getContext(), PrivateModifyActivity.class);
                        startActivity(intent1);
                        break;
                    case 2:
                        Intent intent2 = new Intent(getContext(), ThemeModifyActivity.class);
                        startActivity(intent2);
                        break;

                    case 3:
                        Intent intent3 = new Intent(getContext(), AccountModifyActivity.class);
                        startActivity(intent3);
                        break;
                }
            }
        });

        return root;

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

//    private void replaceFragment(Fragment fragment){
//        //先获得主界面，再获得主界面的FragmentManager
//        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
//        FragmentTransaction transaction = fragmentManager.beginTransaction();
//        transaction.replace(R.id.nav_host_fragment_activity_main,fragment);
//        transaction.commit();
//    }




}