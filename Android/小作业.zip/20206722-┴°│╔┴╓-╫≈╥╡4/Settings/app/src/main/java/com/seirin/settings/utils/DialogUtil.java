package com.seirin.settings.utils;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;

import com.seirin.settings.settings.AccountModifyActivity;

public class DialogUtil {
     static AlertDialog.Builder dialog;
    public static void showDialog(Context context,String msg){
        dialog = new AlertDialog.Builder(context);
        dialog.setTitle("提示");
        dialog.setMessage(msg);
        dialog.setCancelable(false);
        dialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        dialog.show();
    }
}
