package com.seirin.settings;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

public class TestActivity extends AppCompatActivity {

    private SharedPreferences pref;
    private SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);

        Button button = findViewById(R.id.add_button);
        Button button1 = findViewById(R.id.delete_button);
        Button button3 = findViewById(R.id.query_button);
        Button button2 = findViewById(R.id.reset_button);

        TextView textView = findViewById(R.id.textView);
        ListView listView = findViewById(R.id.listView);
        EditText account = findViewById(R.id.editTextAccount);
        EditText password = findViewById(R.id.editTextPassword);

        pref =  PreferenceManager.getDefaultSharedPreferences(this);

        UserDao userDao =new UserDao(this);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                User user =new User(account.getText().toString(),password.getText().toString());
                userDao.insertUser(user);

            }
        });

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SQLiteDatabase database = userDao.getReadableDatabase();
                Cursor cursor = database.rawQuery("select * from users", null);
//                String str = "";
//                while(cursor.moveToNext()){
//                    String id = cursor.getString(cursor.getColumnIndex("_id"));
//                    String name = cursor.getString(cursor.getColumnIndex("name"));
//                    String author = cursor.getString(cursor.getColumnIndex("author"));
//                    String duration = cursor.getString(cursor.getColumnIndex("duration"));
//                    str += "ID:" + id
//                            + "; Name:" + name
//                            + "; Author:" + author
//                            + "; Duration:" + duration
//                            + ";\n";
//                }
//                result.setText(str);
                String from[] = {"account","name","gender","born_date","home","setting_id"};
                int to[] = {R.id.t1,R.id.t2,R.id.t3,R.id.t4,R.id.t5,R.id.t6};
                SimpleCursorAdapter adapter = new SimpleCursorAdapter(TestActivity.this, R.layout.item, cursor, from , to);
                listView.setAdapter(adapter);
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editor=pref.edit();
                editor.putBoolean("deepModel",false);
                editor.putBoolean("reverseModel",false);
                editor.putBoolean("englishModel",false);
                editor.putBoolean("bigModel",false);

            }
        });



    }
}