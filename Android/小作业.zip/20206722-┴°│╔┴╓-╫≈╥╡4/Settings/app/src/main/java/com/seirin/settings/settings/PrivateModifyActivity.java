package com.seirin.settings.settings;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.Switch;

import com.seirin.settings.adapter.Infor;
import com.seirin.settings.R;
import com.seirin.settings.ui.home.HomeViewModel;

import java.util.ArrayList;

public class PrivateModifyActivity extends AppCompatActivity {

    Switch nameSwitch;
    Switch genderSwitch;
    Switch bornSwitch;
    Switch homeSwitch;
    Switch tagSwitch;

    private ArrayList<Infor> infors;
    private boolean tagVisible;

    ArrayList<Boolean> ables = new ArrayList<Boolean>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_private_modify);

        overridePendingTransition(R.anim.slide_in_left,
                R.anim.slide_out_righ);

        nameSwitch =findViewById(R.id.deep);
        genderSwitch= findViewById(R.id.gender_switch);
        bornSwitch = findViewById(R.id.born_switch);
        homeSwitch  = findViewById(R.id.home_switch);
        tagSwitch = findViewById(R.id.tag_switch);

        nameSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b){
                   ables.set(0,true);
                }
                else{
                    ables.set(0,false);
                }
            }
        });
        genderSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b){
                    ables.set(1,true);
                }
                else{
                    ables.set(1,false);
                }
            }
        });
        bornSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b){
                    ables.set(2,true);
                }
                else{
                    ables.set(2,false);
                }
            }
        });
        homeSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b){
                    ables.set(3,true);
                }
                else{
                    ables.set(3,false);
                }
            }
        });
        tagSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b){
                    tagVisible=true;
                }
                else{
                    tagVisible=false;
                }
            }
        });

        init();

    }

    public void init(){
        infors = HomeViewModel.getInforList().getValue();
        tagVisible = HomeViewModel.getTagVisible().getValue();

        for (Infor i:infors){
            ables.add(i.isVisible());
        }
        nameSwitch.setChecked(ables.get(0));
        genderSwitch.setChecked(ables.get(1));
        bornSwitch.setChecked(ables.get(2));
        homeSwitch.setChecked(ables.get(3));
        tagSwitch.setChecked(tagVisible);

    }

    public void save(){
        int i= 0;
        for(Infor infor:infors){
            infor.setVisible(ables.get(i));
            i++;
        }
        HomeViewModel.setData(infors,tagVisible);
        HomeViewModel.updateUser();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        save();
    }

}