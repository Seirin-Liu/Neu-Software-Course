package com.seirin.homework1;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ImageView im;
    TextView tv;
    Button button;
    ProgressBar pro;


    int i = 0;
    ArrayList<Integer> images=new ArrayList<>();
    ArrayList<String> names=new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        im=findViewById(R.id.imageView);
        tv = findViewById(R.id.textView);
        button= findViewById(R.id.button);
        pro = findViewById(R.id.progressBar);

        init();


        im.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                nextImage();
            }
        });
        tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                nextImage();
            }
        });
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                nextImage();

            }
        });


    }

    public void nextImage(){
        i=(i+1)%images.size();
        im.setImageResource(images.get(i));
        tv.setText(names.get(i));
        pro.setProgress((int)(100*(i+1)/images.size()));
        Toast.makeText(MainActivity.this, "NextImage", Toast.LENGTH_SHORT).show();

    }
    public void init(){

        im.setImageResource(R.drawable.apple1);
        tv.setText("apple");


        images.add(R.drawable.apple1);
        images.add(R.drawable.banana);
        images.add(R.drawable.grape);
        images.add(R.drawable.orange);
        images.add(R.drawable.cherry);
        images.add(R.drawable.coconut);
        images.add(R.drawable.lemon);

        names.add("apple");
        names.add("banana");
        names.add("grape");
        names.add("orange");
        names.add("cherry");
        names.add("coconut");
        names.add("lemon");
        pro.setProgress((int)(100/images.size()));

    }

}