package com.seirin.homwork2;

public class Infor {
    private  String tagName;
    private  String content;
    private  int icoId;

    public Infor(String tag, String content, int icoId) {
        this.tagName = tag;
        this.content = content;
        this.icoId = icoId;
    }

    public String getTagName() {
        return tagName;
    }

    public void setTagName(String tagName) {
        this.tagName = tagName;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getIcoId() {
        return icoId;
    }

    public void setIcoId(int icoId) {
        this.icoId = icoId;
    }
}
