package com.seirin.homwork2;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.icu.util.Calendar;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class ModifyActivity extends AppCompatActivity implements DatePickerDialog.OnDateSetListener {

    private EditText editName;
    private ImageView dateButton;
    private TextView bornDate;
    private ImageView portrait;
    private Button completeButton;
    private RadioGroup sexGroup;
    private EditText editHome;
    private Button portraitButton;

    FlowLayout tag_vessel;
    ImageView add_tag;
    List<String> tagList;
    int screenWidth = 0;

    ArrayList<Integer> images=new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modify);
        init();
        dateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                initCalender();
            }
        });
        completeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intentResult();
                overridePendingTransition(R.anim.slide_in_left,
                        R.anim.slide_out_righ);
            }
        });
        portraitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            changePortrait();
            }
        });


    }

    /**
     * 加载初始值，从主页面传递到的值
     */
    public void init(){
        editName =findViewById(R.id.editName);
        dateButton= findViewById(R.id.dateButton);
        bornDate=findViewById(R.id.bornDate);
        completeButton=findViewById(R.id.completeButton);
        dateButton.setImageResource(R.drawable.calender);
        portrait =findViewById(R.id.portrait);

        sexGroup= findViewById(R.id.sexGroup);
        editHome=findViewById(R.id.editHome);
        portraitButton=findViewById(R.id.portraitButton);

        editName.setText(getIntent().getStringExtra("用户名"));
        bornDate.setText(getIntent().getStringExtra("出生日期"));
        portrait.setImageResource(getIntent().getIntExtra("portraitId",0));
        switch(getIntent().getStringExtra("性别")){
            case "男":
                RadioButton radioButton =findViewById(R.id.man);
                radioButton.setChecked(true);
                break;
            case "女":
                RadioButton radioButton1 =findViewById(R.id.fale);
                radioButton1.setChecked(true);
                break;
            case "未知":
                RadioButton radioButton2 =findViewById(R.id.none);
                radioButton2.setChecked(true);
                break;
            default:
                break;
        }
        editHome.setText(getIntent().getStringExtra("家乡"));

        screenWidth = getWindowManager().getDefaultDisplay().getWidth(); // 屏幕宽（像素
        tag_vessel = (FlowLayout) findViewById(R.id.tagvessel);
        add_tag = (ImageView) findViewById(R.id.add_tag);
        add_tag.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AddTagDialog();
            }
        });


        tagList = getIntent().getStringArrayListExtra("个人标签");

        int i= 0;
        for (String s: tagList){
            AddTag(s,i);
            i++;
        }

        images.add(R.drawable.person);
        images.add(R.drawable.img_1);
        images.add(R.drawable.img);
        images.add(R.drawable.img_2);
        images.add(R.drawable.img_3);
        images.add(R.drawable.img_4);
        images.add(R.drawable.img_5);
        images.add(R.drawable.img_6);
        images.add(R.drawable.img_7);
        images.add(R.drawable.img_8);
        images.add(R.drawable.img_9);
        images.add(R.drawable.img_10);
        images.add(R.drawable.img_11);
        images.add(R.drawable.img_12);
        images.add(R.drawable.img_13);


    }

    @Override
    public void onDateSet(DatePicker datePicker, int year, int month, int day) {
        String date = String.format("%d-%d-%d",year,month+1,day);
        bornDate.setText(date);

    }

    public void initCalender(){
        Calendar calendar = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            calendar = Calendar.getInstance();
        }
        DatePickerDialog dialog = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            dialog = new DatePickerDialog(ModifyActivity.this,ModifyActivity.this,

                    calendar.get(Calendar.YEAR),
                    calendar.get(Calendar.MARCH),
                    calendar.get(Calendar.DAY_OF_MONTH));
        }
        dialog.show();
    }



    /**
     * 添加标签的对话框
     */
    public void AddTagDialog() {
        final Dialog dlg = new Dialog(ModifyActivity.this, R.style.dialog);
        dlg.show();
        dlg.getWindow().setGravity(Gravity.CENTER);
        dlg.getWindow().setLayout((int) (screenWidth * 0.8), android.view.WindowManager.LayoutParams.WRAP_CONTENT);
        dlg.getWindow().setContentView(R.layout.setting_add_tags_dialg);
        TextView add_tag_dialg_title = (TextView) dlg.findViewById(R.id.add_tag_dialg_title);
        final EditText add_tag_dialg_content = (EditText) dlg.findViewById(R.id.add_tag_dialg_content);
        TextView add_tag_dialg_no = (TextView) dlg.findViewById(R.id.add_tag_dialg_no);
        TextView add_tag_dialg_ok = (TextView) dlg.findViewById(R.id.add_tag_dialg_ok);
        add_tag_dialg_title.setText("添加个人标签");
        add_tag_dialg_no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dlg.dismiss();
            }
        });
        add_tag_dialg_ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //
                InputMethodManager imm = (InputMethodManager) ModifyActivity.this.getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.toggleSoftInput(InputMethodManager.SHOW_IMPLICIT, InputMethodManager.HIDE_NOT_ALWAYS);

                tagList.add(add_tag_dialg_content.getText().toString());
                AddTag(tagList.get(tagList.size() - 1), tagList.size() - 1);
                dlg.dismiss();
            }
        });
    }

    /**
     * 添加标签
     * @param tag
     * @param i
     */
    @SuppressLint("NewApi")
    public void AddTag(String tag, int i) {
        final TextView mTag = new TextView(ModifyActivity.this);
        mTag.setText(" "+tag+" ");
        mTag.setGravity(Gravity.CENTER);
        mTag.setTextSize(18);
//        mTag.setBackground(getResources().getDrawable(R.drawable.img).);
        mTag.setBackgroundColor(getResources().getColor(R.color.teal_200));
        mTag.setTextColor(Color.WHITE);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, 80);
        params.setMargins(20, 20, 0, 10);

        tag_vessel.addView(mTag, i, params);

        mTag.setOnLongClickListener(new View.OnLongClickListener() {

            @Override
            public boolean onLongClick(View v) {
                // 长按标签删除操作
                final AlertDialog dlg = new AlertDialog.Builder(ModifyActivity.this).create();
                dlg.show();
                dlg.getWindow().setGravity(Gravity.CENTER);
                dlg.getWindow().setLayout((int) (screenWidth * 0.8), android.view.WindowManager.LayoutParams.WRAP_CONTENT);
                dlg.getWindow().setContentView(R.layout.setting_add_tags_dialg);
                TextView add_tag_dialg_title = (TextView) dlg.findViewById(R.id.add_tag_dialg_title);
                EditText add_tag_dialg_content = (EditText) dlg.findViewById(R.id.add_tag_dialg_content);
                TextView add_tag_dialg_no = (TextView) dlg.findViewById(R.id.add_tag_dialg_no);
                TextView add_tag_dialg_ok = (TextView) dlg.findViewById(R.id.add_tag_dialg_ok);
                add_tag_dialg_title.setText("标签删除确认");
                add_tag_dialg_content.setText("您确定要删除“" + mTag.getText().toString() + "”这个标签吗？");
                add_tag_dialg_no.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dlg.dismiss();
                    }
                });
                add_tag_dialg_ok.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        tag_vessel.removeView(mTag);
                        for (int j = 0; j < tagList.size(); j++) {
                            Log.v("==", mTag.getText().toString() + "==" + tagList.get(j).toString());
                            if (mTag.getText().toString().replaceAll(" ", "")
                                    .equals(tagList.get(j).toString().replaceAll(" ", ""))) {
                                tagList.remove(j);
                            }
                        }
                        dlg.dismiss();
                    }
                });

                return true;
            }
        });
    }

    public void  changePortrait(){

        int image=images.get(new Random().nextInt(images.size()));
        portrait.setImageResource(image);
        portrait.setTag(image);
    }

    /**
     * 完成修改，回调
     */
    public void intentResult(){
        Intent intent =new Intent(ModifyActivity.this,MainActivity.class);
        intent.putExtra("用户名",editName.getText().toString());
        intent.putExtra("性别",((RadioButton)findViewById(sexGroup.getCheckedRadioButtonId())).getText().toString());
        intent.putExtra("家乡",editHome.getText().toString());
        intent.putExtra("出生日期",bornDate.getText().toString());
        intent.putExtra("portraitId",(Integer) portrait.getTag());
        intent.putStringArrayListExtra("个人标签",(ArrayList<String>) tagList);
        setResult(RESULT_OK,intent);

        finish();
    }


}