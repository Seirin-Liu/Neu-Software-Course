package com.seirin.homwork2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class TagAdapter extends ArrayAdapter<Infor> {
    private int resourceId;

    public TagAdapter(@NonNull Context context, int textViewResourceId, @NonNull List<Infor> objects) {
        super(context, textViewResourceId, objects);
        resourceId = textViewResourceId;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        Infor infor =getItem(position);
        View view = LayoutInflater.from(getContext()).inflate(resourceId,parent,false);

        ImageView icoImage = view.findViewById(R.id.sicon);
        TextView tagName = view.findViewById(R.id.infor1);
        TextView Content = view.findViewById(R.id.content);
        icoImage.setImageResource(infor.getIcoId());

        tagName.setText(infor.getTagName()+":");
        Content.setText(infor.getContent());

        return view;
    }
}
