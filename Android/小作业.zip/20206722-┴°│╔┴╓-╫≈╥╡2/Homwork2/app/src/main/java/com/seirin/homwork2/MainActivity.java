package com.seirin.homwork2;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

//用户名
//性别
//出生日期
//家乡
//个人标签

public class MainActivity extends AppCompatActivity {

    private List<Infor> inforList = new ArrayList<>();
    ImageView imageView;
    Button modifyButton;

    FlowLayout tag_vessel;
    List<String> tagList = new ArrayList<String>();
    int screenWidth = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView= findViewById(R.id.imageView);
        imageView.setImageResource(R.drawable.person);
        imageView.setTag(R.drawable.person);

        screenWidth = getWindowManager().getDefaultDisplay().getWidth();
        tag_vessel =  findViewById(R.id.tagvessel);

        modifyButton= findViewById(R.id.button);

        init();

        modifyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                modify();
                overridePendingTransition(R.anim.slide_in_left,
                        R.anim.slide_out_righ);
            }
        });



        TagAdapter adapter = new TagAdapter(MainActivity.this,R.layout.list_item, inforList);
        ListView listView = findViewById(R.id.list);
        listView.setAdapter(adapter);



    }

    public void init() {
        Infor infor = new Infor("用户名", "Seirin", R.drawable.tag);
        inforList.add(infor);
        Infor infor1 = new Infor("性别", "男", R.drawable.tag);
        inforList.add(infor1);
        Infor infor2 = new Infor("出生日期", "2022-3-1", R.drawable.tag);
        inforList.add(infor2);
        Infor infor3 = new Infor("家乡", "山西太原", R.drawable.tag);
        inforList.add(infor3);

        tagList.add("摸鱼能手");
        tagList.add("天然呆");
        int i= 0;
        for (String s:tagList){
            AddTag(s,i);
            i++;
        }
    }




    /**
     * 添加标签
     * @param tag
     * @param i
     */
    @SuppressLint("NewApi")
    public void AddTag(String tag, int i) {
        final TextView mTag = new TextView(MainActivity.this);
        mTag.setText(" "+tag+" ");
        mTag.setGravity(Gravity.CENTER);
        mTag.setTextSize(18);
//        mTag.setBackground(getResources().getDrawable(R.drawable.img).);
        mTag.setBackgroundColor(getResources().getColor(R.color.teal_200));
        mTag.setTextColor(Color.WHITE);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, 80);
        params.setMargins(20, 20, 0, 10);

        tag_vessel.addView(mTag, i, params);

    }


    public void modify(){
        Intent intent =new Intent(MainActivity.this,ModifyActivity.class);
        for( Infor infor : inforList){
            intent.putExtra(infor.getTagName(), infor.getContent());
        }

        intent.putStringArrayListExtra("个人标签",(ArrayList<String>) tagList);
        intent.putExtra("portraitId",(Integer) imageView.getTag());
        startActivityForResult(intent,1);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        if(resultCode==RESULT_OK){
            loadModifies(data);
            super.onActivityResult(requestCode, resultCode, data);
        }


    }

    public void loadModifies(Intent intent){
        inforList.get(0).setContent(intent.getStringExtra("用户名"));
        inforList.get(1).setContent(intent.getStringExtra("性别"));
        inforList.get(2).setContent(intent.getStringExtra("出生日期"));
        inforList.get(3).setContent(intent.getStringExtra("家乡"));
        imageView.setImageResource(intent.getIntExtra("portraitId",R.drawable.person));
        imageView.setTag(intent.getIntExtra("portraitId",R.drawable.person));
        TagAdapter adapter = new TagAdapter(MainActivity.this,R.layout.list_item, inforList);
        ListView listView = findViewById(R.id.list);
        listView.setAdapter(adapter);
        tagList = intent.getStringArrayListExtra("个人标签");


        tag_vessel.removeAllViews();//清空所有view
        int i= 0;
        for (String s: tagList){
            AddTag(s,i);
            i++;
        }
    }



}