var empMag = document.getElementById("empMag");
var depMag = document.getElementById("depMag");
var fileMag = document.getElementById("fileMag");
var userMag = document.getElementById("userMag");
var posiMag = document.getElementById("posiMag");