package com.liu.controller;

import com.liu.pojo.Goods;
import com.liu.pojo.Store;
import com.liu.pojo.User;
import com.liu.service.GoodsServiceImpl;
import com.liu.service.StoreServiceImpl;
import com.liu.service.UserServiceImpl;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * 店铺
 */
public class StoreServlet extends HttpServlet {

    private StoreServiceImpl storeService;
    private GoodsServiceImpl goodsService;
    private HttpSession session;
    public StoreServlet(){this.storeService = new StoreServiceImpl();
    this.goodsService= new GoodsServiceImpl();}

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //先拿到当前进行的函数
        session = req.getSession();
        String method = req.getParameter("method");
        System.out.println("StoreSer "+method);
        if (method == null || "storeManage".equals(method)) {
            toStorePage(req,resp);
        }
        /**
         * 添加新商品
         */
        else if ("addStore".equals(method)) {
            addStore(req,resp);
        }
        /**
         * 跳转添加页面
         */
        else if ("toAddStore".equals(method)) {
            toAddStorePage(req,resp);
        }
        /**
         * 打开修改页面
         */
        else if ("updateStorePage".equals(method)) {
            updateStorePage(req,resp);
        }
        else if ("updateStore".equals(method)) {

            updateStore(req,resp);
        }
        else if ("addGoodsToStorePage".equals(method)) {

            addGoodsToStorePage(req,resp);
        }
        else if ("deleteStore".equals(method)) {
            deleteStore(req,resp);
        }

        else if ("search".equals(method)) {
            search(req,resp);
        }
        else if("storeGoodsInfoPage".equals(method)){

            storeGoodsInfoPage(req,resp);
        }

    }


    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req,resp);
    }

    /**
     *获取所有商店
     * @return
     * @throws SQLException
     */
    public List<Store> getStoreList()throws SQLException{
        List<Store> list = null;
        User currentUser = (User) session.getAttribute("USER_SESSION");
        {
            if (currentUser.getLevel() == 3) {
                System.out.println(3);
                list = storeService.getStoreList();
            } else {
                System.out.println(2);
                list = storeService.getStoreList(Integer.parseInt(currentUser.getId()));
            }
            return list;
        }
    }

    /**
     *搜索商店
     * @return
     * @throws SQLException
     */
    public List<Store> searchStoreList(String key)throws SQLException{
        List<Store> list = null;
        User currentUser = (User) session.getAttribute("USER_SESSION");
        {
            if (currentUser.getLevel() == 3) {
                System.out.println(3);
                list = storeService.searchStoreList(key);
            } else {
                System.out.println(2);
                list = storeService.searchStoreList(key,Integer.parseInt(currentUser.getId()));
            }
            return list;
        }
    }


    /**
     * 添加店铺
     * @param req
     * @param resp
     * @throws IOException
     */
    public void addStore(HttpServletRequest req,HttpServletResponse resp) throws  IOException{
        String name = req.getParameter("storeName");
        String description = req.getParameter("description");
        int goodsnum=0;
        int holderId = Integer.parseInt(req.getParameter("holderId"));
        int result = 0;
        try {
            result = storeService.addStore(name,description,goodsnum,holderId);
            if (result>0) {
                List<Store> list = getStoreList();
                session.setAttribute("storeList",list);
                resp.sendRedirect("./jsp/storeManage.jsp");
            } else {
                resp.sendRedirect("./exception/500.jsp");
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    /**
     * 删除店铺
     * @param req
     * @param resp
     * @throws IOException
     */
    private void deleteStore(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        int deleteId = Integer.parseInt(req.getParameter("deleteId"));
        try {

            int result1 = goodsService.deleteGoodsByStoreId(deleteId);
            int result2 = storeService.deleteStore(deleteId);
            if (result1>0&&result2>0) {
                List<Store> list = getStoreList();
                session.setAttribute("storeList",list);
                resp.sendRedirect("./jsp/storeManage.jsp");
            } else {
                resp.sendRedirect("./exception/500.jsp");
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }


    /**
     *
     * @param req
     * @param resp
     * @throws IOException
     */
    private void toStorePage(HttpServletRequest req,HttpServletResponse resp) throws IOException {
        List<Store> list = null;
        try {
            list = getStoreList();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        if (list != null) {
            session.setAttribute("storeList", list);
            resp.sendRedirect("./jsp/storeManage.jsp");
        } else {
            resp.sendRedirect("./exception/500.jsp");
        }
    }

    /**
     * 查询
     * @param req
     * @param resp
     * @throws IOException
     */
    private void search(HttpServletRequest req, HttpServletResponse resp) throws IOException {

        String key = req.getParameter("keyword");
        if (key==null||key.length()==0){
           toStorePage(req,resp);
            return;
        }
        List<Store> list = null;
        try {
            list =searchStoreList(key);
        } catch (SQLException throwable) {
            throwable.printStackTrace();
        }
        if (list != null) {
            session.setAttribute("storeList", list);
            resp.sendRedirect("./jsp/storeManage.jsp");
        } else {
            resp.sendRedirect("./exception/500.jsp");
        }

    }

    /**
     * 跳转添加新店铺页面
     * @param req
     * @param resp
     * @throws IOException
     */
    private void toAddStorePage(HttpServletRequest req,HttpServletResponse resp) throws IOException {
        //当前的所有店铺
        UserServiceImpl userService = new UserServiceImpl();
        List<User>  userList= userService.getUserList(2);
        if (userList != null) {
            session.setAttribute("userList", userList);
            resp.sendRedirect("./jsp/addStore.jsp");
        } else {
            resp.sendRedirect("./exception/500.jsp");
        }
    }

    /**
     * 跳转更新店铺页面
     * @param req
     * @param resp
     * @throws IOException
     */
    private void updateStorePage(HttpServletRequest req,HttpServletResponse resp) throws IOException{
        int updateId = Integer.parseInt(req.getParameter("updateId"));
        try {
            UserServiceImpl userService = new UserServiceImpl();
            List<User>  userList= userService.getUserList(2);
            session.setAttribute("userList",userList);
            Store store = storeService.getStoreById(updateId);
            //传入商品信息
            if (store != null) {
                System.out.println(store);
                session.setAttribute("store",store);
                resp.sendRedirect("./jsp/updateStore.jsp");
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    /**
     * 执行修改店铺
     * @param req
     * @param resp
     * @throws IOException
     */
    private void updateStore(HttpServletRequest req,HttpServletResponse resp)  throws IOException{
        int updateId = Integer.parseInt(req.getParameter("updateId"));
        String name = req.getParameter("storeName");
        String description = req.getParameter("description");
        int goodsnum = Integer.parseInt(req.getParameter("goodsnum"));
        int holderId = Integer.parseInt(req.getParameter("holderId"));
        int result = 0;
        try {
            result = storeService.updateStore(updateId,name, description, goodsnum, holderId);
            if (result > 0) {
                List<Store> list = getStoreList();
                session.setAttribute("storeList", list);
                resp.sendRedirect("./jsp/storeManage.jsp");
            } else {
                resp.sendRedirect("./exception/500.jsp");
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    /**
     * 在店铺页面为店铺添加商品
     * @param req
     * @param resp
     * @throws IOException
     */
    private void addGoodsToStorePage(HttpServletRequest req,HttpServletResponse resp)  throws IOException{
        int addId = Integer.parseInt(req.getParameter("addId"));
        try {
            Store store = storeService.getStoreById(addId);
            if (store != null) {
                session.setAttribute("store", store);
                resp.sendRedirect("./jsp/addGoodsToStore.jsp");
            } else {
                resp.sendRedirect("./exception/500.jsp");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * 打开店铺详情页面
     * @param req
     * @param resp
     * @throws IOException
     */
    private void storeGoodsInfoPage(HttpServletRequest req,HttpServletResponse resp)  throws IOException{
        int storeId = Integer.parseInt(req.getParameter("infoId"));

        List<Goods> list = null;
        Store store = null;
        try
        {
            store = storeService.getStoreById(storeId);
            list = goodsService.getGoodsListByStoreId(storeId);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        if (list != null) {

            session.setAttribute("storeName", store.getName());
            session.setAttribute("goodsList", list);
            resp.sendRedirect("./jsp/storeGoods.jsp");
        } else {
            resp.sendRedirect("./exception/500.jsp");
        }
    }





}
