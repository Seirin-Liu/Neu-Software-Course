package com.liu.dao;

import com.liu.pojo.User;


import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

/**
 * 用户持久层
 */
public interface UserDao {
    //根据用户名和密码获取用户
    User getUserByInfo(Connection connection, String name, String password) throws SQLException;
    /*根据id寻找用户*/
    User getUserById(Connection connection,String id) throws SQLException;
    /*得到所有用户*/
    List<User> getUserList(Connection connection) throws SQLException;
    /*得到指定level所有用户*/
    List<User> getUserList(Connection connection,int level) throws SQLException;
    /*删除用户*/
    int deleteUser(Connection connection,String id) throws SQLException;
    /*新增用户*/
    int addUser(Connection connection,String name,int level,String password) throws SQLException;
    /*修改用户信息*/
    int updateUser(Connection connection,String id,String name,String password,int level) throws SQLException;


}

