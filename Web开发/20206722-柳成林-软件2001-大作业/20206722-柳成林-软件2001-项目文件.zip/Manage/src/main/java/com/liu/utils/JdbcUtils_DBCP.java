package com.liu.utils;

import org.apache.commons.dbcp2.BasicDataSourceFactory;

import javax.sql.DataSource;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

public class JdbcUtils_DBCP {
    private static DataSource dataSource = null ;
    //1.利用静态代码块加载数据库 （利用类加载器在类初始化的时候直接加载配置文件）
    static{
        //数据连接池依旧需要读取配置文件
        InputStream is  = JdbcUtils_DBCP.class.getClassLoader().getResourceAsStream("dbcp.properties");
        Properties properties = new Properties();
        try {
            properties.load(is);
            //创建数据源 : 通过工厂模式创建数据源对象
            dataSource =  BasicDataSourceFactory.createDataSource(properties);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    //2.获取数据库连接
    public static Connection getConnection() throws SQLException {
        return  dataSource.getConnection();
    }
    //查询公共方法
    public static ResultSet execute(Connection connection, ResultSet resultSet, PreparedStatement preparedStatement, Object[] params, String sql) throws SQLException {
        preparedStatement = connection.prepareStatement(sql);
        for(int i=0;i<params.length;i++)
        {
            preparedStatement.setObject(i+1,params[i]);
        }
        resultSet = preparedStatement.executeQuery();
        return resultSet;
    }
    //增删改公共方法
    public static int execute(Connection connection, String sql, Object[] params, PreparedStatement preparedStatement) throws SQLException {
        preparedStatement = connection.prepareStatement(sql);
        for(int i=0;i<params.length;i++)
        {
            preparedStatement.setObject(i+1,params[i]);
        }
        int updateRows = preparedStatement.executeUpdate();
        return updateRows;
    }
    //3.释放资源
    //释放资源
    public static boolean closeResource(Connection connection, PreparedStatement preparedStatement, ResultSet resultSet)
    {
        boolean flag = true;
        if(resultSet!=null)
        {
            try {
                resultSet.close();
                //GC回收
                resultSet = null;
            } catch (SQLException throwables) {
                throwables.printStackTrace();
                flag = false;
            }
        }
        if(preparedStatement!=null)
        {
            try {
                preparedStatement.close();
                //GC回收
                preparedStatement = null;
            } catch (SQLException throwables) {
                throwables.printStackTrace();
                flag = false;
            }
        }
        if(connection!=null)
        {
            try {
                connection.close();
                //GC回收
                connection = null;
            } catch (SQLException throwables) {
                throwables.printStackTrace();
                flag = false;
            }
        }
        return flag;
    }

}
