package com.liu.dao;

import com.liu.pojo.Goods;
import com.liu.pojo.Store;
import com.liu.service.StoreServiceImpl;
import com.liu.utils.JdbcUtils_DBCP;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class GoodsDaoImpl implements GoodsDao{
    @Override
    public List<Goods> getGoodsList(Connection connection) throws SQLException {
        List<Goods> goodsList = new ArrayList<Goods>();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        String sql = "SELECT id,name,description,price,storeId,createDate FROM goods";
        Object[] params = {};
        resultSet = JdbcUtils_DBCP.execute(connection,resultSet,preparedStatement,params,sql);
        StoreServiceImpl storeService  = new StoreServiceImpl();
        while (resultSet.next()) {
            Goods goods = new Goods();
            goods.setId(resultSet.getInt("id"));
            goods.setName(resultSet.getString("name"));
            goods.setDescription(resultSet.getString("description"));
            goods.setPrice(resultSet.getFloat("price"));
            goods.setStoreId(resultSet.getInt("storeId"));
            goods.setCreateDate(resultSet.getDate("createDate"));
            Store store =storeService.getStoreById(resultSet.getInt("storeId"));
            goods.setStoreName(store.getName());
            goodsList.add(goods);
        }
        JdbcUtils_DBCP.closeResource(null,preparedStatement,resultSet);
        return goodsList;
    }

    @Override
    public List<Goods> getGoodsList(Connection connection, int holderId) throws SQLException {
        List<Goods> goodsList = new ArrayList<Goods>();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        String sql = "SELECT goods.id,goods.name,goods.description,goods.price,goods.storeId,goods.createDate FROM goods ,store  WHERE goods.storeId = store.id AND store.holderId =?";
        Object[] params = {holderId};
        resultSet = JdbcUtils_DBCP.execute(connection,resultSet,preparedStatement,params,sql);
        StoreServiceImpl storeService  = new StoreServiceImpl();
        while (resultSet.next()) {
            Goods goods = new Goods();
            goods.setId(resultSet.getInt("id"));
            goods.setName(resultSet.getString("name"));
            goods.setDescription(resultSet.getString("description"));
            goods.setPrice(resultSet.getFloat("price"));
            goods.setStoreId(resultSet.getInt("storeId"));
            goods.setCreateDate(resultSet.getDate("createDate"));
            Store store =storeService.getStoreById(resultSet.getInt("storeId"));
            goods.setStoreName(store.getName());
            goodsList.add(goods);
        }
        JdbcUtils_DBCP.closeResource(null,preparedStatement,resultSet);
        return goodsList;
    }

    @Override
    public List<Goods> getGoodsListByStoreId(Connection connection, int storeId) throws SQLException {
        List<Goods> goodsList = new ArrayList<Goods>();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        String sql = "SELECT id,name,description,price,storeId,createDate FROM goods WHERE storeId =?";
        Object[] params = {storeId};
        resultSet = JdbcUtils_DBCP.execute(connection,resultSet,preparedStatement,params,sql);
        StoreServiceImpl storeService  = new StoreServiceImpl();
        while (resultSet.next()) {
            Goods goods = new Goods();
            goods.setId(resultSet.getInt("id"));
            goods.setName(resultSet.getString("name"));
            goods.setDescription(resultSet.getString("description"));
            goods.setPrice(resultSet.getFloat("price"));
            goods.setStoreId(resultSet.getInt("storeId"));
            goods.setCreateDate(resultSet.getDate("createDate"));
            Store store =storeService.getStoreById(resultSet.getInt("storeId"));
            goods.setStoreName(store.getName());
            goodsList.add(goods);
        }
        JdbcUtils_DBCP.closeResource(null,preparedStatement,resultSet);
        return goodsList;
    }

    @Override
    public int addGoods(Connection connection, String name, String description, float price, Date createDate, int storeId) throws SQLException {
        int result  = -1;
        PreparedStatement preparedStatement = null;
        String sql = "INSERT into goods(name,description,price,createDate,storeId) values (?,?,?,?,?)";
        Object[] params = {name,description,price,createDate,storeId};
        result = JdbcUtils_DBCP.execute(connection,sql,params,preparedStatement);
        JdbcUtils_DBCP.closeResource(null,preparedStatement,null);
        return result;
    }

    @Override
    public int deleteGoods(Connection connection, int id) throws SQLException {
        int result  = -1;
        PreparedStatement preparedStatement = null;
        String sql = "DELETE FROM goods WHERE id=?";
        Object[] params = {id};
        result = JdbcUtils_DBCP.execute(connection,sql,params,preparedStatement);
        JdbcUtils_DBCP.closeResource(null,preparedStatement,null);
        return result;
    }

    @Override
    public int deleteGoodsByStoreId(Connection connection, int storeId) throws SQLException {
        int result  = -1;
        PreparedStatement preparedStatement = null;
        String sql = "DELETE FROM goods WHERE storeId=?";
        Object[] params = {storeId};
        result = JdbcUtils_DBCP.execute(connection,sql,params,preparedStatement);
        JdbcUtils_DBCP.closeResource(null,preparedStatement,null);
        return result;
    }



    @Override
    public Goods getGoodsById(Connection connection, int id) throws SQLException {
        Goods goods = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        String sql = "SELECT id,name,description,price,storeId,createDate FROM goods WHERE id=?";
        Object[] params = {id};
        resultSet = JdbcUtils_DBCP.execute(connection,resultSet,preparedStatement,params,sql);
        StoreServiceImpl storeService  = new StoreServiceImpl();
        while (resultSet.next()) {
            goods = new Goods();
            goods.setId(resultSet.getInt("id"));
            goods.setName(resultSet.getString("name"));
            goods.setDescription(resultSet.getString("description"));
            goods.setPrice(resultSet.getFloat("price"));
            goods.setStoreId(resultSet.getInt("storeId"));
            goods.setCreateDate(resultSet.getDate("createDate"));
            Store store =storeService.getStoreById(resultSet.getInt("storeId"));
            goods.setStoreName(store.getName());
        }
        JdbcUtils_DBCP.closeResource(null,preparedStatement,resultSet);
        return goods;
    }

    @Override
    public int updateGoods(Connection connection, int id, String name, String description, float price, Date createDate, int storeId) throws SQLException {
        int result  = -1;
        PreparedStatement preparedStatement = null;
        String sql = "UPDATE goods set name=?,description=?,price=?,createDate=?,storeId=? WHERE id=?";
        Object[] params = {name,description,price,createDate,storeId,id};
        result = JdbcUtils_DBCP.execute(connection,sql,params,preparedStatement);
        JdbcUtils_DBCP.closeResource(null,preparedStatement,null);
        return result;
    }

    @Override
    public List<Goods> searchGoodsList(Connection connection, String key) throws SQLException {
        List<Goods> goodsList = new ArrayList<Goods>();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        String sql = "SELECT goods.id,goods.name,goods.description,goods.price,goods.storeId,goods.createDate FROM goods,store WHERE (goods.storeId = store.id) AND (goods.name LIKE'%"+key+"%' OR store.name LIKE'%"+key+"%')";
        Object[] params = {};
        resultSet = JdbcUtils_DBCP.execute(connection,resultSet,preparedStatement,params,sql);
        StoreServiceImpl storeService  = new StoreServiceImpl();
        while (resultSet.next()) {
            Goods goods = new Goods();
            goods.setId(resultSet.getInt("id"));
            goods.setName(resultSet.getString("name"));
            goods.setDescription(resultSet.getString("description"));
            goods.setPrice(resultSet.getFloat("price"));
            goods.setStoreId(resultSet.getInt("storeId"));
            goods.setCreateDate(resultSet.getDate("createDate"));
            Store store =storeService.getStoreById(resultSet.getInt("storeId"));
            goods.setStoreName(store.getName());
            goodsList.add(goods);
        }
        JdbcUtils_DBCP.closeResource(null,preparedStatement,resultSet);
        return goodsList;
    }

    @Override
    public List<Goods> searchGoodsList(Connection connection, String key, int holderId) throws SQLException {
        List<Goods> goodsList = new ArrayList<Goods>();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        String sql = "SELECT goods.id,goods.name,goods.description,goods.price,goods.storeId,goods.createDate " +
                "FROM goods,store " +
                "WHERE (goods.storeId = store.id) AND(store.holderId =?) " +
                "AND (goods.name LIKE'%"+key+"%' OR store.name LIKE'%"+key+"%')";
        Object[] params = {holderId};
        resultSet = JdbcUtils_DBCP.execute(connection,resultSet,preparedStatement,params,sql);
        StoreServiceImpl storeService  = new StoreServiceImpl();
        while (resultSet.next()) {
            Goods goods = new Goods();
            goods.setId(resultSet.getInt("id"));
            goods.setName(resultSet.getString("name"));
            goods.setDescription(resultSet.getString("description"));
            goods.setPrice(resultSet.getFloat("price"));
            goods.setStoreId(resultSet.getInt("storeId"));
            goods.setCreateDate(resultSet.getDate("createDate"));
            Store store =storeService.getStoreById(resultSet.getInt("storeId"));
            goods.setStoreName(store.getName());
            goodsList.add(goods);
        }
        JdbcUtils_DBCP.closeResource(null,preparedStatement,resultSet);
        return goodsList;
    }
}
