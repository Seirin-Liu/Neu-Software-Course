package com.liu.service;

import com.liu.pojo.User;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

/**
 * 用户业务层
 */
public interface UserService {
    /*
    登录操作
     */
    User login(String name,String password) throws SQLException;
    /*根据id找到用户*/
    User getUserById(String id);
    /*查找所有的用户*/
    List<User> getUserList();
    List<User> getUserList(int level);
    /*删除用户*/
    int deleteUser(String id);
    /*增加用户*/
    int addUser(String name, int level, String password);
    /*修改用户*/
    int updateUser(String id, String name, String password, int level);
}
