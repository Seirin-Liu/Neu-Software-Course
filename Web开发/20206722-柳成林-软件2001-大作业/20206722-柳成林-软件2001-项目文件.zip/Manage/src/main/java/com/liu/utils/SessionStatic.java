package com.liu.utils;

public class SessionStatic {
    public static final String USER_SESSION = "USER_SESSION" ;
}
