package com.liu.service;

import com.liu.dao.UserDao;
import com.liu.dao.UserDaoImpl;
import com.liu.pojo.User;
import com.liu.utils.JdbcUtils_DBCP;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class UserServiceImpl implements UserService{
    private UserDao userDao;
    public UserServiceImpl(){this.userDao = new UserDaoImpl(); }
    @Override
    public User login(String name, String password) throws SQLException {
        Connection connection = JdbcUtils_DBCP.getConnection();
        User user = null;
        user = userDao.getUserByInfo(connection,name,password);
        JdbcUtils_DBCP.closeResource(connection,null,null);
        return user;
    }

    @Override
    public User getUserById(String id) {
        User user = null;
        try {
            Connection connection = JdbcUtils_DBCP.getConnection();
            user = this.userDao.getUserById(connection,id);
            JdbcUtils_DBCP.closeResource(connection,null,null);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return user;
    }

    @Override
    public List<User> getUserList() {
        List<User> userList = null;
        Connection connection = null;
        try {
            connection = JdbcUtils_DBCP.getConnection();
            userList = this.userDao.getUserList(connection);
            JdbcUtils_DBCP.closeResource(connection,null,null);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return userList;
    }

    @Override
    public List<User> getUserList(int level) {
        List<User> userList = null;
        Connection connection = null;
        try {
            connection = JdbcUtils_DBCP.getConnection();
            userList = this.userDao.getUserList(connection,level);
            JdbcUtils_DBCP.closeResource(connection,null,null);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return userList;
    }

    @Override
    public int deleteUser(String id) {
        int result = -1;
        Connection connection = null;
        try {
            connection = JdbcUtils_DBCP.getConnection();
            result = this.userDao.deleteUser(connection,id);
            JdbcUtils_DBCP.closeResource(connection,null,null);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return result;
    }

    @Override
    public int addUser(String name, int level, String password) {
        int result = -1;
        Connection connection = null;
        try {
            connection = JdbcUtils_DBCP.getConnection();
            result = this.userDao.addUser(connection,name,level,password);
            JdbcUtils_DBCP.closeResource(connection,null,null);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return result;
    }

    @Override
    public int updateUser(String id, String name, String password, int level) {
        int result = -1;
        Connection connection = null;
        try {
            connection = JdbcUtils_DBCP.getConnection();
            result = this.userDao.updateUser(connection,id,name,password,level);
            JdbcUtils_DBCP.closeResource(connection,null,null);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return result;
    }
}
