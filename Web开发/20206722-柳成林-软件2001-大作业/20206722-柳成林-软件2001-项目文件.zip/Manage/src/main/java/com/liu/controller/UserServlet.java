package com.liu.controller;

import com.liu.pojo.User;
import com.liu.service.UserService;
import com.liu.service.UserServiceImpl;
import com.liu.utils.SessionStatic;

import javax.mail.Session;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * 用户
 */
public class UserServlet extends HttpServlet {
    private UserService userService ;
    public UserServlet(){this.userService = new UserServiceImpl();}
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //先拿到当前进行的函数
        HttpSession session = req.getSession();
        String method = req.getParameter("method");
        System.out.println(method);
        if ("login".equals(method)) {
            /*获取前端信息*/
            String username = req.getParameter("username");
            String password = req.getParameter("truepassword");
            System.out.println(username);
            System.out.println(password);
            User user = login(username, password);
            System.out.println(user);
            if(user!=null) {
                    /*把当前用户放到session里面*/
                    session.setAttribute(SessionStatic.USER_SESSION, user);
                    req.getRequestDispatcher("/goods").forward(req, resp);
            } else {
                req.setAttribute("flag","false");
                req.getRequestDispatcher("login.jsp").forward(req,resp);
            }
        } else if ("loginOut".equals(method)) {
            /*登出*/
            session.setAttribute(SessionStatic.USER_SESSION,null);
            req.getRequestDispatcher("login.jsp").forward(req,resp);
        } else if ("userManage".equals(method)){
            List<User> users = getUserList();
            req.getSession().setAttribute("list",users);
            resp.sendRedirect("./jsp/userManage.jsp");
        } else if("deleteUser".equals(method)) {
            String id = req.getParameter("deleteId");
            deleteUser(id);
            List<User> users = getUserList();
            req.getSession().setAttribute("list",users);
            req.getRequestDispatcher("./jsp/userManage.jsp").forward(req,resp);
        } else if("toUserUpdate".equals(method)) {
            String id = req.getParameter("updateId");
            User user = this.userService.getUserById(id);
            session.setAttribute("user",user);
            resp.sendRedirect("./jsp/updateUser.jsp");
        } else if("addUser".equals(method)) {
            String name = req.getParameter("username");
            String password = req.getParameter("password");
            int level = Integer.parseInt(req.getParameter("level"));
            System.out.println("123456");
            System.out.println(name);
            System.out.println(password);
            System.out.println(level);
            int result = addUser(name,password,level);
            if (result >0) {
                List<User> users = getUserList();
                req.getSession().setAttribute("list",users);
                resp.sendRedirect("./jsp/userManage.jsp");
            }
        } else if("updateUser".equals(method)) {
            String id = req.getParameter("updateId");
            String name = req.getParameter("username");
            String password = req.getParameter("password");
            int level = Integer.parseInt(req.getParameter("level"));
            int result = update(id,name,password,level);
            if (result >0) {
                List<User> users = getUserList();
                req.getSession().setAttribute("list",users);
                resp.sendRedirect("./jsp/userManage.jsp");
            }
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req,resp);
    }
    
    /*登录 查询对应用户*/
    public User login(String username,String password) {
        UserService userService = new UserServiceImpl();
        User user = null;
        try {
            user = userService.login(username,password);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return user;
    }
    /*所有用户*/
    public List<User> getUserList(){
        return this.userService.getUserList();
    }
    /*删除用户*/
    public int deleteUser(String id){
        return this.userService.deleteUser(id);
    }
    /*修改用户信息*/
    public int update(String id,String name,String password,int level){
        return this.userService.updateUser(id,name,password,level);
    }
    /*增加用户*/
    public int addUser(String name,String password,int level){
        return this.userService.addUser(name,level,password);
    }
}
