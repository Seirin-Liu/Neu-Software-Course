package com.liu.pojo;

/**
 * 店铺
 */
public class Store {
    private int id;
    private String name;
    private String description;
    private int goodsnum;
    private int holderId;

    public Store(int id, String name, String description, int goodsnum, int holderId) {

        this.id = id;
        this.name = name;
        this.description = description;
        this.goodsnum = goodsnum;
        this.holderId = holderId;
    }

    public Store() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getGoodsnum() {
        return goodsnum;
    }

    public void setGoodsnum(int goodsnum) {
        this.goodsnum = goodsnum;
    }

    public int getHolderId() {
        return holderId;
    }

    public void setHolderId(int holderId) {
        this.holderId = holderId;
    }

    @Override
    public String toString() {
        return "Store{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", goodsnum=" + goodsnum +
                ", holderId=" + holderId +
                '}';
    }
}

