package com.liu.service;

import com.liu.dao.GoodsDaoImpl;
import com.liu.dao.StoreDaoImpl;
import com.liu.pojo.Store;
import com.liu.utils.JdbcUtils_DBCP;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class StoreServiceImpl implements StoreService{
    private StoreDaoImpl storeDao;
    public StoreServiceImpl(){storeDao = new StoreDaoImpl();}
    @Override
    public List<Store> getStoreList() throws SQLException {
        List<Store> storeList = null;
        try {
            Connection connection = JdbcUtils_DBCP.getConnection();
            storeList = this.storeDao.getStoreList(connection);
            JdbcUtils_DBCP.closeResource(connection,null,null);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return storeList;
    }

    @Override
    public List<Store> getStoreList(int holderId) throws SQLException {
        List<Store> storeList = null;
        try {
            Connection connection = JdbcUtils_DBCP.getConnection();
            storeList = this.storeDao.getStoreList(connection,holderId);
            JdbcUtils_DBCP.closeResource(connection,null,null);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return storeList;
    }

    @Override
    public int addStore(String name, String description, int goodsnum, int holderId) throws SQLException {
        int result = -1;
        Connection connection = null;
        try {
            connection = JdbcUtils_DBCP.getConnection();
            result = this.storeDao.addStore(connection,name,description,goodsnum,holderId);
            JdbcUtils_DBCP.closeResource(connection,null,null);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return result;
    }

    @Override
    public int deleteStore(int id) throws SQLException {
        int result = -1;
        Connection connection = null;
        try {
            connection = JdbcUtils_DBCP.getConnection();
            result = this.storeDao.deleteStore(connection,id);
            JdbcUtils_DBCP.closeResource(connection,null,null);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return result;
    }

    @Override
    public Store getStoreById(int id) throws SQLException {
        Store store = null;
        Connection connection = null;
        try {
            connection = JdbcUtils_DBCP.getConnection();
            store= this.storeDao.getStoreById(connection,id);
            JdbcUtils_DBCP.closeResource(connection,null,null);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return store;
    }

    @Override
    public int updateStore(int id, String name, String description, int goodsnum, int holderId) throws SQLException {
        int result = -1;
        Connection connection = null;
        try {
            connection = JdbcUtils_DBCP.getConnection();
            result = this.storeDao.updateStore(connection,id,name,description,goodsnum,holderId);
            JdbcUtils_DBCP.closeResource(connection,null,null);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return result;
    }

    @Override
    public Store getStoreByName(String name) {
        Store store = null;
        Connection connection = null;
        try {
            connection = JdbcUtils_DBCP.getConnection();
            store= this.storeDao.getStoreByName(connection,name);
            JdbcUtils_DBCP.closeResource(connection,null,null);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return store;
    }

    @Override
    public int addGoodsNum(int id) throws SQLException {
        int result = -1;
        Connection connection = null;
        try {
            connection = JdbcUtils_DBCP.getConnection();
            result = this.storeDao.addGoodsNum(connection,id);
            JdbcUtils_DBCP.closeResource(connection,null,null);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return result;
    }

    @Override
    public int deleteGoodsNum(int id) throws SQLException {
        int result = -1;
        Connection connection = null;
        try {
            connection = JdbcUtils_DBCP.getConnection();
            result = this.storeDao.deleteGoodsNum(connection,id);
            JdbcUtils_DBCP.closeResource(connection,null,null);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return result;
    }

    @Override
    public int updateGoodsNum(int oldId, int newId) {
        int result = -1;
        Connection connection = null;
        try {
            connection = JdbcUtils_DBCP.getConnection();
            result = this.storeDao.updateGoodsNum(connection,oldId,newId);
            JdbcUtils_DBCP.closeResource(connection,null,null);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return result;
    }

    @Override
    public List<Store> searchStoreList(String key) throws SQLException {
        List<Store> storeList = null;
        try {
            Connection connection = JdbcUtils_DBCP.getConnection();
            storeList = this.storeDao.searchStoreList(connection,key);
            JdbcUtils_DBCP.closeResource(connection,null,null);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return storeList;
    }

    @Override
    public List<Store> searchStoreList(String key, int holderId) throws SQLException {
        List<Store> storeList = null;
        try {
            Connection connection = JdbcUtils_DBCP.getConnection();
            storeList = this.storeDao.searchStoreList(connection,key,holderId);
            JdbcUtils_DBCP.closeResource(connection,null,null);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return storeList;
    }
}
