package com.liu.dao;

import com.liu.pojo.Store;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

/**
 * 店铺持久层
 */
public interface StoreDao {

    //查询所有店铺
    List<Store> getStoreList(Connection connection) throws SQLException;
    List<Store> getStoreList(Connection connection, int holderId) throws SQLException;
    //添加店铺
    int addStore(Connection connection,String name, String description, int goodsnum, int holderId) throws SQLException;
    //删除店铺
    int deleteStore(Connection connection,int id) throws SQLException;
    //根据id查询店铺
    Store getStoreById(Connection connection,int id) throws SQLException;
    //修改店铺信息
    int updateStore(Connection connection,  int id, String name, String description, int goodsnum, int holderId) throws SQLException;

    /*根据name获得店铺*/
    Store getStoreByName(Connection connection,  String name) throws SQLException;

    /*由于增加商品而带来的店铺变动*/
    int addGoodsNum(Connection connection,int id) throws SQLException;

    /*由于删除商品而带来的店铺变动*/
    int deleteGoodsNum(Connection connection,int id) throws SQLException;

    /*由于修改商品而带来的店铺变动*/
    int updateGoodsNum(Connection connection,int oldId, int newId) throws SQLException;

    List<Store> searchStoreList(Connection connection,String key) throws SQLException;
    List<Store> searchStoreList(Connection connection, String key,int holderId) throws SQLException;

}
