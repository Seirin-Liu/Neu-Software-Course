package com.liu.controller;

import com.liu.pojo.*;
import com.liu.service.*;


import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * 商品
 */
public class GoodsServlet extends HttpServlet {
    private  GoodsServiceImpl goodsService;
    private  StoreServiceImpl storeService;
    private  HttpSession session;
    public  GoodsServlet(){
        goodsService = new GoodsServiceImpl();
        storeService =new StoreServiceImpl();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        session = req.getSession();
        String method = req.getParameter("method");
        System.out.println("GoodsSer "+method);

        if (method == null || "login".equals(method)|| "toGoodsPage".equals(method)) {
           toGoodsPage(req,resp);
        }
        else if ("addGoods".equals(method)) {
            addGoods(req,resp);
        }
        else if ("toAddGoods".equals(method)) {
            toAddGoods(req,resp);
        }
        else if ("deleteGoods".equals(method)) {
            deleteGoods(req,resp);
        }
        else if ("deleteGoodsFromStorePage".equals(method)) {
            deleteGoodsFromStorePage(req,resp);
        }
        else if ("updateGoodsPage".equals(method)) {
            updateGoodsPage(req,resp);
        }
        else if ("updateGoods".equals(method)) {
            updateGoods(req,resp);
        }
        else if("updateGoodsFromStorePage".equals(method)){
            updateGoodsFromStorePage(req,resp);
        }
        else if("updateGoodsFromStore".equals(method)){
            updateGoodsFromStore(req,resp);
        }
        else if ("search".equals(method)) {
            search(req,resp);
        }
        else if("toGoodsPageLevel1".equals(method)){
            toGoodsPageLevel1(req,resp);
        }
        else if("searchInGoodsPage".equals(method)){
            String key = req.getParameter("keyword");
            if (key==null||key.length()==0){
                toGoodsPageLevel1(req,resp);
                return;
            }
            List<Goods> list = null;
            try {
                list =goodsService.searchGoodsList(key);
            } catch (SQLException throwable) {
                throwable.printStackTrace();
            }
            if (list != null) {
                session.setAttribute("goodsList", list);
                resp.sendRedirect("./jsp/goodsPage.jsp");
            } else {
                resp.sendRedirect("./exception/500.jsp");
            }
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req,resp);
    }

    /**
     * 加载商品列表
     * @param req
     * @param resp
     * @throws IOException
     */
    private void toGoodsPage(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        List<Goods> list = null;
        try
        {
           list = getGoodsList();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        if (list != null) {
            session.setAttribute("goodsList", list);
            resp.sendRedirect("./jsp/menu.jsp");
        } else {
            resp.sendRedirect("./exception/500.jsp");
        }
    }

    /**
     * 加载商品列表
     * @param req
     * @param resp
     * @throws IOException
     */
    private void toGoodsPageLevel1(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        List<Goods> list = null;
        try
        {
            list = goodsService.getGoodsList();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        if (list != null) {
            session.setAttribute("goodsList", list);
            resp.sendRedirect("./jsp/goodsPage.jsp");
        } else {
            resp.sendRedirect("./exception/500.jsp");
        }
    }

    /**
     * 添加新商品
     * @param req
     * @param resp
     * @throws IOException
     */
    private void addGoods(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String name = (String) req.getParameter("goodsName");
        String description = req.getParameter("description");
        String storeName = (String) req.getParameter("store");
        System.out.println(storeName);
        Float price = Float.parseFloat(req.getParameter("goodsPrice"));
        String createDate = req.getParameter("createDate");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date date = null;
//        String email = req.getParameter("email");
        try {
            date = sdf.parse(createDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        /*通过name获得部门id并存储*/
        Store store = storeService.getStoreByName(storeName);
        int storeId = store.getId();
        int result = 0;
        try {
            result = addGoods(name,description,price,date,storeId);
            storeService.addGoodsNum(storeId);
            if (result>0) {
                List<Goods> list = getGoodsList();
                session.setAttribute("goodsList",list);
                resp.sendRedirect("./jsp/menu.jsp");
            } else {
                resp.sendRedirect("./exception/500.jsp");
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    /**
     * 跳转添加商品页面
     * @param req
     * @param resp
     * @throws IOException
     */
    private void toAddGoods(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        try {
            List<Store>  storeList= getStoreList();
            if (storeList != null) {
                session.setAttribute("storeList", storeList);
                resp.sendRedirect("./jsp/addGoods.jsp");
            } else {
                resp.sendRedirect("./exception/500.jsp");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * 删除商品
     * @param req
     * @param resp
     * @throws IOException
     */
    private void deleteGoods(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        int deleteId = Integer.parseInt(req.getParameter("deleteId"));
        try {
            Goods deleteGoods = goodsService.getGoodsById(deleteId);
            System.out.println("要删除的:\n"+deleteGoods);
            int result = deleteGoods(deleteId);
            StoreServiceImpl storeService = new StoreServiceImpl();
            int resulteStore = -1;
            resulteStore = storeService.deleteGoodsNum(deleteGoods.getStoreId());
            if (result>0) {
                List<Goods> list = getGoodsList();
                session.setAttribute("goodsList",list);
                resp.sendRedirect("./jsp/menu.jsp");
            } else {
                resp.sendRedirect("./exception/500.jsp");
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    /**
     * 删除商品
     * @param req
     * @param resp
     * @throws IOException
     */
    private void deleteGoodsFromStorePage(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        int deleteId = Integer.parseInt(req.getParameter("deleteId"));
        int storeId = Integer.parseInt(req.getParameter("storeId"));
        try {
            Goods deleteGoods = goodsService.getGoodsById(deleteId);
            System.out.println("要删除的:\n"+deleteGoods);
            int result = deleteGoods(deleteId);
            StoreServiceImpl storeService = new StoreServiceImpl();
            int resulteStore = -1;
            resulteStore = storeService.deleteGoodsNum(deleteGoods.getStoreId());
            if (result>0) {
                List<Goods> list = goodsService.getGoodsListByStoreId(storeId);
                session.setAttribute("goodsList",list);
                resp.sendRedirect("./jsp/storeGoods.jsp");
            } else {
                resp.sendRedirect("./exception/500.jsp");
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    /**
     * 打开编辑页面
     * @param req
     * @param resp
     */
    private void updateGoodsPage(HttpServletRequest req, HttpServletResponse resp){
        int updateId = Integer.parseInt(req.getParameter("updateId"));
        try {
            List<Store> storeList =getStoreList();
            session.setAttribute("storeList",storeList);
            Goods goods = getGoodsById(updateId);
            //传入商品信息
            if (goods != null) {
                session.setAttribute("goods",goods);
                resp.sendRedirect("./jsp/updateGoods.jsp");
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 打开编辑页面
     * @param req
     * @param resp
     */
    private void updateGoodsFromStorePage(HttpServletRequest req, HttpServletResponse resp){
        int updateId = Integer.parseInt(req.getParameter("updateId"));
        try {
            List<Store> storeList =getStoreList();
            session.setAttribute("storeList",storeList);
            Goods goods = getGoodsById(updateId);
            //传入商品信息
            if (goods != null) {
                session.setAttribute("goods",goods);
                resp.sendRedirect("./jsp/updateGoodsFromStore.jsp");
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 更新商品
     * @param req
     * @param resp
     * @throws IOException
     */
    private void updateGoods(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        int updateId = Integer.parseInt(req.getParameter("updateId"));
        String name = req.getParameter("goodsName");
        String description = req.getParameter("description");
        String storeName = req.getParameter("store");
        Float price = Float.parseFloat(req.getParameter("goodsPrice"));
        String createDate = req.getParameter("createDate");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date date = null;
        try {
            date = sdf.parse(createDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        /*通过name获得部门id并存储*/
        StoreServiceImpl storeService = new StoreServiceImpl();
        Store store = storeService.getStoreByName(storeName);
        try {
            int storeIdNew = store.getId();
            int storeIdOld = storeService.getStoreById(getGoodsById(updateId).getStoreId()).getId();
            int result = 0;
            //判断有没有修改storeid
            if(storeIdNew==storeIdOld) {
                result = updateGoods(updateId, name, description, price, date, storeIdNew);
            }
            else{
                result = updateGoods(updateId, name, description, price, date, storeIdNew);
                storeService.updateGoodsNum(storeIdOld,storeIdNew);
            }
            if (result>0) {
                List<Goods> list = getGoodsList();
                session.setAttribute("goodsList",list);
                resp.sendRedirect("./jsp/menu.jsp");
            } else {
                resp.sendRedirect("./exception/500.jsp");
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    /**
     * 更新商品
     * @param req
     * @param resp
     * @throws IOException
     */
    private void updateGoodsFromStore(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        int updateId = Integer.parseInt(req.getParameter("updateId"));
        int storeId = Integer.parseInt(req.getParameter("storeId"));
        String name = req.getParameter("goodsName");
        String description = req.getParameter("description");
        String storeName = req.getParameter("store");
        Float price = Float.parseFloat(req.getParameter("goodsPrice"));
        String createDate = req.getParameter("createDate");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date date = null;
        try {
            date = sdf.parse(createDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        /*通过name获得部门id并存储*/
        StoreServiceImpl storeService = new StoreServiceImpl();
        Store store = storeService.getStoreByName(storeName);
        try {
            int storeIdNew = store.getId();
            int storeIdOld = storeService.getStoreById(getGoodsById(updateId).getStoreId()).getId();
            int result = 0;
            //判断有没有修改storeid
            if(storeIdNew==storeIdOld) {
                result = updateGoods(updateId, name, description, price, date, storeIdNew);
            }
            else{
                result = updateGoods(updateId, name, description, price, date, storeIdNew);
                storeService.updateGoodsNum(storeIdOld,storeIdNew);
            }
            if (result>0) {
                List<Goods> list = goodsService.getGoodsListByStoreId(storeId);
                session.setAttribute("goodsList",list);
                resp.sendRedirect("./jsp/storeGoods.jsp");
            } else {
                resp.sendRedirect("./exception/500.jsp");
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    private void search(HttpServletRequest req, HttpServletResponse resp) throws IOException {

        String key = req.getParameter("keyword");
        if (key==null||key.length()==0){
            toGoodsPage(req,resp);
            return;
        }
        List<Goods> list = null;
        try {
            list =searchGoods(key);
        } catch (SQLException throwable) {
            throwable.printStackTrace();
        }
        if (list != null) {
            session.setAttribute("goodsList", list);
            resp.sendRedirect("./jsp/menu.jsp");
        } else {
            resp.sendRedirect("./exception/500.jsp");
        }

    }


    /**
     * 通过level获取所有商品
     * @return
     * @throws SQLException
     */
    public List<Goods> getGoodsList() throws SQLException {
        List<Goods> list = null;
        User currentUser = (User) session.getAttribute("USER_SESSION");
        {
            if (currentUser.getLevel() == 3||currentUser.getLevel() == 1) {
                list = goodsService.getGoodsList();
            } else {
                list = goodsService.getGoodsList(Integer.parseInt(currentUser.getId()));
            }
            return list;
        }
    }

    /**
     * 通过level获取店铺列表
     * @return
     * @throws SQLException
     */
    public List<Store> getStoreList()throws SQLException{
        List<Store> list = null;
        User currentUser = (User) session.getAttribute("USER_SESSION");
        {
            if (currentUser.getLevel() == 3||currentUser.getLevel() == 1) {
                list = storeService.getStoreList();
            } else {
                list = storeService.getStoreList(Integer.parseInt(currentUser.getId()));
            }
            return list;
        }
    }

    /**
     * 搜索
     * @param key
     * @return
     * @throws SQLException
     */
    public List<Goods> searchGoods(String key) throws  SQLException{
        List<Goods> list = null;
        User currentUser = (User) session.getAttribute("USER_SESSION");
        {
            if (currentUser.getLevel() == 3||currentUser.getLevel() == 1) {
                list = goodsService.searchGoodsList(key);
            } else {
                list = goodsService.searchGoodsList(key,Integer.parseInt(currentUser.getId()));
            }
            return list;
        }
    }


    public int addGoods(String name, String description, float price, Date createDate, int storeId) throws SQLException {
        return goodsService.addGoods(name,description,price,createDate,storeId);
    }
    public int deleteGoods(int id) throws SQLException {
        return goodsService.deleteGoods(id);
    }
    public Goods getGoodsById(int id)throws SQLException{
        return  goodsService.getGoodsById(id);
    }
    public int updateGoods(int id,String name, String description, float price, Date createDate, int storeId) throws SQLException {
        return goodsService.updateGoods(id,name,description,price,createDate,storeId);
    }


}
