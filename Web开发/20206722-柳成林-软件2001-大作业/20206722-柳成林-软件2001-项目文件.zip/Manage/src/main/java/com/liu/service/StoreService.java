package com.liu.service;

import com.liu.pojo.Store;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

/**
 * 店铺业务层
 */
public interface StoreService {
    //查询所有店铺
    List<Store> getStoreList() throws SQLException;
    //查询所有店铺
    List<Store> getStoreList(int holderId) throws SQLException;
    //添加店铺
    int addStore( String name, String description, int goodsnum, int holderId) throws SQLException;
    //删除店铺
    int deleteStore(int id) throws SQLException;
    //根据id查询店铺
    Store getStoreById(int id) throws SQLException;
    //修改店铺信息
    int updateStore( int id, String name, String description, int goodsnum, int holderId) throws SQLException;

    /*根据name获得店铺*/
    Store getStoreByName(String name) throws SQLException;

    /*由于增加店铺而带来的店铺变动*/
    int addGoodsNum(int id) throws SQLException;

    /*由于删除店铺而带来的店铺变动*/
    int deleteGoodsNum(int id) throws SQLException;

    /*由于修改店铺而带来的店铺变动*/
    int updateGoodsNum(int oldId, int newId);

    List<Store> searchStoreList( String key) throws SQLException;
    List<Store> searchStoreList( String key,int holderId) throws SQLException;


}
