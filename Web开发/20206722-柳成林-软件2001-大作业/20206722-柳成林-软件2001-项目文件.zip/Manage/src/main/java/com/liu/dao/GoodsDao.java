package com.liu.dao;

import com.liu.pojo.Goods;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

/**
 * 商品持久层
 */
public interface GoodsDao {
    //查询所有商品
    List<Goods> getGoodsList(Connection connection) throws SQLException;

    //查询所有商品
    List<Goods> getGoodsList(Connection connection,int holderId) throws SQLException;

    //查询所有商品
    List<Goods> getGoodsListByStoreId(Connection connection,int storeId) throws SQLException;

    //添加商品
    int addGoods(Connection connection, String name, String description, float price, Date createDate, int storeId) throws SQLException;
    //删除商品
    int deleteGoods(Connection connection,int id) throws SQLException;
    //根据id查询商品
    Goods getGoodsById(Connection connection,int id) throws SQLException;
    //修改商品信息
    int updateGoods(Connection connection,int id, String name, String description, float price, Date createDate, int storeId) throws SQLException;

    int deleteGoodsByStoreId(Connection connection, int storeId) throws SQLException;

    //查询
    List<Goods> searchGoodsList(Connection connection,String key) throws SQLException;

    List<Goods> searchGoodsList(Connection connection,String key,int holderId) throws SQLException;


}
