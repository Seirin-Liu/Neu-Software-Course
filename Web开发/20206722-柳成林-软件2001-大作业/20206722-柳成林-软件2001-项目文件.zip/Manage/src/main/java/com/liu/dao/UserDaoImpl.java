package com.liu.dao;

import com.liu.pojo.User;
import com.liu.utils.JdbcUtils_DBCP;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserDaoImpl implements UserDao{

    @Override
    public User getUserByInfo(Connection connection, String name, String password) throws SQLException {
            User user = null;
            PreparedStatement preparedStatement = null;
            ResultSet resultSet = null;
            String sql = "SELECT id,name,level,password FROM user WHERE name=? AND password=?";
            Object[] params = {name,password};
            resultSet = JdbcUtils_DBCP.execute(connection,resultSet,preparedStatement,params,sql);
            while(resultSet.next()) {
                user = new User();
                user.setId(resultSet.getString("id"));
                user.setName(resultSet.getString("name"));
                user.setLevel(resultSet.getInt("level"));
                user.setPasswrod(resultSet.getString("password"));
            }
            JdbcUtils_DBCP.closeResource(null,preparedStatement,resultSet);
            return user;
        }

    @Override
    public User getUserById(Connection connection, String id) throws SQLException {
        User user = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        String sql = "SELECT id,name,level,password FROM user WHERE id=?";
        Object[] params = {id};
        resultSet = JdbcUtils_DBCP.execute(connection,resultSet,preparedStatement,params,sql);
        while(resultSet.next()) {
            user = new User();
            user.setId(resultSet.getString("id"));
            user.setName(resultSet.getString("name"));
            user.setLevel(resultSet.getInt("level"));
            user.setPasswrod(resultSet.getString("password"));
        }
        JdbcUtils_DBCP.closeResource(null,preparedStatement,resultSet);
        return user;
    }

    @Override
    public List<User> getUserList(Connection connection) throws SQLException {
        List<User> userList = new ArrayList<User>();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        String sql = "SELECT id,name,level,password FROM user";
        Object[] params = {};
        resultSet = JdbcUtils_DBCP.execute(connection,resultSet,preparedStatement,params,sql);
        while (resultSet.next()) {
            User user = new User();
            user.setId(resultSet.getString("id"));
            user.setName(resultSet.getString("name"));
            user.setLevel(resultSet.getInt("level"));
            user.setPasswrod(resultSet.getString("password"));
            userList.add(user);
        }
        JdbcUtils_DBCP.closeResource(null,preparedStatement,resultSet);
        return userList;
    }

    @Override
    public List<User> getUserList(Connection connection, int level) throws SQLException {
        List<User> userList = new ArrayList<User>();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        String sql = "SELECT id,name,level,password FROM user WHERE level =?";
        Object[] params = {level};
        resultSet = JdbcUtils_DBCP.execute(connection,resultSet,preparedStatement,params,sql);
        while (resultSet.next()) {
            User user = new User();
            user.setId(resultSet.getString("id"));
            user.setName(resultSet.getString("name"));
            user.setLevel(resultSet.getInt("level"));
            user.setPasswrod(resultSet.getString("password"));
            userList.add(user);
        }
        JdbcUtils_DBCP.closeResource(null,preparedStatement,resultSet);
        return userList;
    }

    @Override
    public int deleteUser(Connection connection, String id) throws SQLException {
        int result = -1;
        PreparedStatement preparedStatement = null;
        String sql = "delete FROM user WHERE id=?";
        Object[] params = {id};
        result = JdbcUtils_DBCP.execute(connection,sql,params,preparedStatement);
        JdbcUtils_DBCP.closeResource(null,preparedStatement,null);
        return result;
    }

    @Override
    public int addUser(Connection connection,String name, int level, String password) throws SQLException {
        int result  = -1;
        PreparedStatement preparedStatement = null;
        String sql = "insert into user(name,password,level) values (?,?,?)";
        Object[] params = {name,password,level};
        result = JdbcUtils_DBCP.execute(connection,sql,params,preparedStatement);
        JdbcUtils_DBCP.closeResource(null,preparedStatement,null);
        return result;
    }

    @Override
    public int updateUser(Connection connection, String id, String name, String password, int level) throws SQLException {
        int result = -1;
        PreparedStatement preparedStatement = null;
        String sql = "update user set name=?,level=?,password=? WHERE id=?";
        Object[] params = {name,level,password,id};
        result = JdbcUtils_DBCP.execute(connection,sql,params,preparedStatement);
        JdbcUtils_DBCP.closeResource(null,preparedStatement,null);
        return result;
    }


}
