package com.liu.dao;

import com.liu.pojo.Store;
import com.liu.utils.JdbcUtils_DBCP;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class StoreDaoImpl implements StoreDao{
    @Override
    public List<Store> getStoreList(Connection connection) throws SQLException {
        List<Store> storeList = new ArrayList<Store>();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        String sql = "SELECT id,name,description,goodsnum,holderId FROM store";
        Object[] params = {};
        resultSet = JdbcUtils_DBCP.execute(connection,resultSet,preparedStatement,params,sql);
        while (resultSet.next()) {
            Store store = new Store();
            store.setId(resultSet.getInt("id"));
            store.setName(resultSet.getString("name"));
            store.setDescription(resultSet.getString("description"));
            store.setGoodsnum(resultSet.getInt("goodsnum"));
            store.setHolderId(resultSet.getInt("holderId"));
            storeList.add(store);
        }
        JdbcUtils_DBCP.closeResource(null,preparedStatement,resultSet);
        return storeList;
    }
    @Override
    public List<Store> getStoreList(Connection connection, int holderId) throws SQLException {
        List<Store> storeList = new ArrayList<Store>();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        String sql = "SELECT id,name,description,goodsnum,holderId FROM store WHERE holderId =?";
        Object[] params = {holderId};
        resultSet = JdbcUtils_DBCP.execute(connection,resultSet,preparedStatement,params,sql);
        while (resultSet.next()) {
            Store store = new Store();
            store.setId(resultSet.getInt("id"));
            store.setName(resultSet.getString("name"));
            store.setDescription(resultSet.getString("description"));
            store.setGoodsnum(resultSet.getInt("goodsnum"));
            store.setHolderId(resultSet.getInt("holderId"));
            storeList.add(store);
        }
        JdbcUtils_DBCP.closeResource(null,preparedStatement,resultSet);
        return storeList;
    }

    @Override
    public int addStore(Connection connection, String name, String description, int goodsnum, int holderId) throws SQLException {
        int result  = -1;
        PreparedStatement preparedStatement = null;
        String sql = "INSERT INTO store(name,description,goodsnum,holderId) values (?,?,?,?)";
        Object[] params = {name,description,goodsnum,holderId};
        result = JdbcUtils_DBCP.execute(connection,sql,params,preparedStatement);
        JdbcUtils_DBCP.closeResource(null,preparedStatement,null);
        return result;
    }

    @Override
    public int deleteStore(Connection connection, int id) throws SQLException {
        int result = -1;
        PreparedStatement preparedStatement = null;
        String sql = "DELETE FROM store WHERE id=?";
        Object[] params = {id};
        result = JdbcUtils_DBCP.execute(connection,sql,params,preparedStatement);
        JdbcUtils_DBCP.closeResource(null,preparedStatement,null);
        return result;
    }

    @Override
    public Store getStoreById(Connection connection, int id) throws SQLException {
        Store store = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        String sql = "SELECT id,name,description,goodsnum,holderId FROM store WHERE id=?";
        Object[] params = {id};
        resultSet = JdbcUtils_DBCP.execute(connection,resultSet,preparedStatement,params,sql);
        while(resultSet.next()) {
            store = new Store();
            store.setId(resultSet.getInt("id"));
            store.setName(resultSet.getString("name"));
            store.setDescription(resultSet.getString("description"));
            store.setGoodsnum(resultSet.getInt("goodsnum"));
            store.setHolderId(resultSet.getInt("holderId"));
        }
        JdbcUtils_DBCP.closeResource(null,preparedStatement,resultSet);
        return store;
    }

    @Override
    public int updateStore(Connection connection, int id, String name, String description, int goodsnum, int holderId) throws SQLException {
        int result = -1;
        PreparedStatement preparedStatement = null;
        String sql = "UPDATE store SET name=?,description=?,goodsnum=?,holderId=? WHERE id=?";
        Object[] params = {name,description,goodsnum,holderId,id};
        result = JdbcUtils_DBCP.execute(connection,sql,params,preparedStatement);
        JdbcUtils_DBCP.closeResource(null,preparedStatement,null);
        return result;
    }

    @Override
    public Store getStoreByName(Connection connection, String name) throws SQLException {
        Store store = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        String sql = "SELECT id,name,description,goodsnum,holderId FROM store WHERE name=?";
        Object[] params = {name};
        resultSet = JdbcUtils_DBCP.execute(connection,resultSet,preparedStatement,params,sql);
        while (resultSet.next()) {
            store = new Store();
            store.setId(resultSet.getInt("id"));
            store.setName(resultSet.getString("name"));
            store.setDescription(resultSet.getString("description"));
            store.setGoodsnum(resultSet.getInt("goodsnum"));
            store.setHolderId(resultSet.getInt("holderId"));
        }
        JdbcUtils_DBCP.closeResource(null,preparedStatement,resultSet);
        return store;
    }

    @Override
    public int addGoodsNum(Connection connection, int id) throws SQLException {
        int result = -1;
        PreparedStatement preparedStatement = null;
        String sql = "UPDATE store set goodsnum=goodsnum+1 WHERE id=?";
        Object[] params = {id};
        result = JdbcUtils_DBCP.execute(connection,sql,params,preparedStatement);
        JdbcUtils_DBCP.closeResource(null,preparedStatement,null);
        return result;
    }

    @Override
    public int deleteGoodsNum(Connection connection, int id) throws SQLException {
        int result = -1;
        PreparedStatement preparedStatement = null;
        String sql = "UPDATE store set goodsnum=goodsnum-1 WHERE id=?";
        Object[] params = {id};
        result = JdbcUtils_DBCP.execute(connection,sql,params,preparedStatement);
        JdbcUtils_DBCP.closeResource(null,preparedStatement,null);
        return result;
    }

    @Override
    public int updateGoodsNum(Connection connection, int oldId, int newId) throws SQLException {
        int result = -1;
        PreparedStatement preparedStatement = null;
        int addresult = addGoodsNum(connection,newId);
        int deleteresult = deleteGoodsNum(connection,oldId);
        JdbcUtils_DBCP.closeResource(null,preparedStatement,null);
        return result;
    }

    @Override
    public List<Store> searchStoreList(Connection connection, String key) throws SQLException {
        List<Store> storeList = new ArrayList<Store>();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        String sql = "SELECT id,name,description,goodsnum,holderId FROM store WHERE name LIKE'%"+key+"%'";
        Object[] params = {};
        resultSet = JdbcUtils_DBCP.execute(connection,resultSet,preparedStatement,params,sql);
        while (resultSet.next()) {
            Store store = new Store();
            store.setId(resultSet.getInt("id"));
            store.setName(resultSet.getString("name"));
            store.setDescription(resultSet.getString("description"));
            store.setGoodsnum(resultSet.getInt("goodsnum"));
            store.setHolderId(resultSet.getInt("holderId"));
            storeList.add(store);
        }
        JdbcUtils_DBCP.closeResource(null,preparedStatement,resultSet);
        return storeList;
    }

    @Override
    public List<Store> searchStoreList(Connection connection, String key, int holderId) throws SQLException {
        List<Store> storeList = new ArrayList<Store>();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        String sql = "SELECT id,name,description,goodsnum,holderId FROM store WHERE name LIKE'%"+key+"%' AND holderId =?";
        Object[] params = {holderId};
        resultSet = JdbcUtils_DBCP.execute(connection,resultSet,preparedStatement,params,sql);
        while (resultSet.next()) {
            Store store = new Store();
            store.setId(resultSet.getInt("id"));
            store.setName(resultSet.getString("name"));
            store.setDescription(resultSet.getString("description"));
            store.setGoodsnum(resultSet.getInt("goodsnum"));
            store.setHolderId(resultSet.getInt("holderId"));
            storeList.add(store);
        }
        JdbcUtils_DBCP.closeResource(null,preparedStatement,resultSet);
        return storeList;
    }
}
