package com.liu.service;

import com.liu.dao.GoodsDaoImpl;
import com.liu.pojo.Goods;
import com.liu.pojo.Store;
import com.liu.utils.JdbcUtils_DBCP;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

public class GoodsServiceImpl implements GoodsService{
    private  GoodsDaoImpl goodsDao;
    public GoodsServiceImpl(){
        goodsDao =new GoodsDaoImpl();
    }

    @Override
    public List<Goods> getGoodsList() throws SQLException {
        List<Goods> goodsList = null;
        try {
            Connection connection = JdbcUtils_DBCP.getConnection();
            goodsList = this.goodsDao.getGoodsList(connection);
            JdbcUtils_DBCP.closeResource(connection,null,null);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return goodsList;
    }

    @Override
    public List<Goods> getGoodsList(int holderId) throws SQLException {
        List<Goods> goodsList = null;
        try {
            Connection connection = JdbcUtils_DBCP.getConnection();
            goodsList = this.goodsDao.getGoodsList(connection,holderId);
            JdbcUtils_DBCP.closeResource(connection,null,null);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return goodsList;
    }

    @Override
    public List<Goods> getGoodsListByStoreId(int storeId) throws SQLException {
        List<Goods> goodsList = null;
        try {
            Connection connection = JdbcUtils_DBCP.getConnection();
            goodsList = this.goodsDao.getGoodsListByStoreId(connection,storeId);
            JdbcUtils_DBCP.closeResource(connection,null,null);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return goodsList;
    }

    @Override
    public int addGoods(String name, String description, float price, Date createDate, int storeId) throws SQLException {
        int result = -1;
        Connection connection = null;
        try {
            connection = JdbcUtils_DBCP.getConnection();
            result = this.goodsDao.addGoods(connection,name,description,price,createDate,storeId);
            JdbcUtils_DBCP.closeResource(connection,null,null);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return result;
    }

    @Override
    public int deleteGoods(int id) throws SQLException {
        int result = -1;
        Connection connection = null;
        try {
            connection = JdbcUtils_DBCP.getConnection();
            result = this.goodsDao.deleteGoods(connection,id);
            JdbcUtils_DBCP.closeResource(connection,null,null);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return result;
    }

    @Override
    public int deleteGoodsByStoreId(int storeId) throws SQLException {
        int result = -1;
        Connection connection = null;
        try {
            connection = JdbcUtils_DBCP.getConnection();
            result = this.goodsDao.deleteGoodsByStoreId(connection,storeId);
            JdbcUtils_DBCP.closeResource(connection,null,null);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return result;
    }

    @Override
    public Goods getGoodsById(int id) throws SQLException {
        Goods goods = null;
        Connection connection = null;
        try {
            connection = JdbcUtils_DBCP.getConnection();
            goods= this.goodsDao.getGoodsById(connection,id);
            JdbcUtils_DBCP.closeResource(connection,null,null);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return goods;
    }

    @Override
    public int updateGoods(int id, String name, String description, float price, Date createDate, int storeId) throws SQLException {
        int result = -1;
        Connection connection = null;
        try {
            connection = JdbcUtils_DBCP.getConnection();
            result = this.goodsDao.updateGoods(connection,id,name,description,price,createDate,storeId);
            JdbcUtils_DBCP.closeResource(connection,null,null);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return result;
    }

    @Override
    public List<Goods> searchGoodsList(String key) throws SQLException {
        List<Goods> goodsList = null;
        try {
            Connection connection = JdbcUtils_DBCP.getConnection();
            goodsList = this.goodsDao.searchGoodsList(connection,key);
            JdbcUtils_DBCP.closeResource(connection,null,null);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return goodsList;
    }

    @Override
    public List<Goods> searchGoodsList(String key, int holderId) throws SQLException {
        List<Goods> goodsList = null;
        try {
            Connection connection = JdbcUtils_DBCP.getConnection();
            goodsList = this.goodsDao.searchGoodsList(connection,key,holderId);
            JdbcUtils_DBCP.closeResource(connection,null,null);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return goodsList;
    }
}
