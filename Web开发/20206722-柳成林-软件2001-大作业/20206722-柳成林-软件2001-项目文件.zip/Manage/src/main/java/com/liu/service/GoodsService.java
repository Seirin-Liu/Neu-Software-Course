package com.liu.service;

import com.liu.pojo.Goods;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

/**
 * 商品业务层
 */
public interface GoodsService {
    //查询所有商品
    List<Goods> getGoodsList() throws SQLException;
    //查询所有商品
    List<Goods> getGoodsList(int holderId) throws SQLException;

    //查询所有商品
    List<Goods> getGoodsListByStoreId(int storeId) throws SQLException;

    //添加商品
    int addGoods(String name, String description, float price, Date createDate, int storeId) throws SQLException;
    //删除商品
    int deleteGoods(int id) throws SQLException;

    int deleteGoodsByStoreId(int storeId) throws SQLException;
    //根据id查询商品
    Goods getGoodsById(int id) throws SQLException;
    //修改商品信息
    int updateGoods(int id, String name, String description, float price, Date createDate, int storeId) throws SQLException;

    //查询
    List<Goods> searchGoodsList(String key) throws SQLException;

    List<Goods> searchGoodsList(String key,int holderId) throws SQLException;
}
