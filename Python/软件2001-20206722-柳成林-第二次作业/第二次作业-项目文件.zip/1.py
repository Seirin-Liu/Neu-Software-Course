import numpy as np

arr = np.random.randn(10,10)
print("1.元素服从标准正态分布：\n",arr)

arr=arr.astype(np.int8).T
print("2.数据类型转换并数组转置：\n",arr)

print("3.数据类型：",arr.dtype)

print("4.内存占用：",arr.size*arr.itemsize)

print("5.所有偶数存入一维数组：\n",arr.astype(np.int8)[arr.astype(np.int8)%2==0])