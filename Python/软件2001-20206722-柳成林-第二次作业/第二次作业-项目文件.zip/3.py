import collections

import numpy as np;


arr=np.random.randint(1,100,[6,6])
print("\n1.6行6列的二维数组arr:\n",arr)

print("\n2.每列的最大值:\n",np.max(arr,axis=0))

print("\n3.每行的最小值:\n",np.min(arr,axis=1))

print("\n4.每个元素的出现次数:\n ",collections.Counter(arr.flatten()))

print("\n5.第三行每个元素的排名:\n",np.sort(arr,axis=1)[2][:])

print("\n6.去除重复的行:\n",np.unique(arr, axis=0))

print("\n7.从第4行抽取3个元素:\n",np.random.choice(arr[3][:],3,False))

print("\n8.第5行中不含第1行数据的数据:\n",np.setdiff1d(arr[4][:],arr[4][arr[4][:]==arr[1][:]]))


arr2 , arr2[arr2<10]=arr.astype('float32') , float(np.nan)
print("\n9.小于10的元素修改为NaN,生成arr2:\n",arr2)


print("\n10.删除arr2中含有Nan的列:\n",arr2[:, ~np.isnan(arr2).any(axis=0)])
