import numpy as np


from numpy import mat

matr = mat(np.eye(5)*3)
print("1.主对角线为3的5*5矩阵matr:\n",matr)

matr1=matr[:,[1,0,2,3,4]]
print("2.交换第一列与第二列,构成matr1:\n",matr1)

matr2=matr[[0,2,1,3,4],:]
print("3.交换第二行与第三行,构成matr2:\n",matr2)

print("4.是否有元素不同：",len(np.argwhere(matr1!=matr2))!=0,"\n  不同元素的个数：",len(np.argwhere(matr1!=matr2)),"\n  不同元素的位置：\n",np.argwhere(matr1!=matr2))

print("5.matr1与matr2相乘:\n",matr1*matr2)

print("6.matr1与matr2对应元素相乘:\n",np.multiply(matr1,matr2))

print("7.matr1与matr2按行拼接:\n",np.hstack((matr1,matr2)))
