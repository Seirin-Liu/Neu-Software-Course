package Dao;

import Entity.Question;
import Util.ReadUtils;
import Util.WriteUtils;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class QuestionDao {

	private ObservableList<Question> questionData;
	
	private static QuestionDao questionDao;
	
	
	/**
	 * ��ȡ����
	 */
	public static QuestionDao getQuestionDao() {
		if(questionDao==null) {
			questionDao=new QuestionDao();
		}
		return questionDao;
	}


	public ObservableList<Question> getQuestionData() {
		return questionData;
	}


	public void setQuestionData(ObservableList<Question> questionData) {
		this.questionData = questionData;
	}


    public   QuestionDao() {
		questionData=ReadUtils.readQuestionData("Questions");
		
	}
	
	/**
	 * ͨ��content��������
	 * @param key
	 * @return
	 */
	public ObservableList<Question> getQuestionBySearch(String key){
		ObservableList<Question> questionList=FXCollections.observableArrayList();
		for(Question q:questionData) {
			if(q.getContent().indexOf(key)!=-1) {
				questionList.add(q);
			}		
		}
		return questionList;	
	}
	/**
	 * ��������ʱ�Զ�����һ���µ�id
	 * @return
	 */
	public int getNewId() {
		int max=0;
		for(Question q:questionData) {		
			if(q.getId()>=max) {	
				max=q.getId();
			}
		}
		return max+1;
	}
	
	/**
	 * ͨ��id��������
	 * @param id
	 * @return
	 */
	public Question searchQuestionById(int id) {
		for(Question q:questionData) {
			if(q.getId()==id) {	
				return q;
			}
		}
		return null;
	}
	public void saveQuestionData() {
		WriteUtils.writeQuestionData("Questions", questionData);
	}
}
