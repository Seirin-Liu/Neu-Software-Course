package Dao;

import java.util.List;

import Entity.Moudel;
import Entity.Question;
import Util.ReadUtils;
import Util.WriteUtils;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class MoudelDao {

	private ObservableList<Moudel> moudelData;
	
	private static MoudelDao moudelDao;
	

	/**
	 * ��ȡ����
	 */
	public static MoudelDao getMoudelDao() {
		if(moudelDao==null) {
			moudelDao=new MoudelDao();
		}
		return moudelDao;
	}

	public ObservableList<Moudel> getMoudelData() {
		return moudelData;
	}

	public void setMoudelData(ObservableList<Moudel> moudelData) {
		this.moudelData = moudelData;
	}
	
	private MoudelDao() {
		moudelData=ReadUtils.readMoudelData("Moudels");
	}
	

	/**
	 * �����µ�id
	 * @return
	 */
	public int getNewId() {
		int max=0;
		for(Moudel q:moudelData) {		
			if(q.getId()>=max) {	
				max=q.getId();
			}
		}
		return max+1;
	}
	/**
	 * ģ������
	 * @param key
	 * @return
	 */
	public ObservableList<Moudel> getMoudelBySearch(String key){
		ObservableList<Moudel> MoudelList=FXCollections.observableArrayList();
		for(Moudel q:moudelData) {
			if(q.getName().indexOf(key)!=-1||q.getType().indexOf(key)!=-1) {
				MoudelList.add(q);
			}		
		}
		return MoudelList;	
	}
	/**
	 * ɾ��ģ���������
	 * @param q
	 */
	public void DeleteQuestion(Question q) {
		for(Moudel m:moudelData) {
			List<Question> questionList=m.getQuestions();
			for(int i=0;i<questionList.size();i++) {
				if(q.getId()==questionList.get(i).getId()) {
					questionList.remove(i);
					i--;	
				}
			}
			m.setQuestions(questionList);
		}
	}
	/**
	 * �޸�ģ���������
	 * @param q
	 */
	public void modifyQuestion(Question q) {
		for(Moudel m:moudelData) {
			List<Question> questionList=m.getQuestions();
			for(int i=0;i<questionList.size();i++) {
				if(q.getId()==questionList.get(i).getId()) {
					questionList.set(i, q);		
				}
			}
			m.setQuestions(questionList);
		}
		
	}
	
	public void saveMoudelData() {
		WriteUtils.writeMoudelData("Moudels", moudelData);
	}
	
}
