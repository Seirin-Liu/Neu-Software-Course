package Dao;

import java.util.List;

import Entity.Bed;
import Entity.Building;
import Entity.Floor;
import Entity.Room;
import Util.ReadUtils;
import Util.WriteUtils;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class BuildingDao {

	private List<Building> buildingData;
	private ObservableList<Bed> bedData;
	private ObservableList<Bed> patientBedData;
	/**
	 * ˽�л����췽��
	 */
	private BuildingDao() {
		buildingData = ReadUtils.readBuildingData("Buildings");
		bedData = getAllBeds(); // bedData�����еĴ�
		patientBedData=getPatientBeds();
	}

	private static BuildingDao buildingDao; // ʵ��

	/**
	 * ��ȡ����
	 * 
	 * @return
	 */
	public static BuildingDao getBuildingDao() {
		if (buildingDao == null) {
			buildingDao = new BuildingDao();
		}
		return buildingDao;
	}

	public ObservableList<Bed> getBedData() {
		return bedData;
	}

	public void setBedData(ObservableList<Bed> bedData) {
		this.bedData = bedData;
	}

	public ObservableList<Bed> getPatientBedData() {
		return patientBedData;
	}

	public void setPatientBedData(ObservableList<Bed> patientBedData) {
		this.patientBedData = patientBedData;
	}

	public static void setBuildingDao(BuildingDao buildingDao) {
		BuildingDao.buildingDao = buildingDao;
	}

	public List<Building> getBuildingData() {
		return buildingData;
	}

	public void setBuildingData(List<Building> buildingData) {
		this.buildingData = buildingData;
	}

	public void saveBuildingData() {
		WriteUtils.writeBuildingData("Buildings", buildingData);
	}

	public ObservableList<String> getBuildingNames() {
		ObservableList<String> buildings = FXCollections.observableArrayList();
		for (Building b : buildingData) {
			buildings.add(b.getName());
		}
		return buildings;
	}

	/**
	 * ͨ��¥�����ƻ�ȡ¥��ʵ��
	 * 
	 * @param buildingName
	 * @return
	 */
	public Building getBuilding(String buildingName) {
		for (Building b : buildingData) {
			if (b.getName().equals(buildingName)) {
				return b;
			}
		}
		return null;
	}

	public ObservableList<String> getFloorNames(Building building) {
		ObservableList<String> floorNames = FXCollections.observableArrayList();
		for (Floor f : building.getFloors()) {
			floorNames.add(f.getName());
		}
		return floorNames;
	}

	public ObservableList<String> getRoomNames(Floor floor) {
		ObservableList<String> roomNames = FXCollections.observableArrayList();
		for (Room r : floor.getRooms()) {
			roomNames.add(r.getName());
		}
		return roomNames;
	}

	public ObservableList<String> getBedNames(Room room) {
		ObservableList<String> bedNames = FXCollections.observableArrayList();
		if (room.getBeds().size() == 0) {
			return null;
		}
		for (Bed b : room.getBeds()) {
			bedNames.add(b.getName());
		}
		return bedNames;
	}

	public Floor getFloor(Building building, String floorName) {
		for (Floor f : building.getFloors()) {
			if (f.getName().equals(floorName)) {
				return f;
			}
		}
		return null;
	}

	public Room getRoom(Floor floor, String roomName) {
		for (Room m : floor.getRooms()) {
			if (m.getName().equals(roomName)) {
				return m;
			}
		}
		return null;
	}

	public Bed getBed(Room room, String bedName) {
		for (Bed b : room.getBeds()) {
			if (b.getName().equals(bedName)) {
				return b;
			}
		}
		return null;
	}

	/**
	 * �жϲ����Ƿ��д�
	 * 
	 * @return
	 */
	public boolean isPatientHasBed(String patientName) {
		if(patientBedData==null) {
			return false;
		}
		for (Bed b : patientBedData) {
			// ע������ѭ�����������в��˵Ĵ�λ��Ҳ����˵�����˴���������¼������data
			if (b.getPatientName().equals(patientName)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * ��ȡ��ס�Ĵ�
	 * 
	 * @return
	 */
	public ObservableList<Bed> getPatientBeds() {
		ObservableList<Bed> bedList = FXCollections.observableArrayList();
		if (buildingData == null) {
			return null;
		}
		for (Bed bed : bedData) {
			if (bed.getStatus().equals("��ס��")) {
				bedList.add(bed);
			}
		}
		return bedList;
	}
	/**
	 * ��ȡδ��ס�Ĵ�
	 * 
	 * @return
	 */
	public ObservableList<Bed> getFreeBeds() {
		ObservableList<Bed> bedList = FXCollections.observableArrayList();
		for (Bed bed : bedData) {
			if (bed.getStatus().equals("δ��ס")) {
				bedList.add(bed);
			}
		}
		return bedList;
	}

	/**
	 * ��ȡ���еĴ�
	 * 
	 * @return
	 */
	public ObservableList<Bed> getAllBeds() {
		ObservableList<Bed> bedList = FXCollections.observableArrayList();
		for (Building b : buildingData) {
			for (Floor f : b.getFloors()) {
				for (Room r : f.getRooms()) {
					for (Bed bed : r.getBeds()) {
						bedList.add(bed);
					}
				}
			}
		}
		return bedList;
	}

	

	/**
	 * �����˴�
	 * 
	 * @param bedName
	 * @return
	 */
	public void clearBed(String bedName) {
		for (Building b : buildingData) {
			for (Floor f : b.getFloors()) {
				for (Room r : f.getRooms()) {
					for (Bed bed : r.getBeds()) {
						if (bed.getName().equals(bedName)) {
							bed.setEndTime(null);
							bed.setPatientAge(null);
							bed.setPatientName(null);
							bed.setPatientSex(null);
							bed.setRecordId(null);
							bed.setStartTime(null);
							bed.setStatus("δ��ס");
							bedData.remove(bed);
						}
					}
				}
			}
		}
	}

	/**
	 * ������λ
	 * 
	 * @param key
	 * @return
	 */
	public ObservableList<Bed> searchBeds(String key) {
		ObservableList<Bed> bedList = FXCollections.observableArrayList();
		for (Bed bed : bedData) {
			if (bed.getPatientName().indexOf(key) != -1 || bed.getName().indexOf(key) != -1
					|| bed.getRecordId().indexOf(key) != -1) {
				bedList.add(bed);
			}
		}
		return bedList;
	}

	/**
	 * ѡ��һ��Room��������Ŀ��д�λ��Ϣ
	 * @param room
	 * @return
	 */
	public ObservableList<String> getFreeBedNames(Room room) {
		ObservableList<String> bedNames = FXCollections.observableArrayList();
		if (room.getBeds().size() == 0) {
			return null;
		}
		for (Bed b : room.getBeds()) {
			if (b.getStatus().equals("δ��ס")) {
				bedNames.add(b.getName());
			}
		}
		return bedNames;
	}

}
