package Dao;


import java.util.List;

import Entity.Employee;
import Util.ReadUtils;
import Util.WriteUtils;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class EmployeeDao {

	 private  ObservableList<Employee> employeeData;
	 private  List<Employee> employeeList;
	 
  /**
	* ˽�л����췽��
	*/
	 private  EmployeeDao() {
		 employeeList =ReadUtils.readEmployeeData("Employees");
		 employeeData = FXCollections.observableArrayList(employeeList);
	 }

	public ObservableList<Employee> getEmployeeData() {
		return employeeData;
	}

	public void setEmployeeData(ObservableList<Employee> employeeData) {
		this.employeeData = employeeData;
	}

	public List<Employee> getEmployeeList() {
		return employeeList;
	}

	
	private static EmployeeDao employeeDao;
	/**
	 * ��ȡ����
	 */
	public static EmployeeDao getEmployeeDao() {
		if(employeeDao==null) {
			employeeDao=new EmployeeDao();
		}
		return employeeDao;
	}
	/**
	    * �ж�employee���û��������Ƿ���ȷ
	    * @param username
	    * @param password
	    * @return  �û�
	    */
	public  Employee CheckEmployee(String username,String password) {
		
		  for(Employee e:employeeData) {
			  if(e.getUsername().equals(username)&&e.getPassword().equals(password)) {
				  return e;
			  }
		  }
		   return null;
	   }
	
	/**
	 * ͨ���û�������
	 * @param username
	 * @return
	 */
	public Employee getEmployeeByUsername(String username) {
		for(Employee e:employeeData) {
			if(e.getUsername().equals(username)) {
				return e;
			}
		}
		return null;	
	}
	
	/**
	 * ͨ������Ա��ְҵ��ȡԱ���б�
	 * @param profession
	 * @return
	 */
	public ObservableList<Employee> getEmployeeListOfProfession(String profession) {
		ObservableList<Employee> employeeList = FXCollections.observableArrayList();
		for (Employee e : employeeData) {
			if (e.getProfession().equals(profession)) {
				employeeList.add(e);
			}
		}
		return employeeList;
	}	
	
	/**
	 * ͨ������Ա��������ȡԱ���б�
	 * @param key
	 * @return
	 */
	public ObservableList<Employee> getEmployeeListBySearch(String key){
		ObservableList<Employee> employeeList = FXCollections.observableArrayList();
		for (Employee e : employeeData) {
			if (e.getName().indexOf(key)!=-1||e.getId().indexOf(key)!=-1||e.getSpeciality().indexOf(key)!=-1) {
				employeeList.add(e);
			}
		}
		return employeeList;
		
	}
	
   public void saveNewEmployeedata(Employee newEmployee) {
	   for(Employee e:employeeData) {
			if(e.getUsername().equals(newEmployee.getUsername())) {
				int index =employeeData.indexOf(e);
				employeeData.set(index, newEmployee);
				return;
			}
		}	
	}
   
   public void saveEmployeeData() {
	   WriteUtils.writeEmployeeData("Employees", employeeData);
   }
}
