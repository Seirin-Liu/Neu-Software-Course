package Dao;

import Entity.Assess;
import Util.ReadUtils;
import Util.WriteUtils;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class AssessDao {

	
	private ObservableList<Assess> assessData;
	
	private static AssessDao assessDao;
	

	/**
	 * ��ȡ����
	 */
	public static AssessDao getAssessDao() {
		if(assessDao==null) {
			assessDao=new AssessDao();
		}
		return assessDao;
	}

	public ObservableList<Assess> getAssessData() {
		return assessData;
	}

	public void setAssessData(ObservableList<Assess> assessData) {
		this.assessData = assessData;
	}
	/**
	 * ˽�л����췽��
	 */
	private AssessDao() {
		assessData=ReadUtils.readAssessData("Assesses");
	}
	
	
	/**
	 * ͨ�������������˵���������������¼
	 * @param key
	 * @return
	 */
	public ObservableList<Assess> getAssessBySearch(String key){
		ObservableList<Assess> assessList=FXCollections.observableArrayList();
		for(Assess q:assessData) {
			if(q.getName().indexOf(key)!=-1) {
				assessList.add(q);
			}		
		}
		return assessList;	
	}
	
	/**
	 * �����µ�������¼
	 * @param assess
	 */
	public void AddNewAssessData(Assess assess) {
		assessData.add(assess);		
	}
	
	public void  saveAssessData() {
		WriteUtils.writeAssessData("Assesses", assessData);
	}
	
}
