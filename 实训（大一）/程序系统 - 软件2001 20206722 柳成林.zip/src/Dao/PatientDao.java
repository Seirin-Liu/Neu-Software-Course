package Dao;

import Entity.Patient;
import Util.ReadUtils;
import Util.WriteUtils;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class PatientDao {

	private ObservableList<Patient> patientData;
	
	private static PatientDao patientDao;
	
	/**
	 * ��ȡ����
	 */
	public static PatientDao getPatientDao() {
		if(patientDao==null) {
			patientDao=new PatientDao();
		}
		return patientDao;
	}
	
	private PatientDao() {
		patientData=ReadUtils.readPatientData("Patients");
	}

	public ObservableList<Patient> getPatientData() {
		return patientData;
	}

	public void setPatientData(ObservableList<Patient> patientData) {
		this.patientData = patientData;
	}
	
	/**
	 * ͨ����������������ȡԱ���б�
	 * @param key
	 * @return
	 */
	public ObservableList<Patient> getPatientListBySearch(String key){
		ObservableList<Patient> patientList = FXCollections.observableArrayList();
		for (Patient e : patientData) {
			if (e.getName().indexOf(key)!=-1||e.getId().indexOf(key)!=-1) {
				patientList.add(e);
			}
		}
		return patientList;
		
	}	
	/**
	 * ԭ���� ���޸ĺ��
	 * @param patient
	 * @param modifiedPatient
	 */
	public void saveModifiedPatient(Patient patient ,Patient modifiedPatient) {
	    int index=patientData.indexOf(patient);
	    patientData.set(index, modifiedPatient);
	}
	/**
	 * �����ļ�
	 */
	public void savePatientData() {
		WriteUtils.writePatientData("Patients", patientData);
	}
	
	
	
}
