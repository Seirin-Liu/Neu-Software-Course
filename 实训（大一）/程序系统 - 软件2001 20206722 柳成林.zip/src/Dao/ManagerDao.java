package Dao;

import java.util.List;

import Entity.Manager;
import Util.ReadUtils;
import Util.WriteUtils;

public class ManagerDao {
	
	private List<Manager> managerList;
	
	private  ManagerDao() {
		managerList=ReadUtils.readManagerList("Managers");
	}

	public List<Manager> getManagerList() {
		return managerList;
	}

	public void setManagerList(List<Manager> managerList) {
		this.managerList = managerList;
	}
	
	private static ManagerDao managerDao;
	
	/**
	 * ��ȡ����
	 */
	public static ManagerDao getManagerDao() {
		if(managerDao==null) {
			managerDao=new ManagerDao();
		}
		return managerDao;
	}
	
	
	/**
	 * ��¼ʱ�ã���loginservice��ʹ��
	 * @param username
	 * @param password
	 * @return
	 */
	public Manager CheckManager(String username,String password) {
		 
		   for (Manager m:managerList) {
			   if(m.getUsername().equals(username)&&m.getPassword().equals(password)) {
				   return m;
			   }
		   }
		   return null;
	   }
	
	/**
	 * �޸Ĺ���Ա��Ϣʱ��,���µĹ���Ա���뵽ԭ�����б���
	 * @param manager
	 */
	public void  saveNewManager(Manager manager) {
		for (Manager m:managerList) {
			if (m.getUsername().equals(manager.getUsername())) {
				int index =managerList.indexOf(m);
				managerList.set(index, manager);
				saveManagerData();
				return;
			}
		}
	}
	
	public void saveManagerData() {
		WriteUtils.writeManagerData("Managers", managerList);
	}
}
