package Dao;

import Entity.RareRoom;
import Util.ReadUtils;
import Util.WriteUtils;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class RareRoomDao {

	private ObservableList<RareRoom> rareRoomData;

	/**
	 * ��ȡ����
	 */
	public ObservableList<RareRoom> getRareRoomData() {
		return rareRoomData;
	}

	public void setRareRoomData(ObservableList<RareRoom> rareRoomData) {
		this.rareRoomData = rareRoomData;
	}
	
	private RareRoomDao() {
		rareRoomData=ReadUtils.readRareRoomData("RareRooms");
	}
	
	private static RareRoomDao rareRoomDao;
	
	public static RareRoomDao getRareRoomDao() {
		if(rareRoomDao==null) {
			rareRoomDao=new RareRoomDao();
		}
		return rareRoomDao;
	}
	
	public void saveRareRoomData() {
		WriteUtils.writeRareRoomData("RareRooms", rareRoomData);
	}
	public void addNewRareRoom(RareRoom rareRoom) {
		rareRoomData.add(rareRoom);
	}
	public void deleteRareRoom(String rareRoomName){
		for(RareRoom r:rareRoomData) {
			if(r.getName().equals(rareRoomName)) {
				rareRoomData.remove(r);
			}
		}
	}
	public void clearUser(RareRoom rareRoom) {
		for(RareRoom r:rareRoomData) {
			if(r.getName().equals(rareRoom.getName())) {
				r.getUserId().clear();
				r.setNow(0);
			}
		}
	}
	public ObservableList<RareRoom> searchRareRoom(String key){
		ObservableList<RareRoom> rareRoomList=FXCollections.observableArrayList();
		for(RareRoom r:rareRoomData) {
			if(r.getName().indexOf(key)!=-1) {
				rareRoomList.add(r);
			}
		}
		return rareRoomList;
	}
}
