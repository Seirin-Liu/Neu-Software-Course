package Service;



import Dao.MoudelDao;
import Entity.Moudel;
import Entity.Question;
import javafx.collections.ObservableList;

public class MoudelService {

	private MoudelDao moudelDao;
	
	private static MoudelService moudelService;
	
	public static MoudelService getMoudelService() {
		if(moudelService==null) {
			moudelService=new MoudelService();
		}
		return moudelService;
	}

	public MoudelDao getMoudelDao() {
		return moudelDao;
	}

	public void setMoudelDao(MoudelDao moudelDao) {
		this.moudelDao = moudelDao;
	}

	private MoudelService() {
		moudelDao=MoudelDao.getMoudelDao();
	}
	public int  getNewId() {
		return moudelDao.getNewId();
	}
	/**
	 * ����
	 * @param key
	 * @return
	 */
	public ObservableList<Moudel> getMoudelBySearch(String key){
		return moudelDao.getMoudelBySearch(key);
	}
	/**
	 * ɾ������ʱ��ͬʱɾ��ģ���������
	 * @param q
	 */
	public void DeleteQuestion(Question q) {
		moudelDao.DeleteQuestion(q);
		moudelDao.saveMoudelData();
	}
	
    /**
     * �޸�����ʱ����ģ���������Ҳһ���޸�
     * @param q
     */
	public void modifyQuestion(Question q) {
		moudelDao.modifyQuestion(q);
		moudelDao.saveMoudelData();
	}
	
	
	public void saveMoudelData(ObservableList<Moudel> moudelData) {
		moudelDao.setMoudelData(moudelData);
		moudelDao.saveMoudelData();
	}
}
