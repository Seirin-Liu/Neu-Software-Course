package Service;

import Dao.AssessDao;
import Entity.Assess;
import javafx.collections.ObservableList;

public class AssessService {

	private AssessDao assessDao;
	
	private static AssessService assessService;
	
	
	public static AssessService getAssessService() {
		if(assessService==null) {
			assessService=new AssessService();
		}
		return assessService;
	}
	/**
	 * ˽�л����췽��
	 */
	private AssessService() {
		assessDao=AssessDao.getAssessDao();
	}

	public AssessDao getAssessDao() {
		return assessDao;
	}

	public void setAssessDao(AssessDao assessDao) {
		this.assessDao = assessDao;
	}
	
	/**
	 * ����
	 * @param key
	 * @return
	 */
	public ObservableList<Assess> getAssessBySearch(String key){
		return assessDao.getAssessBySearch(key);
		
	}
	
	/**
	 * �����µ�������¼��ֻ������һ��
	 * @param assess
	 */
	public void AddNewAssessData(Assess assess) {
		assessDao.AddNewAssessData(assess);
		assessDao.saveAssessData();
	}
	
	/**
	 * �����µ�assessData�����Data��һ����list
	 * @param assessData
	 */
	public void saveAssessData(ObservableList<Assess> assessData) {
		assessDao.setAssessData(assessData);
		assessDao.saveAssessData();
	}
	
	
}
