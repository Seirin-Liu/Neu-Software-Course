package Service;

import Dao.PatientDao;
import Entity.Patient;
import javafx.collections.ObservableList;

public class PatientService {

	private PatientDao patientDao;
	
	private static PatientService patientService;
	
	public static PatientService getPatientService() {
		if(patientService==null) {
			patientService=new PatientService();
		}
		return patientService;
	}
	/**
	 * ˽�л����췽��
	 */
	private PatientService() {
		
		patientDao=PatientDao.getPatientDao();
	}

	public PatientDao getPatientDao() {
		return patientDao;
	}

	public void setPatientDao(PatientDao patientDao) {
		this.patientDao = patientDao;
	}
	
	public ObservableList<Patient> getEmployeeListBySearch(String key){
		return patientDao.getPatientListBySearch(key);
	}
	
	public void savePatientData(ObservableList<Patient> patientData) {
		patientDao.setPatientData(patientData);
		patientDao.savePatientData();
	}
	public void saveModifiedPatient(Patient patient ,Patient modifiedPatient) {
		patientDao.saveModifiedPatient(patient, modifiedPatient);
		patientDao.savePatientData();
		
	}
}
