package Service;

import Dao.EmployeeDao;
import Dao.ManagerDao;
import Entity.Employee;
import Entity.Manager;

/**
 * ͨ������EmployeDao��ManagerDao�������ݷ��ʣ��жϵ�¼�Ƿ�ɹ�
 * @author Seirin
 *
 */
public class LoginService {
   EmployeeDao edao;
   ManagerDao adao;  
   
   private Manager manager;
   private Employee employee;
      
   
public Manager getManager() {
	return manager;
}


public Employee getEmployee() {
	return employee;
}

public  LoginService() {
	   edao=EmployeeDao.getEmployeeDao();
	   adao=ManagerDao.getManagerDao();
   }
   
  /**
   * �ж��������˵�¼�����ж��û��������Ƿ���ȷ 
   * @param username
   * @param password
   * @return
   */
 public  int LoginCheck (String username,String password){
	  
	if(username.startsWith("admin")) {
		if((manager=adao.CheckManager(username, password))!=null) {
			return 1;
		}			
	}
	else {
		if((employee=edao.CheckEmployee(username, password))!=null) {
			return 2;
		}
		else {
			return 0;
		}
	}	
	return 0;
  }
 
   
   
   
   
}
