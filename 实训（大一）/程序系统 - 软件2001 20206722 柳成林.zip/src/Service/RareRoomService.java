package Service;

import Dao.RareRoomDao;
import Entity.RareRoom;
import javafx.collections.ObservableList;

public class RareRoomService {

	private RareRoomDao  rareRoomDao;

	public RareRoomDao getRareRoomDao() {
		return rareRoomDao;
	}

	public void setRareRoomDao(RareRoomDao rareRoomDao) {
		this.rareRoomDao = rareRoomDao;
	}
	/**
	 * ˽�л����췽��
	 */
	private RareRoomService() {
		rareRoomDao=RareRoomDao.getRareRoomDao();
	}
	
	private static RareRoomService rareRooomService;

	public static RareRoomService getRareRooomService() {
		if(rareRooomService==null) {
			rareRooomService=new RareRoomService();
		}
		return rareRooomService;
	}
	
	public void saveRareRoomData(ObservableList<RareRoom> rareRoomData) {
		rareRoomDao.setRareRoomData(rareRoomData);
		rareRoomDao.saveRareRoomData();
	}

	/**
	 * �����µ�ϡ�з���
	 * @param rareRoom
	 */
	public void addNewRareRoom(RareRoom rareRoom) {
		rareRoomDao.addNewRareRoom(rareRoom);
		rareRoomDao.saveRareRoomData();
	}

	/**
	 * ɾ��ϡ�з���
	 * @param rareRoomName
	 */
	public void deleteRareRoom(String rareRoomName){
		rareRoomDao.deleteRareRoom(rareRoomName);
		rareRoomDao.saveRareRoomData();
	}
	/**
	 * ���ʹ����
	 * @param rareRoom
	 */
	public void clearUser(RareRoom rareRoom) {
		rareRoomDao.clearUser(rareRoom);
		rareRoomDao.saveRareRoomData();
	}
	
	public ObservableList<RareRoom> searchRareRoom(String key){
		return rareRoomDao.searchRareRoom(key);
	}


	
	
}
