package Service;

import java.util.List;

import Dao.BuildingDao;
import Entity.Bed;
import Entity.Building;
import Entity.Floor;
import Entity.Room;
import javafx.collections.ObservableList;

public class BuildingService {

	private  BuildingDao buildingDao;
	
	public BuildingDao getBuildingDao() {
		return buildingDao;
	}

	public void setBuildingDao(BuildingDao buildingDao) {
		this.buildingDao = buildingDao;
	}
	/**
	 * ˽�л����췽��
	 */
	private BuildingService() {
		buildingDao=BuildingDao.getBuildingDao();
	}
	
	private static BuildingService buildingService;
	
	public static  BuildingService getBuildingService() {
		if  (buildingService==null){
			buildingService=new BuildingService();
		}
		return buildingService;
	}
	
	/**
	 * ��ȡ¥������
	 * @return
	 */
	public  ObservableList<String> getBuildingNames(){
		return buildingDao.getBuildingNames();
	}	
	/**
	 * ��ȡ¥��
	 * @return
	 */
	public Building getBuilding(String buildingName) {
		return buildingDao.getBuilding(buildingName);
	}
	/**
	 * ��ȡ¥������
	 * @return
	 */
	public ObservableList<String> getFloorNames(Building building){
		return buildingDao.getFloorNames(building);
	}
	/**
	 * ��ȡ��������
	 * @return
	 */
	public ObservableList<String> getRoomNames(Floor floor){
		return buildingDao.getRoomNames(floor);
	}
	/**
	 * ��ȡ��λ����
	 * @return
	 */
	public ObservableList<String> getBedNames(Room room){
		return buildingDao.getBedNames(room);
	}
	
	/**
	 * ��ȡ¥��
	 * @return
	 */
	 public Floor getFloor(Building building,String floorName) {
		 return buildingDao.getFloor(building, floorName);
	 }
	 /**
		 * ��ȡ����
		 * @return
		 */
	 public Room getRoom(Floor floor,String roomName) {
		 return buildingDao.getRoom(floor, roomName);
	 }
	 /**
		 * ��ȡ��λ
		 * @return
		 */
	 public Bed getBed(Room room, String bedName) {
		 return buildingDao.getBed(room, bedName);
	 }
	/**
	 * ֱ�ӱ�������Data ,�ȴ���ȥ,�󱣴�
	 * @param buildingData
	 */
	public void saveBuildingData(List<Building>buildingData) {
		buildingDao.setBuildingData(buildingData);
		buildingDao.saveBuildingData();
	}
	/**
	 * ��մ����ٱ���
	 * @param bedName
	 */
	public void  clearBed(String bedName){
		 buildingDao.clearBed(bedName);
		 buildingDao.saveBuildingData();
	}

	/**
	 * ��ס�Ĵ�
	 * @return
	 */
	public ObservableList<Bed> getPatientBeds(){
		return buildingDao.getPatientBeds();
	}
	/**
	 * ���д�
	 * @return
	 */
	public ObservableList<Bed> getAllBeds(){
		return buildingDao.getAllBeds();
	}
	/**
	 * ���д�
	 * @return
	 */
	public ObservableList<Bed> getFreeBeds(){
		return buildingDao.getFreeBeds();
	}
	
	/**
	 * �ж��Ƿ���ס
	 * @param patientName
	 * @return
	 */
	public boolean isPatientHasBed(String patientName) {
		return buildingDao.isPatientHasBed(patientName);
		
	}
	/**
	 * ����
	 * @param key
	 * @return
	 */
	public ObservableList<Bed> searchBeds(String key){
		return buildingDao.searchBeds(key);
	}
	/**
	 * ��ȡ���д�λ����
	 * @param room
	 * @return
	 */
	public  ObservableList<String> getFreeBedNames(Room room){
		return buildingDao.getFreeBedNames(room);
	}
	
    
}
