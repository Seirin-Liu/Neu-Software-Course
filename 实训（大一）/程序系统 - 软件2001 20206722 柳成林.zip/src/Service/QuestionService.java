package Service;

import Dao.QuestionDao;
import Entity.Question;
import javafx.collections.ObservableList;

public class QuestionService {

	private QuestionDao questionDao;
	

	public QuestionDao getQuestionDao() {
		return questionDao;
	}

	public void setQuestionDao(QuestionDao questionDao) {
		this.questionDao = questionDao;
	}

	public   QuestionService(){
		questionDao=new QuestionDao();
	}
	
	//public static QuestionService getQuestionService() {
//		if(questionService==null) {
//			questionService=new QuestionService();
//		}
//		return questionService;
//	}
	
	/**
	 * ͨ��������ȡ�����б�
	 * @param key
	 * @return
	 */
	public ObservableList<Question> getQuestionBySearch(String key){
		return questionDao.getQuestionBySearch(key);
	}
	
	
	
	public int  getNewId()
	{
		return questionDao.getNewId();
	}
	
	public void saveQuestionData(ObservableList<Question> questionData) {
		questionDao.setQuestionData(questionData);
		questionDao.saveQuestionData();
	}
}
