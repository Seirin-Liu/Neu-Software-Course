package Service;


import Dao.EmployeeDao;
import Entity.Employee;
import javafx.collections.ObservableList;

public class EmployeeService {

	private EmployeeDao employeeDao;
	
	private static  EmployeeService employeeService;
	public static EmployeeService getEmployeeService() {
		if(employeeService==null) {
			employeeService=new EmployeeService();		
		}
		return employeeService;
	}
	/**
	 * ˽�л����췽��
	 */
	private EmployeeService() {
		employeeDao =EmployeeDao.getEmployeeDao();
	}
	
	public EmployeeDao getEmployeeDao() {
		return employeeDao;
	}
	public void setEmployeeDao(EmployeeDao employeeDao) {
		this.employeeDao = employeeDao;
	}
	
	
	public boolean isEmployeeExist(String username) {
		if (employeeDao.getEmployeeByUsername(username) != null) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * ͨ������Ա��ְҵ��ȡԱ���б�
	 * @param profession
	 * @return
	 */
	public ObservableList<Employee> getEmployeeListOfProfession(String profession) {
		
		return employeeDao.getEmployeeListOfProfession(profession);
	}	
	
	/**
	 * ͨ������Ա��������ȡԱ���б�
	 * @param key
	 * @return
	 */
	public ObservableList<Employee> getEmployeeListBySearch(String key){
		
		return employeeDao.getEmployeeListBySearch(key);
		
	}
	/**
	 * Ա��ҳ���޸ĸ�����Ϣ�����浽�ļ�
	 * @param newEmployee
	 */
	public void saveNewEmployeedata(Employee newEmployee) {
		
		employeeDao.saveNewEmployeedata(newEmployee);
		employeeDao.saveEmployeeData();
	}
	
	public void saveEmployeeData(ObservableList<Employee> employeeData) {
		employeeDao.setEmployeeData(employeeData);
		employeeDao.saveEmployeeData();
	}
}
