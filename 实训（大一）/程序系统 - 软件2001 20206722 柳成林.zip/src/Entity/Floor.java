package Entity;

import java.util.ArrayList;
import java.util.List;

public class Floor {

	private String name;
	private List<Room> rooms;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<Room> getRooms() {
		return rooms;
	}

	public void setRooms(List<Room> rooms) {
		this.rooms = rooms;
	}
	/**
	 * @param name
	 * @param rooms
	 */
	public Floor(String name, List<Room> rooms) {
		super();
		this.name = name;
		this.rooms = rooms;
	}
	/**
	 * 
	 */
	public Floor() {
		super();
	}
	/**
	 * @param name
	 */
	public Floor(String name) {
		super();
		this.name = name;
		this.rooms=new ArrayList<Room>();
	}
	
//	public  ObservableList<String> getRoomNames(boolean key){
//		ObservableList<String> roomNames=FXCollections.observableArrayList();
//		for (Room r:rooms) {
//			roomNames.add(r.getName());
//		}
//		return roomNames;
//	}
//	public Room getRoom(String roomName) {
//		for(Room m:rooms) {
//			if(m.getName().equals(roomName)) {
//				return m;
//			}
//		}
//		return null;
//	}
	
	
}
