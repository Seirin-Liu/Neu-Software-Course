package Entity;

public class Assess {

	private String name;
	private String sex;
	private String moudelName;
	private String moudelType;
	private String employeeName;
	private String time;
	private String advice;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getMoudelName() {
		return moudelName;
	}
	public void setMoudelName(String moudelName) {
		this.moudelName = moudelName;
	}
	public String getMoudelType() {
		return moudelType;
	}
	public void setMoudelType(String moudelType) {
		this.moudelType = moudelType;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getAdvice() {
		return advice;
	}
	public void setAdvice(String advice) {
		this.advice = advice;
	}
	/**
	 * @param name
	 * @param sex
	 * @param moudelName
	 * @param moudelType
	 * @param employeeName
	 * @param time
	 * @param advice
	 */
	public Assess(String name, String sex, String moudelName, String moudelType, String employeeName, String time,
			String advice) {
		super();
		this.name = name;
		this.sex = sex;
		this.moudelName = moudelName;
		this.moudelType = moudelType;
		this.employeeName = employeeName;
		this.time = time;
		this.advice = advice;
	}
	/**
	 * 
	 */
	public Assess() {
		super();
	}
//	
//	public static void main(String[] args) {
//		Date date = new Date();
//		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
//		System.out.println(formatter.format(date)); 
//		Assess a=new Assess("С��", "��","ģ��һ", "A", "������", formatter.format(date) , "��");
//		JSONObject aj=(JSONObject) JSONObject.toJSON(a);
//		System.out.println(aj.toString());
//		WriteUtils.writeJson("Assesses",aj.toString() );
//	}
	
	
}
