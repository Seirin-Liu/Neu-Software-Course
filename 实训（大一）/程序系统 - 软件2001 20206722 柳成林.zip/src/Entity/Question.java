package Entity;

import javafx.scene.control.CheckBox;

public class Question {

	
	private int id;
	private String content;
	private String type;
	private String choose1;
	private String choose2;
	private String choose3;
	private  CheckBox checkBox=new CheckBox();
	

	public CheckBox getCheckBox() {
		return checkBox;
	}

	public void setCheckBox(CheckBox checkBox) {
		this.checkBox = checkBox;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getChoose1() {
		return choose1;
	}
	public void setChoose1(String choose1) {
		this.choose1 = choose1;
	}
	public String getChoose2() {
		return choose2;
	}
	public void setChoose2(String choose2) {
		this.choose2 = choose2;
	}
	public String getChoose3() {
		return choose3;
	}
	public void setChoose3(String choose3) {
		this.choose3 = choose3;
	}

	/**
	 * @param id
	 * @param content
	 * @param type
	 * @param choose1
	 * @param choose2
	 * @param choose3
	 */
	public Question(int id, String content, String type, String choose1, String choose2, String choose3) {
		super();
		this.id = id;
		this.content = content;
		this.type = type;
		this.choose1 = choose1;
		this.choose2 = choose2;
		this.choose3 = choose3;
	}

	/**
	 * 
	 */
	public Question() {
		super();
		
	}
	
//	public static void main(String[] args) {
//	Question q=new Question("1","��ϲ����ʲô","A","�����","����","ɳ��") ;
//	JSONObject qo=(JSONObject) JSONObject.toJSON(q);	
//		System.out.println(qo.toString());
//		WriteUtils.writeJson("Questions",qo.toString() );
//	}
	
	
	
	
}
