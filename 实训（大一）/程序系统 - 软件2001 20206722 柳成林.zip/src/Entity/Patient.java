package Entity;


import javafx.scene.control.CheckBox;

public class Patient {
	private String name;  //����
	private String sex;   //�Ա�
	private String birthday; //����
	private String id;     //����֤��
	private String tel; //�绰
	private String emergencyContact; //������ϵ��
	private String emConTel; //������ϵ�˵绰
	private Assess assessRecord; //������¼
	
	
	private CheckBox checkBox=new CheckBox();
	
	
	public Assess getAssessRecord() {
		return assessRecord;
	}
	public void setAssessRecord(Assess assessRecord) {
		this.assessRecord = assessRecord;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getBirthday() {
		return birthday;
	}
	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getEmergencyContact() {
		return emergencyContact;
	}
	public void setEmergencyContact(String emergencyContact) {
		this.emergencyContact = emergencyContact;
	}
	public String getEmConTel() {
		return emConTel;
	}
	public void setEmConTel(String emConTel) {
		this.emConTel = emConTel;
	}
	
	public CheckBox getCheckBox() {
	return checkBox;
	}
	public void setCheckBox(CheckBox checkBox) {
		this.checkBox = checkBox;
	}
	/**
	 * @param name
	 * @param sex
	 * @param birthday
	 * @param id
	 * @param tel
	 * @param emergencyContact
	 * @param emConTel
	 */
	public Patient(String name, String sex, String birthday, String id, String tel, String emergencyContact,
			String emConTel) {
		super();
		this.name = name;
		this.sex = sex;
		this.birthday = birthday;
		this.id = id;
		this.tel = tel;
		this.emergencyContact = emergencyContact;
		this.emConTel = emConTel;
		this.assessRecord=null;
	}
	/**
	 * 
	 */
	public Patient() {
		super();
	}
	
//	public static void main(String[] args) {
//		Patient p=new Patient("С��","��","1999-2-3","1323221324","112341312542","����","221235664");
//		JSONObject ps =(JSONObject)JSONObject.toJSON(p);
//		WriteUtils.writeJson("Patients", ps.toString());
//		System.out.println("111");
//	}
	
	
	

}
