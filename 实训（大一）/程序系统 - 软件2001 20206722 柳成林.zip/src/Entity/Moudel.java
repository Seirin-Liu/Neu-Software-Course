package Entity;

import java.util.List;

import javafx.scene.control.CheckBox;

public class Moudel {
	private int  id;
	private String name;
	private List<Question> questions;
	private String type;
	private CheckBox checkBox=new CheckBox();
		
	public CheckBox getCheckBox() {
		return checkBox;
	}
	public void setCheckBox(CheckBox checkBox) {
		this.checkBox = checkBox;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<Question> getQuestions() {
		return questions;
	}
	public void setQuestions(List<Question> questions) {
		this.questions = questions;
	}

	/**
	 * @param id
	 * @param name
	 * @param questions
	 * @param type
	 * @param checkBox
	 */
	public Moudel(int id, String name, List<Question> questions, String type) {
		super();
		this.id = id;
		this.name = name;
		this.questions = questions;
		this.type = type;
		
	}
	/**
	 * 
	 */
	public Moudel() {
		super();
	}


//	public static void main(String[] args) {
//		ObservableList<Question> questions=new QuestionDao().getQuestionData();
//		Moudel moudel =new Moudel(1, "ģ��һ", questions, "A");
//		JSONObject mj= (JSONObject) JSONObject.toJSON(moudel);
//		System.out.println(mj.toString());	
//	}
//	
}
