package Entity;

import java.util.ArrayList;
import java.util.List;

public class RareRoom  extends Room{

	private String rareType;
	private int max;
	private int now;
	private List<String> userId;
	
	
	public List<String> getUserId() {
		return userId;
	}
	public void setUserId(List<String> userId) {
		this.userId = userId;
	}
	public String getRareType() {
		return rareType;
	}
	public void setRareType(String rareType) {
		this.rareType = rareType;
	}
	public int getMax() {
		return max;
	}
	public void setMax(int max) {
		this.max = max;
	}
	public int getNow() {
		return now;
	}
	public void setNow(int now) {
		this.now = now;
	}
	/**
	 * @param name
	 * @param beds
	 * @param isRare
	 * @param rareType
	 * @param max
	 * @param now
	 */
	public RareRoom(String name,  String rareType, int max) {
		super(name,true);
		this.rareType = rareType;
		this.max = max;
		this.now = 0;
		this.userId=new ArrayList<String>();
		}
	/**
	 * @param name
	 * @param beds
	 * @param isRare
	 */
	public RareRoom(String name, List<Bed> beds, boolean isRare) {
		super(name, beds, isRare);
	}
	
	
	
	public RareRoom() {
		
	}

	 
	
	
}
