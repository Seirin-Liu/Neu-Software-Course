package Entity;

import java.util.ArrayList;
import java.util.List;

public class Room {

	private String name;
	private List<Bed> beds;
	private  boolean isRare=false;
	
	public boolean isRare() {
		return isRare;
	}
	public void setRare(boolean isRare) {
		this.isRare = isRare;
	}
	public String getName() {
		
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<Bed> getBeds() {
		return beds;
	}
	public void setBeds(List<Bed> beds) {
		this.beds = beds;
	}
	/**
	 * @param name
	 * @param beds
	 * @param isRare
	 */
	public Room(String name, List<Bed> beds, boolean isRare) {
		super();
		this.name = name;
		this.beds = beds;
		this.isRare = isRare;
	}
	/**
	 * 
	 */
	public Room() {
		super();
	}
	/**
	 * ����ϡ�з���ʱ���ã��Զ�����ϡ��ֵΪtrue
	 * @param name
	 */
	public Room(String name,boolean isRare) {
		super();
		this.name = name;
		this.beds=new ArrayList<Bed>();
		this.isRare=isRare;
	}
	/**
	 * ������ͨ����ʱ���ã�����ϡ��ֵΪfalse
	 * @param name
	 */
	public Room(String name) {
		super();
		this.name = name;
		this.beds=new ArrayList<Bed>();
	}
	
	
//	public ObservableList<String> getBedNames(boolean key ) {
//		
//		ObservableList<String> bedNames=FXCollections.observableArrayList();
//		if(beds.size()==0) {
//			return null;
//		}
//		for(Bed b:beds) {
//			bedNames.add(b.getName());
//		}
//		return bedNames;	
//	}
//	
//	
//	
//	public ObservableList<String> getFreeBedNames(boolean key) {
//		ObservableList<String> bedNames=FXCollections.observableArrayList();
//		if(beds.size()==0) {
//			return null;
//		}
//		for(Bed b:beds) {
//			if(b.getStatus().equals("δ��ס")) {
//			bedNames.add(b.getName());}
//		}
//		return bedNames;	
//	}
//	
//	
//	public Bed getBed(String bedName) {
//	   for(Bed b:beds) {
//		if(b.getName().equals(bedName)) {
//			return b;
//		}
//	}
//		return null;
//	}

	
	
	
}
