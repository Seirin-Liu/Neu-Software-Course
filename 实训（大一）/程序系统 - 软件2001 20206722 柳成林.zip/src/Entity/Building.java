package Entity;

import java.util.ArrayList;
import java.util.List;

public class Building {

	private String name;
	private List<Floor> floors;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<Floor> getFloors() {
		return floors;
	}
	public void setFloors(List<Floor> floors) {
		this.floors = floors;
	}
	/**
	 * @param name
	 * @param floors
	 */
	public Building(String name, List<Floor> floors) {
		super();
		this.name = name;
		this.floors = floors;
	}
	/**
	 * 
	 */
	public Building() {
		super();
	}
	/**
	 * @param name
	 */
	public Building(String name) {
		super();
		this.name = name;
		this.floors=new ArrayList<Floor>();
	}
	

//	public  ObservableList<String> getFloorNames(){
//		 ObservableList<String> floorNames=FXCollections.observableArrayList();
//		 for(Floor f:floors) {
//			 floorNames.add(f.getName());
//		 }
//		 return floorNames;
//	}
//	 public Floor getFloor(String floorName) {
//		 for (Floor f:floors) {
//			 if(f.getName().equals(floorName)) {
//				 return f;
//			 }
//		 }
//		 return null;
//	 }
	 
	 
}
