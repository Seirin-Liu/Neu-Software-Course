
package Entity;

import javafx.scene.control.CheckBox;

public class Employee {
	private String name;
	private String username;
	private String password;
	private String birthday;
	private String id;//����֤��
	private String speciality;//ר��
	private String profession ;//ְҵ
	
	private CheckBox checkBox=new CheckBox();;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getSpeciality() {
		return speciality;
	}
	public void setSpeciality(String speciality) {
		this.speciality = speciality;
	}
	public String getProfession() {
		return profession;
	}
	public void setProfession(String profession) {
		this.profession = profession;
	}
	
	public String getBirthday() {
		return birthday;
	}
	
	public CheckBox getCheckBox() {
		return checkBox;
	}
	public void setCheckBox(CheckBox checkBox) {
		this.checkBox = checkBox;
	}
	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	/**
	 * @param name
	 * @param username
	 * @param password
	 * @param id
	 * @param speciality
	 * @param profession
	 */
	public Employee(String username, String password) {
		super();
		this.name = "name";
		this.username = username;
		this.password = password;
		this.birthday="1999-1-1";
		this.id ="00000000000";
		this.speciality = "��";
		this.profession = "��";
		
	}
	/**
	 * 
	 */
	public Employee() {
		super();
	}
	
	
//	public static void main(String[] args) {
//		
//	
//
//	}

}
