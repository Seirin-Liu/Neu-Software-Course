package Entity;

public class Bed {

	private String   name;
	private String patientName;
	private String patientSex;
	private String patientAge;
	private String recordId;
	private String startTime;
	private String endTime;
	private String status;
	
	
	
	/**
	 * @param name
	 * @param patientName
	 * @param patientSex
	 * @param patientAge
	 * @param recordId
	 * @param startTime
	 * @param endTime
	 * @param status
	 */
	public Bed(String name, String patientName, String patientSex, String patientAge, String recordId, String startTime,
			String endTime, String status) {
		super();
		this.name = name;
		this.patientName = patientName;
		this.patientSex = patientSex;
		this.patientAge = patientAge;
		this.recordId = recordId;
		this.startTime = startTime;
		this.endTime = endTime;
		this.status = status;
	}
	public String getPatientAge() {
		return patientAge;
	}
	public void setPatientAge(String patientAge) {
		this.patientAge = patientAge;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public String getPatientSex() {
		return patientSex;
	}
	public void setPatientSex(String patientSex) {
		this.patientSex = patientSex;
	}
	public String getRecordId() {
		return recordId;
	}
	public void setRecordId(String recordId) {
		this.recordId = recordId;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * @param name
	 * @param patient
	 */
	public Bed(String name) {
		super();
		this.name = name;
		this.patientName =null;
		this.status="δ��ס";
	    this.endTime=null;
	    this.patientAge=null;
	    this.recordId=null;
	    this.patientSex=null;
	    this.startTime=null;
	    this.endTime=null;
	}
	/**
	 * 
	 */
	public Bed() {
		super();
	}
	/**
	 * @param name
	 * @param patient
	 * @param status
	 */

//	public static void main(String[] args) {
//		Bed bed=new Bed("111", "111",  "111",  "111",  "111",  "111",  "111",  "111");
//	
//		JSONObject bj=(JSONObject) JSONObject.toJSON(bed);
//		WriteUtils.writeJson("PatientBeds", bj.toString());
//		
//	
//	}
}
