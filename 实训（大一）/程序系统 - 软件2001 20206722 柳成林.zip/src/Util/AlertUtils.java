package Util;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.stage.Stage;

public class AlertUtils {

	/**
	 * ���󵯴�
	 * 
	 * @param message
	 * @param txt
	 * @param ownerStage
	 */
	public static void newErrorAlert(String message, String txt, Stage ownerStage) {
		Alert alert = new Alert(AlertType.ERROR);
		alert.initOwner(ownerStage);
		alert.setTitle("����");
		alert.setHeaderText(txt);
		alert.setContentText(message);
		alert.showAndWait();
	}

	/**
	 * ��ʾ����
	 * 
	 * @param message
	 * @param txt
	 * @param ownerStage
	 */
	public static void newRmindAlert(String message, String txt, Stage ownerStage) {
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.initOwner(ownerStage);
		alert.setTitle("��ʾ");
		alert.setHeaderText(txt);
		alert.setContentText(message);
		alert.showAndWait();
	}

	/**
	 * ����ȷ��ѯ�ʿ򣬵��ȷ������true
	 * 
	 * @param message
	 * @param txt
	 * @param ownerStage
	 * @return
	 */
	public static boolean newQureAlert(String message, String txt, Stage ownerStage) {
		Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.initOwner(ownerStage);
		alert.setTitle("  ");
		alert.setHeaderText(txt);
		alert.setContentText(message);
		alert.showAndWait();
		if (alert.getResult().equals(ButtonType.OK)) {
			return true;
		} else {
			return false;
		}

	}

	/**
	 * ��ʾ����
	 * 
	 * @param message
	 * @param txt
	 * @param ownerStage
	 */
	public static void newAlert(String message, String txt, Stage ownerStage) {
		Alert alert = new Alert(AlertType.NONE);
		alert.initOwner(ownerStage);
		alert.setTitle("��ʾ");
		alert.setHeaderText(txt);
		alert.setContentText(message);
		alert.show(); // ���ﲻ����wait,��ز���
	}
}
