package Util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.alibaba.fastjson.JSONObject;

import Entity.Assess;
import Entity.Bed;
import Entity.Building;
import Entity.Employee;
import Entity.Manager;
import Entity.Moudel;
import Entity.Patient;
import Entity.Question;
import Entity.RareRoom;
import javafx.collections.ObservableList;

public class WriteUtils {
	
	/**
	 *���ļ���д��һ���ַ��������ı���ǰ������
	 * @param filename
	 * @param line
	 */
   public static void writeJson(String filename,String line) {
	 
		File file =new File(".\\documents\\"+filename+".txt");
		try {
			BufferedWriter bw=new BufferedWriter(new FileWriter(file,true));
			bw.write(line+"\n");
			
			bw.flush();
			bw.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		   
   }
   
   /**
    * д�����Ա��Ϣ
    * @param filename
    * @param managerList
    */
   public static void writeManagerData(String filename,List<Manager> managerList) {
		File file =new File(".\\documents\\"+filename+".txt");
		
		try {
			BufferedWriter bw=new BufferedWriter(new FileWriter(file,false));
			StringBuilder sb=new StringBuilder();
			for(Manager m:managerList) {
				JSONObject mj=(JSONObject) JSONObject.toJSON(m);
				sb.append(mj.toString()+"\n");
			}
			bw.write(sb.toString());
			bw.flush();
			bw.close();
			
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	   
	   
   }
   /**
    * д��Ա����Ϣ
    * 
    * @param filename
    * @param employeeList
    */
   public static void writeEmployeeData(String filename,ObservableList<Employee> employeeList) {
		 
		File file =new File(".\\documents\\"+filename+".txt");
		try {
			BufferedWriter bw=new BufferedWriter(new FileWriter(file,false));
			StringBuilder sb=new StringBuilder();
			for(Employee e:employeeList) {
				JSONObject ej= new JSONObject();
				ej.put("name", e.getName());
				ej.put("username", e.getUsername());
				ej.put("password", e.getPassword());
				ej.put("birthday", e.getBirthday());
				ej.put("id", e.getId());
				ej.put("speciality", e.getSpeciality());
				ej.put("profession", e.getProfession());
				sb.append(ej.toString()+"\n");
		    //sb.append(((JSONObject)JSONObject.toJSON(e)).toString()+"\n");
			}
			bw.write(sb.toString());
			bw.flush();
			bw.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		   
  }
   
   /**
    * д�뻼����Ϣ
    * @param filename
    * @param patientData
    */
   public static void writePatientData(String filename,ObservableList<Patient> patientData) {
	   
		File file =new File(".\\documents\\"+filename+".txt");
		try {
			BufferedWriter bw=new BufferedWriter(new FileWriter(file,false));
			StringBuilder sb=new StringBuilder();
			for(Patient p:patientData) {
				JSONObject pj=new JSONObject();
				pj.put("name", p.getName());
				pj.put("sex", p.getSex());
				pj.put("birthday", p.getBirthday());
				pj.put("id", p.getId());
				pj.put("tel", p.getTel());
				pj.put("emergencyContact", p.getEmergencyContact());
				pj.put("emConTel", p.getEmConTel());
				pj.put("assessRecord", p.getAssessRecord());
				sb.append(pj.toString()+"\n");
			}
			bw.write(sb.toString());
			bw.flush();
			bw.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
   }
   
   /**
    * �������б�д���ļ�
    * @param filename
    * @param questionData
    */
   public static void writeQuestionData(String filename,ObservableList<Question> questionData) {
		File file =new File(".\\documents\\"+filename+".txt");
		try {
			BufferedWriter bw=new BufferedWriter(new FileWriter(file,false));
			StringBuilder sb=new StringBuilder();
			for(Question q:questionData) {
				JSONObject qj=new JSONObject();
				qj.put("id", q.getId());
				qj.put("content", q.getContent());
				qj.put("choose1", q.getChoose1());
				qj.put("choose2", q.getChoose2());
				qj.put("choose3", q.getChoose3());
				qj.put("type", q.getType());	
				sb.append(qj.toString()+"\n");
			}
			bw.write(sb.toString());
			bw.flush();
			bw.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
   }
   
   public static void writeMoudelData(String filename,ObservableList<Moudel>moudelData) {
	   File file =new File(".\\documents\\"+filename+".txt");
	   try {
			BufferedWriter bw=new BufferedWriter(new FileWriter(file,false));
			StringBuilder sb=new StringBuilder();
			for(Moudel m:moudelData) {
			JSONObject mj=new JSONObject();
			mj.put("id", m.getId());
				mj.put("type", m.getType());
				mj.put("name", m.getName());
				List<JSONObject> jList=new ArrayList<JSONObject>();
				for(Question q:m.getQuestions()) {	
					JSONObject qj=new JSONObject();
					qj.put("id", q.getId());	
					qj.put("content", q.getContent());
					qj.put("choose1", q.getChoose1());
					qj.put("choose2", q.getChoose2());
					qj.put("choose3", q.getChoose3());
					qj.put("type", q.getType());
				jList.add(qj);
				}
				mj.put("questions", jList);		
				sb.append(mj.toString()+"\n");
			}
			bw.write(sb.toString());
			bw.flush();
			bw.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
   }
   
   public static void writeAssessData(String filename,ObservableList<Assess> assessList) {
		File file =new File(".\\documents\\"+filename+".txt");
		try {
			BufferedWriter bw=new BufferedWriter(new FileWriter(file,false));
			StringBuilder sb=new StringBuilder();
			for(Assess m:assessList) {
				JSONObject mj=(JSONObject) JSONObject.toJSON(m);
				sb.append(mj.toString()+"\n");
			}
			bw.write(sb.toString());
			bw.flush();
			bw.close();
			
		}
		catch (IOException e) {
			e.printStackTrace();
		}
   }
   public static void writeNewAssess(String filename,Assess assess) {
		File file =new File(".\\documents\\"+filename+".txt");
		try {
			BufferedWriter bw=new BufferedWriter(new FileWriter(file,true));
			StringBuilder sb=new StringBuilder();	
			JSONObject mj=(JSONObject) JSONObject.toJSON(assess);
			sb.append(mj.toString()+"\n");
			bw.write(sb.toString());
			bw.flush();
			bw.close();
			
		}
		catch (IOException e) {
			e.printStackTrace();
		}
  }
   
   public static void writeBuildingData(String filename, List<Building> buildingData) {
			File file =new File(".\\documents\\"+filename+".txt");
			try {
				BufferedWriter bw=new BufferedWriter(new FileWriter(file,false));
				StringBuilder sb=new StringBuilder();
				for(Building m:buildingData) {
					JSONObject mj=new JSONObject();
					mj.put("name", m.getName());
					mj.put("floors", m.getFloors());
					sb.append(mj.toString()+"\n");
				}
				bw.write(sb.toString());
				bw.flush();
				bw.close();
				
			}
			catch (IOException e) {
				e.printStackTrace();
			}
	   }
   public static void writeBedData(String filename,ObservableList<Bed> bedData) {
		File file =new File(".\\documents\\"+filename+".txt");
		try {
			BufferedWriter bw=new BufferedWriter(new FileWriter(file,false));
			StringBuilder sb=new StringBuilder();
			for(Bed m:bedData) {
				JSONObject mj=(JSONObject) JSONObject.toJSON(m);
				sb.append(mj.toString()+"\n");
			}
			bw.write(sb.toString());
			bw.flush();
			bw.close();
			
		}
		catch (IOException e) {
			e.printStackTrace();
		}
   }
   
   public static void writeRareRoomData(String filename,ObservableList<RareRoom> RareRoomData) {
		File file =new File(".\\documents\\"+filename+".txt");
		try {
			BufferedWriter bw=new BufferedWriter(new FileWriter(file,false));
			StringBuilder sb=new StringBuilder();
			for(RareRoom m:RareRoomData) {
				JSONObject mj=(JSONObject) JSONObject.toJSON(m);
				sb.append(mj.toString()+"\n");
			}
			bw.write(sb.toString());
			bw.flush();
			bw.close();
			
		}
		catch (IOException e) {
			e.printStackTrace();
		}
   }

	   
}
