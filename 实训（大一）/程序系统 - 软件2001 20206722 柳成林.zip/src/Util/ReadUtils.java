package Util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.alibaba.fastjson.JSON;

import Entity.Assess;
import Entity.Bed;
import Entity.Building;
import Entity.Employee;
import Entity.Manager;
import Entity.Moudel;
import Entity.Patient;
import Entity.Question;
import Entity.RareRoom;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class ReadUtils {	
	/**
	 * 
	 * @param file
	 * @return
	 */
	public static String getAllJson(String filename) 
	{	
		StringBuilder sb=new StringBuilder();
		File file =new File(".\\documents\\"+filename+".txt");
		if (!file.exists()) {
			try {
				file.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String line = null;
			while( (line=br.readLine())!=null) {
				sb.append(line+"/");   
			}
			br.close();			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return sb.toString();
	}
	/**
	 * 
	 * @param filename
	 * @return
	 */
	public static List<Manager> readManagerList(String filename){
		String allJson=ReadUtils.getAllJson(filename);
		if(allJson.length()==0) {
			return null;
		}
		else{
			String[] managers =allJson.split("/");
		    List<Manager> managerList = new ArrayList<Manager>();		
	    for (String mJson : managers) {		    	
	    	Manager m = JSON.parseObject(mJson, new Manager().getClass());
			managerList.add(m);
		  }
          return managerList;
		}	
	}	
	
	public static List<Employee> readEmployeeData(String filename){
		String allJson=ReadUtils.getAllJson(filename);
		if(allJson.length()==0) {
			return null;
		}
		else{
			String[] employees =allJson.split("/");
		    List<Employee> employeeList = new ArrayList<Employee>();		
	    for (String mJson : employees) {		
	    	Employee m = JSON.parseObject(mJson, new Employee().getClass());
			employeeList.add(m);
		  }
          return employeeList;
		}	
	}	
	
	public static  ObservableList<Patient> readPatientData(String filename){	
		String allJson=ReadUtils.getAllJson(filename);
		if(allJson.length()==0) {
			return null;
		}
		else {	
			String[] patients =allJson.split("/");
			ObservableList<Patient> patientData= FXCollections.observableArrayList();
			for(String pJson:patients) {			
				Patient p= JSON.parseObject(pJson, new Patient().getClass());
				patientData.add(p);
			}			
		return patientData;
		}
	}
	
	public static ObservableList<Question> readQuestionData(String filename){
		String allJson=ReadUtils.getAllJson(filename);
		if(allJson.length()==0) {
			return null;
		}
		else {
			String[]questions =allJson.split("/");
			ObservableList<Question> questionData= FXCollections.observableArrayList();
			for(String qJson:questions) {			
				Question q=JSON.parseObject(qJson, new Question().getClass());
				questionData.add(q);			
			}
			return questionData;
		}
	}
	
	public static ObservableList<Moudel> readMoudelData(String filename){
		String allJson=ReadUtils.getAllJson(filename);
		if(allJson.length()==0) {
			return null;
		}
		else {
			String[] moudels=allJson.split("/");
			ObservableList<Moudel> moudelData=FXCollections.observableArrayList();
			for(String mJson :moudels ) {
				Moudel m=JSON.parseObject(mJson, new Moudel().getClass());
				moudelData.add(m);		
			}
			return  moudelData;
		}
	}
	
	public static ObservableList<Assess> readAssessData(String filename){
		String allJson=ReadUtils.getAllJson(filename);
		if(allJson.length()==0) {
			return null;
		}
		else {
			String[] assesss=allJson.split("/");
			ObservableList<Assess> assessData=FXCollections.observableArrayList();
			for(String mJson :assesss ) {
				Assess m=JSON.parseObject(mJson, new Assess().getClass());
				assessData.add(m);		
			}
			return  assessData;
		}
	}
	
	public static List<Building> readBuildingData(String filename){
		String allJson=ReadUtils.getAllJson(filename);
		if(allJson.length()==0) {
			return null;
		}
		else{
			String[] Buildings =allJson.split("/");
		    List<Building> BuildingList = new ArrayList<Building>();		
	    for (String mJson : Buildings) {		    	
	    	Building m = JSON.parseObject(mJson, new Building().getClass());
			BuildingList.add(m);
		  }
          return BuildingList;
		}	
	}	
	
	public static ObservableList<Bed> readBedData(String filename){
		String allJson=ReadUtils.getAllJson(filename);
		if(allJson.length()==0) {
			return null;
		}
		else{
			String[] Beds =allJson.split("/");
		    ObservableList<Bed> BedList = FXCollections.observableArrayList();		
	    for (String mJson : Beds) {		    	
	    	Bed m = JSON.parseObject(mJson, new Bed().getClass());
			BedList.add(m);
		  }
          return BedList;
		}	
	}	
	
	public static ObservableList<RareRoom> readRareRoomData(String filename){
		String allJson=ReadUtils.getAllJson(filename);
		if(allJson.length()==0) {
			return null;
		}
		else{
			String[] RareRooms =allJson.split("/");
		    ObservableList<RareRoom> RareRoomList = FXCollections.observableArrayList();		
	    for (String mJson : RareRooms) {		    	
	    	RareRoom m = JSON.parseObject(mJson, new RareRoom().getClass());
			RareRoomList.add(m);
		  }
          return RareRoomList;
		}	
	}	
		
}
