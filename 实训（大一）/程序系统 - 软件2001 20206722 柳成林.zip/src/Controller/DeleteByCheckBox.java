package Controller;

public interface DeleteByCheckBox {
	public int deleteByCheckBox() ;
}
