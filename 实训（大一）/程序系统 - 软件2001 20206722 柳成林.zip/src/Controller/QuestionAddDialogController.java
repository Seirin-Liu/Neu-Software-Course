package Controller;

import Entity.Question;
import Service.QuestionService;
import Util.AlertUtils;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * �����������
 * @author Seirin
 *
 */
public class QuestionAddDialogController implements InputValidInterface{


	  private  Stage dialogStage;
	  private Question newQuestion;//�µ�����
	  private boolean okClicked=false;
	  
	private QuestionService queService;

    public QuestionService getQueService() {
		return queService;
	}

	public void setQueService(QuestionService queService) {
		this.queService = queService;
	}

	public Stage getDialogStage() {
		return dialogStage;
	}

	public void setDialogStage(Stage dialogStage) {
		this.dialogStage = dialogStage;
	}

	public Question getNewQuestion() {
		return newQuestion;
	}

	public void setNewQuestion(Question newQuestion) {
		this.newQuestion = newQuestion;
	}

	public boolean isOkClicked() {
		return okClicked;
	}

	public void setOkClicked(boolean okClicked) {
		this.okClicked = okClicked;
	}

	@FXML
    private TextField idTextField;

    @FXML
    private TextField choose3TextField;

    @FXML
    private TextField choose1TextField;

    @FXML
    private Button cancelButton;

    @FXML
    private ComboBox<String> typeComboBox;

    @FXML
    private TextField choose2TextField;

    @FXML
    private TextField contentTextField;

    @FXML
    private Button okButton;
    
    @FXML
	private void initialize() {
    	ObservableList<String> options = 
    FXCollections.observableArrayList(
	    	"A",
	    	"B",
	    	"C",
	    	"D",
	    	"E"	               
	    );  	
    	queService=new QuestionService();
    	typeComboBox.setItems(options);
    	typeComboBox.setValue("A");
    	idTextField.setText(""+queService.getNewId()+" (�Զ�����)");
    	idTextField.setEditable(false);
    }

    @FXML
    void okEvent(ActionEvent event) {
    	if(isInputValid()) {
    	newQuestion=new Question(queService.getNewId(), contentTextField.getText(), typeComboBox.getValue(), choose1TextField.getText(),
    			choose2TextField.getText(),choose3TextField.getText());
    	okClicked=true;
    	dialogStage.close();
    	}
    }

    @FXML
    void cancelEvent(ActionEvent event) {

    }


		@Override
		public boolean isInputValid() {
			// TODO Auto-generated method stub
			 String errorMessage = "";    
			 
//	         if (idTextField.getText() == null || idTextField.getText().length() == 0) {
//	             errorMessage += "���Ϊ��\n"; 
//	         }	
	         if (contentTextField.getText() == null || contentTextField.getText().length() == 0) {
	             errorMessage += "����Ϊ��\n"; 
	         }	        
	         if (typeComboBox.getValue() == null ||typeComboBox.getValue().length() == 0) {
	             errorMessage += "����Ϊ��\n"; 
	         }	        
	         
	         if (choose1TextField.getText() == null || choose1TextField.getText().length() == 0) {
	             errorMessage += "ѡ��1Ϊ��\n"; 
	         }	        
	         
	         if (choose2TextField.getText() == null || choose2TextField.getText().length() == 0) {
	             errorMessage += "ѡ��2Ϊ��\n"; 
	         }	   
	         if (choose3TextField.getText() == null || choose3TextField.getText().length() == 0) {
	             errorMessage += "ѡ��3Ϊ��\n"; 
	         }	     	                            
	         if (errorMessage.length() == 0) {
	             return true;
	             
	         } else {
	        	 
	             AlertUtils.newErrorAlert(errorMessage, "��������Ч����", dialogStage);	             
	             return false;
	         }
	    	
	    }
    
}
