package Controller;

import java.io.IOException;

import Entity.Moudel;
import Service.MoudelService;
import Util.AlertUtils;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Callback;

/**
 * ģ�����
 * @author Seirin
 *
 */
public class MoudelSceneController  implements TabReLoadInterface,DeleteByCheckBox{

	private Stage employeeStage; //Stage
	
	private ObservableList<Moudel> moudelData;//���ļ��ж�ȡ��ģ���б�     
	private ObservableList<Moudel> moudelList;//��ǰ��ʾ��ģ���б�����������ˢ�¡�
	
	private MoudelService mouService;
	
	private MoudelAddDialogController addController;//���ӽ���
	private MoudelModifyDialogController modifyController;//�޸Ľ���
	private MoudelQuestionsDialogController  questionsController;//
	
    public Stage getEmployeeStage() {
		return employeeStage;
	}

	public void setEmployeeStage(Stage employeeStage) {
		this.employeeStage = employeeStage;
	}

	@FXML
    private Button deletButton;

    @FXML
    private Button contentButton;

    @FXML
    private Button searchButton;

    @FXML
    private Button modifyButton;

    @FXML
    private TextField searchField;

    @FXML
    private TableColumn<Moudel, String> titleColumn;

    @FXML
    private TableColumn<Moudel, CheckBox> checkBoxColumn;

    @FXML
    private Button addButton;

    @FXML
    private Button saveButton;

    @FXML
    private TableColumn<Moudel, String> typeColumn;

    @FXML
    private TableView<Moudel> moudelTableView;

    @FXML
    private TableColumn<Moudel, String> idColumn;
    
    @FXML
    private void initialize() {
    		mouService=MoudelService.getMoudelService();
    		moudelData=mouService.getMoudelDao().getMoudelData();
    		moudelList=moudelData;
    		reflushMoudelTableView(moudelList);
    }

    @FXML
    void addEvent(ActionEvent event) {

    	if(showMoudelAddDialog()) {
    		Moudel m=addController.getNewMoudel();
    		moudelData.add(m);
    		mouService.saveMoudelData(moudelData);
        	AlertUtils.newRmindAlert("���ӳɹ�\n����ɹ�", "���ӳɹ�", employeeStage);
    		reflushMoudelTableView(moudelData);
    	}
    }

    @FXML
    void deleteEvent(ActionEvent event) {
    	int key =deleteByCheckBox();
		if (key==1) {
			mouService.saveMoudelData(moudelData);
        	AlertUtils.newRmindAlert("ɾ���ɹ�\n����ɹ�", "ɾ���ɹ�", employeeStage);
		} else if (key==0){
			AlertUtils.newErrorAlert("error��δѡ��ɾ������", "��ѡ��ɾ������", employeeStage);
			return;
		}
		else {
			return;
		}
    }
    	

    @FXML
    void modifyEvent(ActionEvent event) {

    	Moudel p = moudelTableView.getSelectionModel().getSelectedItem();
		if (p == null) {
			AlertUtils.newErrorAlert("error��δѡ���޸Ķ���", "��ѡ���޸Ķ���", employeeStage);
			return;
		}
		int index = moudelTableView.getItems().indexOf(p);
		if (showMoudelModifyDialog(p)) {
			if (AlertUtils.newQureAlert("���ȷ���޸Ļ�����Ϣ", "�Ƿ�ȷ���޸ģ�", employeeStage)) {
			p = modifyController.getModifiedMoudel(); // ���ڵ�p�Ѿ����޸���
			moudelTableView.getItems().set(index, p);
			mouService.saveMoudelData(moudelData);
			AlertUtils.newRmindAlert("�޸ĳɹ�", "�޸ĳɹ�", employeeStage);
			}
		}
    }

    @FXML
    void saveEvent(ActionEvent event) {

    	mouService.saveMoudelData(moudelData);
    	AlertUtils.newRmindAlert("����ɹ�", "����ɹ�", employeeStage);
    	
    }

    @FXML
    void seeContentEvent(ActionEvent event) {
     	Moudel p = moudelTableView.getSelectionModel().getSelectedItem();
    		if (p == null) {
    			AlertUtils.newErrorAlert("error��δѡ���޸Ķ���", "��ѡ���޸Ķ���", employeeStage);
    			return;
    		}
    		showMoudelQuestionsDialog(p);
 			 
    	
    }

    @FXML
    void searchEvent(ActionEvent event) {

    	if (searchField.getText() == null || searchField.getText().length() == 0) {
    		reflushMoudelTableView(moudelData);
    		return;    	
    		}
    	moudelList=mouService.getMoudelBySearch(searchField.getText());
    	if(moudelList.size()==0) {
    		AlertUtils.newErrorAlert("�����Ÿı������ؼ���", "���Ҳ�������", employeeStage);
    	}
    	reflushMoudelTableView(moudelList);
    	
    }
    
   public void  reflushMoudelTableView(ObservableList<Moudel> moudelList) {
	   moudelTableView.setItems(moudelList);
	   idColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Moudel, String>, ObservableValue<String>>() {
					@Override
					public ObservableValue<String> call(CellDataFeatures<Moudel, String> param) {
						// TODO Auto-generated method stub
						int id=param.getValue().getId();
						String ss=""+id;
						SimpleStringProperty s = new SimpleStringProperty(ss);
						return s;
					}
				});
	   typeColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Moudel, String>, ObservableValue<String>>() {
					@Override
					public ObservableValue<String> call(CellDataFeatures<Moudel, String> param) {
						// TODO Auto-generated method stub
						SimpleStringProperty s = new SimpleStringProperty(param.getValue().getType());
						return s;
					}
				});
	   titleColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Moudel, String>, ObservableValue<String>>() {
					@Override
					public ObservableValue<String> call(CellDataFeatures<Moudel, String> param) {
						// TODO Auto-generated method stub
						SimpleStringProperty s = new SimpleStringProperty(param.getValue().getName());
						return s;
					}
				});
	   
	   checkBoxColumn.setCellValueFactory(new PropertyValueFactory<Moudel, CheckBox>("checkBox"));
	   
   }
   public int deleteByCheckBox() {
		int i=0;
		for (Moudel p:moudelList) {
			if(p.getCheckBox().isSelected()) {
				i++;break;
			}
		}
		if(i==0) {return 0;}
		if (AlertUtils.newQureAlert("���ȷ��ɾ������\n���ȡ������", "ȷ���Ƿ�ɾ����", employeeStage)) {
		int index = -1;
		moudelList = moudelTableView.getItems();
		Moudel e;
		for ( i = 0; i < moudelList.size(); i++) {
			e = moudelList.get(i);
			if (e.getCheckBox().isSelected()) {
				index = moudelTableView.getItems().indexOf(e);
				moudelTableView.getItems().remove(index);
				moudelData.remove(e);
				i--;
			}
		}	
		if (index != -1) {
			return 1;
		} else {
			return 0;
		}
	}
		return 2;		
	}
   
   public boolean showMoudelAddDialog() {
	   try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("/View/MoudelAddDialog.fxml"));
			AnchorPane page = (AnchorPane) loader.load();
			// Create the dialog Stage.
			Stage dialogStage = new Stage();
			dialogStage.setTitle("����");
			dialogStage.initOwner(employeeStage);
			dialogStage.initModality(Modality.WINDOW_MODAL); // ��������Ժ���벻�ܵ�ԭ����stage
			dialogStage.setWidth(800.0);
			dialogStage.setHeight(360.0);
			dialogStage.setResizable(false);
			Scene scene = new Scene(page);
			scene.getStylesheets().add(getClass().getResource("/View/Dialog.css").toExternalForm());
			dialogStage.setScene(scene);
			addController = loader.getController();
			addController.setDialogStage(dialogStage);
			// Show the dialog and wait until the user closes it
			dialogStage.showAndWait();
			return addController.isOkClicked();
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}   
   }
   
   
   public boolean showMoudelModifyDialog(Moudel modifiedMoudel) {
	   try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("/View/MoudelModifyDialog.fxml"));
			AnchorPane page = (AnchorPane) loader.load();
			// Create the dialog Stage.
			Stage dialogStage = new Stage();
			dialogStage.setTitle("�޸�");
			dialogStage.initOwner(employeeStage);
			dialogStage.initModality(Modality.WINDOW_MODAL); // ��������Ժ���벻�ܵ�ԭ����stage
			dialogStage.setWidth(800.0);
			dialogStage.setHeight(360.0);
			dialogStage.setResizable(false);
			Scene scene = new Scene(page);
			scene.getStylesheets().add(getClass().getResource("/View/Dialog.css").toExternalForm());
			dialogStage.setScene(scene);
			modifyController = loader.getController();
			modifyController.setDialogStage(dialogStage);
			modifyController.setModifiedMoudel(modifiedMoudel);
			// Show the dialog and wait until the user closes it
			dialogStage.showAndWait();
			return modifyController.isOkClicked();
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}   
   }
   
   public void showMoudelQuestionsDialog(Moudel moudel) {
	   try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("/View/MoudelQuestionsDialog.fxml"));
			AnchorPane page = (AnchorPane) loader.load();
			// Create the dialog Stage.
			Stage dialogStage = new Stage();
			dialogStage.setTitle("�鿴");
			dialogStage.initOwner(employeeStage);
			dialogStage.initModality(Modality.WINDOW_MODAL); // ��������Ժ���벻�ܵ�ԭ����stage
			dialogStage.setWidth(800.0);
			dialogStage.setHeight(360.0);
			dialogStage.setResizable(false);
			Scene scene = new Scene(page);
			scene.getStylesheets().add(getClass().getResource("/View/Dialog.css").toExternalForm());
			dialogStage.setScene(scene);
			questionsController = loader.getController();
			questionsController.setDialogStage(dialogStage);
			questionsController.setMoudelData(moudel);
			// Show the dialog and wait until the user closes it
			dialogStage.showAndWait();	
		} catch (IOException e) {
			e.printStackTrace();		
		}   
   	
   }
   /**
    * tab�л�ʱʹ�ø÷��� //��Ϊ�����������ܶ��ļ����й�����
    */
   public void initAndReflush(){
	   
	    moudelData=MoudelService.getMoudelService().getMoudelDao().getMoudelData();
		moudelList=moudelData;
		reflushMoudelTableView(moudelList);
   }
}
