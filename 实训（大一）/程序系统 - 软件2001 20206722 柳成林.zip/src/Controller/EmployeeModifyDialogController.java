package Controller;

import Entity.Employee;
import Util.AlertUtils;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * �޸�Ա������
 * @author Seirin
 *
 */
public class EmployeeModifyDialogController implements InputValidInterface{

	private Employee modifiedEmployee;
	private Stage dialogStage;
	private boolean okClicked = false;

	

	public Employee getModifiedEmployee() {
		return modifiedEmployee;
	}

	public void setModifiedEmployee(Employee modifiedEmployee) {
		this.modifiedEmployee = modifiedEmployee;
	}

	public Stage getDialogStage() {
		return dialogStage;
	}

	public void setDialogStage(Stage dialogStage) {
		this.dialogStage = dialogStage;
	}

	public boolean isOkClicked() {
		return okClicked;
	}

	public void setOkClicked(boolean okClicked) {
		this.okClicked = okClicked;
	}

	@FXML
	private TextField birthdayField;

	@FXML
	private TextField specialityField;

	@FXML
	private Button handleCancel;


	@FXML
	private TextField idField;

	@FXML
	private TextField passwordField;

	@FXML
	private TextField nameField;

	@FXML
	private Button handleOk;

	@FXML
	private ComboBox<String> professionComboBox;
	 
	    	
	@FXML
	private  void initialize() {
		//nameField.setText(modifiedEmployee.getName());
		ObservableList<String> options = 
			    FXCollections.observableArrayList(
			    	"ҽ��",
			        "��ʿ",
			        "����"		        
			    );
			professionComboBox.setItems(options);
 }
	@FXML
	void handleOkEvent(ActionEvent event) {
         
		  if(isInputValid()) {
        	 modifiedEmployee.setPassword(passwordField.getText());
        	 modifiedEmployee.setBirthday(birthdayField.getText());
        	 modifiedEmployee.setId(idField.getText());
        	 modifiedEmployee.setName(nameField.getText());
        	 modifiedEmployee.setSpeciality(specialityField.getText());
        	 modifiedEmployee.setProfession(professionComboBox.getValue());
        	 okClicked=true;
        	 dialogStage.close();
         }
	}

	@FXML
	void handleCancelEvent(ActionEvent event) {
		((Stage) passwordField.getScene().getWindow()).close();
	}

	/**
	 * ���������������Ե�����ʾ
	 */
	 public boolean isInputValid() {
	    	 String errorMessage = "";     
	         if (passwordField.getText() == null || passwordField.getText().length() == 0) {
	             errorMessage += "����Ϊ��\n"; 
	         }
	         if (birthdayField.getText() == null || birthdayField.getText().length() == 0) {
	             errorMessage += "����Ϊ��\n"; 
	         }
	         if (idField.getText() == null || idField.getText().length() == 0) {
	             errorMessage += "����֤Ϊ��\n"; 
	         }
	         if (nameField.getText() == null || nameField.getText().length() == 0) {
	             errorMessage += "����Ϊ��\n"; 
	         }
	         if (specialityField.getText() == null || specialityField.getText().length() == 0) {
	             errorMessage += "ר��Ϊ��\n"; 
	         }
	         if (professionComboBox.getValue()== null || professionComboBox.getValue().length()== 0) {
	             errorMessage += "ְҵΪ��\n"; 
	         }
	               
	         if (errorMessage.length() == 0) {
	             return true;
	         } else {
	             // Show the error message.
	        	 AlertUtils.newErrorAlert(errorMessage, "��������Ч����", dialogStage);		             
	             return false;
	         }
	    	
	    }
	 
	 /**
	  * �����޸ĵ�Ա����Ϣ���ӵ��޸Ŀ���
	  * @param e
	  */
	 public void loadOldEmployeeInfom(Employee e) {
		 passwordField.setText(e.getPassword());
		 birthdayField.setText(e.getBirthday());
		 idField.setText(e.getId());
		 specialityField.setText(e.getSpeciality());
		 nameField.setText(e.getName());
		 professionComboBox.getSelectionModel().select(e.getProfession()); 
		 
		 
	 }
}
