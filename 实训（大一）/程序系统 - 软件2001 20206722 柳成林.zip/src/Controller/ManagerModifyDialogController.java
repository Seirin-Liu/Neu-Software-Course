package Controller;

import Entity.Manager;
import Util.AlertUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * ����Ա���� �޸Ĺ���Ա��Ϣ
 * @author Seirin
 *
 */
public class ManagerModifyDialogController implements InputValidInterface{

	private Manager manager;
	
	private Stage  dialogStage;
	
	private boolean okClicked = false;
	
	
	public boolean isOkClicked() {
		return okClicked;
	}

	public void setOkClicked(boolean okClicked) {
		this.okClicked = okClicked;
	}

	public Manager getManager() {
		return manager;
	}

	public void setManager(Manager manager) {
		this.manager = manager;
		
	}

	public Stage getDialogStage() {
		return dialogStage;
	}

	public void setDialogStage(Stage dialogStage) {
		this.dialogStage = dialogStage;
	}

	@FXML
    private TextField usernameField;

    @FXML
    private Label userLabel;

    @FXML
    private Button handleCancel;

    @FXML
    private TextField passwordField;

    @FXML
    private Button handleOk;

    @FXML
    private Label passwordLabel;
    
    @FXML
	private void initialize() {
    	
    	usernameField.setEditable(false);
    	
    }
    @FXML
    void OkEvent(ActionEvent event) {

    	if(isInputValid()) {
    		manager.setPassword(passwordField.getText());
    		okClicked=true;
    		dialogStage.close();
    	}
    }

    @FXML
    void CancelEvent(ActionEvent event) {

    	dialogStage.close();
    }
    
    public  boolean isInputValid() {
   	 String errorMessage = "";          
        if (passwordField.getText() == null || passwordField.getText().length() == 0) {
            errorMessage += "����Ϊ��\n"; 
        }        
        if (errorMessage.length() == 0) {
            return true;   
        } else {    	 
            AlertUtils.newErrorAlert(errorMessage, "��������Ч����", dialogStage);	             
            return false;
        }
   	
   }
    
    public  void loadManager() {
    	usernameField.setText(manager.getUsername()+" (�����޸�)");
		passwordField.setText(manager.getPassword());
    }

}
