package Controller;

import java.io.IOException;

import Service.LoginService;
import Util.AlertUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;


/**
 * ��¼�������
 * @author Seirin
 *
 */
public class LoginSceneController implements InputValidInterface {

	private LoginService ls; // �����жϵ�¼��Ϣ
	
	private ManagerSceneController manController; //����Ա����
	private EmployeeSceneController empController; //Ա������

	private Stage loginStage;

	public void setLoginStage(Stage loginStage) {
		this.loginStage = loginStage;
	}

	public Stage getLoginStage() {
		return loginStage;
	}

	@FXML
	private PasswordField passwordTextField;
	@FXML
	private TextField usernameTextField;
	

	public PasswordField getPasswordTextField() {
		return passwordTextField;
	}

	public TextField getUsernameTextField() {
		return usernameTextField;
	}

	@FXML
	private Button loginButton;

	@FXML
	private Label loginLabel;

	@FXML
	private Hyperlink registLink;

	@FXML
	void loginButtonEvent(ActionEvent event) {

		String username = usernameTextField.getText();
		String password = passwordTextField.getText();
		if (isInputValid()) {
			if (ls.LoginCheck(username, password) == 1) {
				// ������ʾ ����Ա��¼�ɹ�
				AlertUtils.newRmindAlert("����Ա��¼�ɹ�", "��¼�ɹ�", loginStage);
				loginStage.close();
				loadManageStage();
			} else if (ls.LoginCheck(username, password) == 2) {
				// ������ʾԱ����¼�ɹ�
				AlertUtils.newRmindAlert("Ա����¼�ɹ�", "��¼�ɹ�", loginStage);
				loginStage.close();
				loadEmployeeStage();
			} else {
				AlertUtils.newErrorAlert("�û�������������", "��¼ʧ��", loginStage);
			}
		}
	}

	@FXML
	void registLinkEvent(ActionEvent event) {

	}

	@FXML
	private void initialize() {

		ls = new LoginService();
	}

	/**
	 * ���ع���Ա����������Ϣ
	 */
	void loadManageStage() {
		Stage stage = new Stage();
		// ObservableList<Employee> employeeData=new EmployeeDB().getEmployeeData();
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(getClass().getResource("/View/ManagerScene.fxml"));
		try {
			AnchorPane root = loader.load();
			 manController = loader.getController();
			// controller.setData(employeeData);
			Scene sence = new Scene(root);
			sence.getStylesheets().add(getClass().getResource("/View/ManagerScene.css").toExternalForm());
			stage.setScene(sence);
			stage.setWidth(900.0);
			stage.setHeight(480.0);
			stage.setResizable(false);
			manController.setManagerStage(stage);
			manController.setManager(ls.getManager()); // ��ȡ��loginservice�е�¼�ɹ��Ĺ���Ա����
			manController.setManagerdata(); // ���ص�¼�Ĺ���Ա����Ϣ
			stage.show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	void loadEmployeeStage() {
		Stage stage = new Stage();
		// ObservableList<Employee> employeeData=new EmployeeDB().getEmployeeData();
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(getClass().getResource("/View/EmployeeScene.fxml"));
		try {
			BorderPane root = loader.load();
			empController = loader.getController();
			// controller.setData(employeeData);
			Scene sence = new Scene(root);
			sence.getStylesheets().add(getClass().getResource("/View/EmployeeScene.css").toExternalForm());
			stage.setScene(sence);
			stage.setWidth(900.0);
			stage.setHeight(480.0);
			stage.setResizable(false);
			stage.show();
			empController.setEmployeeStage(stage);
			empController.setEmployee(ls.getEmployee());
			empController.loadEmployee();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public boolean isInputValid() {
		// TODO Auto-generated method stub

		String errorMessage = "";

		if (usernameTextField.getText() == null || usernameTextField.getText().length() == 0) {
			errorMessage += "�û���Ϊ��\n";
		}

		if (passwordTextField.getText() == null || passwordTextField.getText().length() == 0) {
			errorMessage += "����Ϊ��\n";
		}

		if (errorMessage.length() == 0) {
			return true;
		} else {
			// Show the error message.
			AlertUtils.newErrorAlert(errorMessage, "��¼ʧ��", loginStage);

			return false;
		}

	}

}
