package Controller;

import Entity.RareRoom;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.stage.Stage;
import javafx.util.Callback;

public class RareRoomContentSceneController {

	private RareRoom rareRoom;
	private Stage stage;
	private boolean isChanged;

	public boolean isChanged() {
		return isChanged;
	}

	public void setChanged(boolean isChanged) {
		this.isChanged = isChanged;
	}

	public Stage getStage() {
		return stage;
	}

	public void setStage(Stage stage) {
		this.stage = stage;
	}

	public RareRoom getRareRoom() {
		return rareRoom;
	}

	public void setRareRoom(RareRoom rareRoom) {
		this.rareRoom = rareRoom;
		table.setItems(FXCollections.observableArrayList(rareRoom.getUserId()));
		user.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<String, String>, ObservableValue<String>>() {

			@Override
			public ObservableValue<String> call(CellDataFeatures<String, String> param) {
				// TODO Auto-generated method stub
				return new SimpleStringProperty(param.getValue());
			}
		});

	}

	@FXML
	private Button deleteButton;

	@FXML
	private TableColumn<String, String> user;

	@FXML
	private TableView<String> table;

	@FXML
	private void initialize() {

	}

	@FXML
	void deleteEvent(ActionEvent event) {
		String user = table.getSelectionModel().getSelectedItem();
		if (user != null) {
			table.getItems().remove(user);
			rareRoom.getUserId().remove(user);
			rareRoom.setNow(rareRoom.getNow() - 1);
			isChanged = true;
		}
	}
}
