package Controller;

import Entity.Employee;
import Service.EmployeeService;
import Util.AlertUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * ����Ա������
 * @author Seirin
 *
 */
public class EmployeeAddDialogController implements InputValidInterface {
	
	    private Employee newEmployee;  //�µ�Ա��
	    private Stage dialogStage;
	    private boolean okClicked=false;
	   
	   
	    public Employee getNewEmployee() {
			return newEmployee;
		}

		public void setNewEmployee(Employee newEmployee) {
			this.newEmployee = newEmployee;
		}

		public Stage getDialogStage() {
			return dialogStage;
		}

		public void setDialogStage(Stage dialogStage) {
			this.dialogStage = dialogStage;
		}

		public boolean isOkClicked() {
			return okClicked;
		}

	    @FXML
	    private TextField usernameField;

	    @FXML
	    private Label userLabel;

	    @FXML
	    private Button handleCancel;

	    @FXML
	    private TextField passwordField;

	    @FXML
	    private Button handleOk;

	    @FXML
	    private Label passwordLabel;

	    @FXML
	    void OkEvent(ActionEvent event) {
	    	if(isInputValid()) {
	    		newEmployee=new Employee(usernameField.getText(),passwordField.getText());
	    		okClicked=true;
	    		dialogStage.close();
	    	}
	    }
	    @FXML
	    void CancelEvent(ActionEvent event) {
	    	((Stage) usernameField.getScene().getWindow()).close();
       
	    }
	    
	    /**
	     * �ж����������Ƿ���Ч
	     * @return
	     */
	   public  boolean isInputValid() {
	    	 String errorMessage = "";
	    	 EmployeeService empService=EmployeeService.getEmployeeService();	    	 
	         if (usernameField.getText() == null || usernameField.getText().length() == 0) {
	             errorMessage += "�û���Ϊ��\n"; 
	         }	        
	         if (passwordField.getText() == null || passwordField.getText().length() == 0) {
	             errorMessage += "����Ϊ��\n"; 
	         }
	         if (usernameField.getText().startsWith("admin")) {
	             errorMessage += "Ա���û���������admin��ͷ\n"; 
	         }
	         if(empService.isEmployeeExist(usernameField.getText())) {
	        	 errorMessage ="���û����Ѵ���\n";
	         }
	         if (errorMessage.length() == 0) {
	             return true;
	         } else {	        	 
	             AlertUtils.newErrorAlert(errorMessage, "��������Ч����", dialogStage);	             
	             return false;
	         } 	
	    }
	    
	    
}
