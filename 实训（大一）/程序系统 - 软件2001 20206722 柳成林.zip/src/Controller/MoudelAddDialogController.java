package Controller;

import java.util.ArrayList;
import java.util.List;

import Entity.Moudel;
import Entity.Question;
import Service.MoudelService;
import Service.QuestionService;
import Util.AlertUtils;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.util.Callback;

/**
 * ����ģ��
 * @author Seirin
 *
 */
public class MoudelAddDialogController  implements InputValidInterface {

	private Moudel newMoudel;  //�µ�ģ��
	private Stage dialogStage;
	private boolean okClicked;
	
	private ObservableList<Question> questionData; 
	private ObservableList<Question> questionList;   //��ʾ�����б�
	
	private QuestionService queService;
	private MoudelService mouService;

	public Moudel getNewMoudel() {
		return newMoudel;
	}

	public void setNewMoudel(Moudel newMoudel) {
		this.newMoudel = newMoudel;
	}

	public Stage getDialogStage() {
		return dialogStage;
	}

	public void setDialogStage(Stage dialogStage) {
		this.dialogStage = dialogStage;
	}

	public boolean isOkClicked() {
		return okClicked;
	}

	public void setOkClicked(boolean okClicked) {
		this.okClicked = okClicked;
	}



	@FXML
	private TextField titleTextField;

	@FXML
	private Button searchButton;

	@FXML
	private Button cancelButton;

	@FXML
	private TextField searchField;

	@FXML
	private TableView<Question> questionTableView;

	@FXML
	private TextField idTextField;

	@FXML
	private TableColumn<Question, CheckBox> checkBoxColumn;

	@FXML
	private TableColumn<Question, String> contentColumn;

	@FXML
	private Button okButton;

	@FXML
	private TableColumn<Question, String> typeColumn;

	@FXML
	private ComboBox<String> typrComBox;

	@FXML
	private TableColumn<Question, String> idColumn;

	@FXML
	void searchEvent(ActionEvent event) {
		
		if (searchField.getText() == null || searchField.getText().length() == 0) {
    		reflushQuestionTableView(questionData);
    		return;	
    		}
    	questionList=queService.getQuestionBySearch(searchField.getText());
    	if(questionList.size()==0) {
    		AlertUtils.newErrorAlert("�����Ÿı������ؼ���", "���Ҳ�������", dialogStage);
			return;
    	}
    	reflushQuestionTableView(questionList);

	}

	@FXML
	void okEvent(ActionEvent event) {
		if(isInputValid()) {
			int id=Integer.parseInt(idTextField.getText());
			newMoudel=new Moudel(id, titleTextField.getText(), getCheckedQuestions(), typrComBox.getValue());
			okClicked=true;
			dialogStage.close();
		}
	}

	@FXML
	void cancelEvent(ActionEvent event) {

		dialogStage.close();
	}
	
	@FXML
	void initialize() {
		ObservableList<String> options = 
			    FXCollections.observableArrayList(
				    	"A",
				    	"B",
				    	"C",
				    	"D",
				    	"E"	               
				    );  	
		typrComBox.setItems(options);
		typrComBox.setValue("A");
		queService=new QuestionService(); 
		questionData=queService.getQuestionDao().getQuestionData();
		questionList=questionData;
		reflushQuestionTableView(questionList);
		mouService=MoudelService.getMoudelService();
		idTextField.setText(""+mouService.getNewId());
		
	}
	
	 public void reflushQuestionTableView(ObservableList<Question> questionData) {
	    	
	    	questionTableView.setItems(questionData);
	    	
	    	idColumn.setCellValueFactory(
					new Callback<TableColumn.CellDataFeatures<Question, String>, ObservableValue<String>>() {
						@Override
						public ObservableValue<String> call(CellDataFeatures<Question, String> param) {
							// TODO Auto-generated method stub
							SimpleStringProperty name = new SimpleStringProperty(""+param.getValue().getId());
							return name;
						}
					});
	    	typeColumn.setCellValueFactory(
					new Callback<TableColumn.CellDataFeatures<Question, String>, ObservableValue<String>>() {
						@Override
						public ObservableValue<String> call(CellDataFeatures<Question, String> param) {
							// TODO Auto-generated method stub
							SimpleStringProperty name = new SimpleStringProperty(param.getValue().getType());
							return name;
						}
					});
	    	contentColumn.setCellValueFactory(
					new Callback<TableColumn.CellDataFeatures<Question, String>, ObservableValue<String>>() {
						@Override
						public ObservableValue<String> call(CellDataFeatures<Question, String> param) {
							// TODO Auto-generated method stub
							SimpleStringProperty name = new SimpleStringProperty(param.getValue().getContent());
							return name;
						}
					});
	    
	    	checkBoxColumn.setCellValueFactory(new PropertyValueFactory<Question, CheckBox>("checkBox"));
	    }
	    
	 /**
	  * �õ���ѡ��������б�
	  */
	 public List<Question> getCheckedQuestions() {
		 
		 List<Question> beCheckedQuestionList=new ArrayList<Question>();
		 for(Question q:questionList) {
			 if(q.getCheckBox().isSelected()) {
				 beCheckedQuestionList.add(q);	
				 q.getCheckBox().setSelected(false);
			 }
		 }
		 return beCheckedQuestionList;
	 }

	@Override
	public boolean isInputValid() {
		// TODO Auto-generated method stub
		String errorMessage = "";    
        if (titleTextField.getText() == null || titleTextField.getText().length() == 0) {
            errorMessage += "��ĿΪ��\n"; 
        }
        if (typrComBox.getValue()== null || typrComBox.getValue().length() == 0) {
            errorMessage += "����Ϊ��\n"; 
        }	
             
        if (errorMessage.length() == 0) {
            return true;
            
        } else {
       	 
            AlertUtils.newErrorAlert(errorMessage, "��������Ч����", dialogStage);	             
            return false;
        }
	
	}
}
