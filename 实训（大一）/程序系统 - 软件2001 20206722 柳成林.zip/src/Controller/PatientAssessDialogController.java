package Controller;

import Entity.Moudel;
import Service.MoudelService;
import Util.AlertUtils;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.stage.Stage;
/**
 * ����ʱѡ��ģ��Ľ���
 * @author Seirin
 *
 */
public class PatientAssessDialogController implements InputValidInterface{

	    private String employeeName;
	    
	    private String patientName;
	    
	   
	    private boolean okClicked=false;
	    private MoudelService mouService;
	    private Stage dialogStage;
	    private Moudel selectMoudel;  //��ѡ���ģ�壬������һ������
	    private ObservableList<Moudel> moudelData;
	    
	    
	    public Moudel getSelectMoudel() {
			return selectMoudel;
		}

		public void setSelectMoudel(Moudel selectMoudel) {
			this.selectMoudel = selectMoudel;
		}

		public String getPatientName() {
			return patientName;
		}

		public void setPatientName(String patientName) {
			this.patientName = patientName;
		}

		public Stage getDialogStage() {
			return dialogStage;
		}

		public void setDialogStage(Stage dialogStage) {
			this.dialogStage = dialogStage;
		}

		public String getEmployeeName() {
			return employeeName;
		}

		public void setEmployeeName(String employeeName) {
			this.employeeName = employeeName;
		}

		public boolean isOkClicked() {
			return okClicked;
		}

		public void setOkClicked(boolean okClicked) {
			this.okClicked = okClicked;
		}

		public MoudelService getMouService() {
			return mouService;
		}

		public void setMouService(MoudelService mouService) {
			this.mouService = mouService;
		}

		@FXML
	    private Button cancelButton;

	    @FXML
	    private ComboBox<String> moudelTypeComboBox;

	    @FXML
	    private Label PatientNameLabel;

	    @FXML
	    private Label employeeNameLabel;

	    @FXML
	    private Button okButton;

		@FXML
		private void initialize() {
			//ÿ�ε����������¶�ȡ�ļ������Ա����޸ĵ�ͬ��
			mouService =MoudelService.getMoudelService();
			moudelData=mouService.getMoudelDao().getMoudelData();
		    moudelTypeComboBox.setItems(getMoudelNames());
		   
		}
		
	    @FXML
	    void okEvent(ActionEvent event) {

	    	if(isInputValid()) {
	    		int index=moudelTypeComboBox.getSelectionModel().getSelectedIndex();
	    		selectMoudel=moudelData.get(index);
	    		okClicked=true;
	    		dialogStage.close();
	    	}
	    }

	    @FXML
	    void cancelEvent(ActionEvent event) {

	    	dialogStage.close();
	    }
	    
	    ObservableList<String> getMoudelNames(){
	    	ObservableList<String> options =FXCollections.observableArrayList();
	    	for(Moudel m:moudelData) {
	    		options.add(m.getName());
	    	}
	    	return options;
	    }

		@Override
		public boolean isInputValid() {
			 String errorMessage = "";    
	         if (moudelTypeComboBox.getValue() == null || moudelTypeComboBox.getValue().length() == 0) {
	             errorMessage += "ģ��δѡ��\n"; 
	         }	        
              
	         if (errorMessage.length() == 0) {
	             return true;
	             
	         } else {
	        	 
	             AlertUtils.newErrorAlert(errorMessage, "ģ��δѡ��", dialogStage);	             
	             return false;
	         }
		}
		
		/**
		 * ����Ա���ͱ��������ߵ���Ϣ
		 */
		public  void loadData() {
			 employeeNameLabel.setText(employeeName);
			PatientNameLabel.setText(patientName);
		}
}
