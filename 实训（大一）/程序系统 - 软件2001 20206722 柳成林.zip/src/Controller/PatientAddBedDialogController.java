package Controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import Entity.Bed;
import Entity.Building;
import Entity.Floor;
import Entity.Patient;
import Entity.Room;
import Service.BuildingService;
import Util.AlertUtils;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;


/**
 * Ϊ�������Ӵ�λ�Ľ���
 * @author Seirin
 *
 */
public class PatientAddBedDialogController implements InputValidInterface {
	
	
	private Stage dialogStage;
	private BuildingService buildingService;
	//private BedService bedService;
	private List<Building> buildingData;
	
	private Building building;
	private Floor floor;
	private Room room;
	private Bed bed;
	
	private Patient patient;
	private boolean okClicked=false;
	  
	public Patient getPatient() {
		return patient;
	}
	public void setPatient(Patient patient) {
		this.patient = patient;
	}
	public Stage getDialogStage() {
		return dialogStage;
	}
	public void setDialogStage(Stage dialogStage) {
		this.dialogStage = dialogStage;
	}
	public BuildingService getBuildingService() {
		return buildingService;
	}
	public void setBuildingService(BuildingService buildingService) {
		this.buildingService = buildingService;
	}
	public List<Building> getBuildingData() {
		return buildingData;
	}
	public void setBuildingData(List<Building> buildingData) {
		this.buildingData = buildingData;
	}
	public boolean isOkClicked() {
		return okClicked;
	}
	public void setOkClicked(boolean okClicked) {
		this.okClicked = okClicked;
	}
    public Bed getBed() {
		return bed;
	}
	public void setBed(Bed bed) {
		this.bed = bed;
	}
	@FXML
	private TextField endTimeTextField;
	
	@FXML
	private TreeView<String> treeView;
	 
	@FXML
	private Label patientNameLabel;

	@FXML
    private ComboBox<String> buildingComboBox;

    @FXML
    private Button cancelButton;

    @FXML
    private ComboBox<String> bedComboBox;

    @FXML
    private ComboBox<String> roomComboBox;

    @FXML
    private ComboBox<String> floorComboBox;

    @FXML
    private Button okButton;
    
    @FXML
    private TextField startTimeTextField;

    //��¥�������ͬ���ļ��ط�ʽ
    @FXML
    private void initialize() {
    	buildingService = BuildingService.getBuildingService();
		buildingData = buildingService.getBuildingDao().getBuildingData();	
		buildingComboBox.setItems(buildingService.getBuildingNames());
		loadTree();
		//bedService=BedService.getBedService();
		
		buildingComboBox.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
			@Override
			public void changed(ObservableValue<? extends String> observable, String oldValue, String buildingName) {
				// TODO Auto-generated method stub
				floorComboBox.setValue(null); // ÿ�θ���buildingNameʱ���¥���¥�������
				floorComboBox.setItems(null);
				floor = null;
				if (buildingName != null) {
					building = buildingService.getBuilding(buildingName);
					floorComboBox.setItems(buildingService.getFloorNames(building));
				}

			}
		});
		floorComboBox.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
			@Override
			public void changed(ObservableValue<? extends String> observable, String oldValue, String floorName) {
				// TODO Auto-generated method stub
				roomComboBox.setValue(null);
				roomComboBox.setItems(null);
				room = null;
				if (floorName != null) {
					floor = buildingService.getFloor(building, floorName);
					roomComboBox.setItems(buildingService.getRoomNames(floor));
				}

			}
		});
		roomComboBox.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
			@Override
			public void changed(ObservableValue<? extends String> arg0, String oldValue, String roomName) {
				// TODO Auto-generated method stub
				bedComboBox.setValue(null);
				bedComboBox.setItems(null);
				bed = null;
				if (roomName != null) {
					room = buildingService.getRoom(floor, roomName);
					bedComboBox.setItems(buildingService.getFreeBedNames(room));
				}
			}
		});
		bedComboBox.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
			@Override
			public void changed(ObservableValue<? extends String> arg0, String oldValue, String bedName) {
				// TODO Auto-generated method stub
				if (bedName != null) {
					bed = buildingService.getBed(room, bedName);
				}
			}
		});
		
		treeView.setOnMouseClicked(new EventHandler<MouseEvent>()
		{
		    @Override
		    public void handle(MouseEvent mouseEvent)
		    {
		        if(mouseEvent.getClickCount() == 1)
		        {
		            TreeItem<String> item = treeView.getSelectionModel().getSelectedItem();
		            bedComboBox.setValue(null);
		            roomComboBox.setValue(null);
		            floorComboBox.setValue(null);
		            if(item.getValue()!=null) {
		            getTreeSelect(item.getValue());	} 
		        }
		    }
		});
    	
    }
    @FXML
    void okEvent(ActionEvent event) {

    	if(isInputValid()) {
    		int bedIndex=room.getBeds().indexOf(bed);
    		int roomIndex = floor.getRooms().indexOf(room);
    		int floorIndex = building.getFloors().indexOf(floor);
    		int buildingIndex = buildingData.indexOf(building);
    		bed = buildingService.getBed(room, bedComboBox.getValue());
    		
    		bed.setPatientName(patient.getName());
    		bed.setStatus("��ס��");
    		SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");//�������ڸ�ʽ
    		String recordId=df.format(new Date());
    		bed.setRecordId(recordId);
    		bed.setPatientSex(patient.getSex());
    		bed.setPatientAge(patient.getBirthday());
    		bed.setStartTime(startTimeTextField.getText());
    		bed.setEndTime(endTimeTextField.getText());
    			
    		room.getBeds().set(bedIndex, bed);
    		floor.getRooms().set(roomIndex, room);
    		building.getFloors().set(floorIndex, floor);
    		buildingData.set(buildingIndex, building);
    		
    		buildingService.saveBuildingData(buildingData);
    		
    		//bedService.saveNewBed(bed);
    		
    		okClicked=true;
    		dialogStage.close();
    	}
    	
    }

    @FXML
    void cancelEvent(ActionEvent event) {

    	dialogStage.close();
    }
    
    public void loadData() { 	
    	SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");//�������ڸ�ʽ
		String startTime=df.format(new Date());
		startTimeTextField.setText(startTime);
		endTimeTextField.setText(startTime);
		patientNameLabel.setText(patient.getName());
		
    }
	@Override
	public boolean isInputValid() {
		// TODO Auto-generated method stub
		 String errorMessage = "";    
		 
         if (startTimeTextField.getText()== null || startTimeTextField.getText().length() == 0) {
             errorMessage += "��ʼʱ��Ϊ��\n"; 
         }	 
         if (endTimeTextField.getText()== null || endTimeTextField.getText().length() == 0) {
             errorMessage += "����ʱ��Ϊ��\n"; 
         }	
         if (bedComboBox.getValue()== null || bedComboBox.getValue().length() == 0) {
             errorMessage += "��λΪ��\n"; 
         }	   
         if (errorMessage.length() == 0) {
             return true;     
         }    
          else {
             AlertUtils.newErrorAlert(errorMessage, "����ʧ��", dialogStage);	             
             return false;
         }
	}
	
	public void loadTree() {
		 Image depIcon = new Image("file:pictures\\¥���Զ���.png");
		 ImageView img=new ImageView(depIcon);
		 img.setFitHeight(20.0);
		 img.setFitWidth(20.0);
		 TreeItem<String> hosItem = new TreeItem<String>("ҽԺ",img);
			hosItem.setExpanded(true);
			for (Building b : buildingData) {
				TreeItem<String> buildingItem = new TreeItem<String>(b.getName());
				buildingItem.setExpanded(true);
				for (Floor f : b.getFloors()) {
					TreeItem<String> floorItem = new TreeItem<String>(f.getName());
					floorItem.setExpanded(true);
					for (Room r : f.getRooms()) {
						TreeItem<String> roomItem = new TreeItem<String>(r.getName());
						roomItem.setExpanded(true);
						if (r.isRare() == true) {				
							continue;
						}
						for (Bed bed : r.getBeds()) {
							if(bed.getStatus().equals("δ��ס")) {
							TreeItem<String> bedItem = new TreeItem<String>(bed.getName());
							bedItem.setExpanded(true);
							roomItem.getChildren().add(bedItem);}
							if(bed.getStatus().equals("��ס��")) {
								continue;
							}
						}
						floorItem.getChildren().add(roomItem);
					}
					buildingItem.getChildren().add(floorItem);
				}
				hosItem.getChildren().add(buildingItem);
			}

			treeView.setRoot(hosItem);
		}
	
	
	public void getTreeSelect(String value) {
		String[] name=value.split("-");
		if(value.equals("ҽԺ")) {
			return;
		}
		if(name.length==1) {
			buildingComboBox.setValue(name[0]);
		}
		if(name.length==2) {
			buildingComboBox.setValue(name[0]);		
			floorComboBox.setValue(value);
		}
		if(name.length==3) {
			buildingComboBox.setValue(name[0]);
			floorComboBox.setValue(name[0]+"-"+name[1]);
			roomComboBox.setValue(value);
			
		}
		if(name.length>=4) {
			buildingComboBox.setValue(name[0]);
			floorComboBox.setValue(name[0]+"-"+name[1]);
			roomComboBox.setValue(name[0]+"-"+name[1]+"-"+name[2]);
			bedComboBox.setValue(name[0]+"-"+name[1]+"-"+name[2]+"-"+name[3]);
			
		}
		
	}
}
