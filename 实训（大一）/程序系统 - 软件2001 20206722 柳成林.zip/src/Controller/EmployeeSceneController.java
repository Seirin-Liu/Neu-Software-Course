package Controller;

import java.io.IOException;

import Entity.Employee;
import Service.EmployeeService;
import Util.AlertUtils;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TabPane.TabClosingPolicy;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;


/**
 *Ա���ĸ�����
 *tabpane������ʾ��ͬ���ܴ�������root
 * @author Seirin
 *
 */
public class EmployeeSceneController{

	private Stage employeeStage;
	
	private Employee employee;  //��¼��Ա��
	private EmployeeModifyDialogController modifyController;
	
	private PatientSceneController psController;  //���Ʋ�ͬ�����Controller
	private QuestionSceneController qsController;
	private MoudelSceneController msController;
	private AssessSceneController asController;
	private BuildingSceneController bsController;
	
	private static final String patientSence=" ���߹��� ";
	private static final String questionSence=" ������� ";
	private static final String moudelSence=" ģ����� ";
	private static final String assessSence=" ������¼ ";
	private static final String buildingSence=" ¥����� ";
	
	private static  Tab patientTab;  //ÿ��tab
	private static  Tab questionTab;
	private static  Tab moudelTab;
	private static  Tab assessTab;
	private static  Tab buildingTab;
	
	
	public Stage getEmployeeStage() {
		return employeeStage;
	}
	public void setEmployeeStage(Stage employeeStage) {
		this.employeeStage = employeeStage;
	}
	public Employee getEmployee() {
		return employee;
	}
	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	
    @FXML
	private Button assessSceneButton;

	@FXML
	private Button patientSceneButton;
	@FXML
	private Button questionSceneButton;
	@FXML
	private Button moudelSceneButton;

	@FXML
    private Button buildingSceneButton;
	@FXML
    private Button bedSceneButton;

	@FXML
	private TabPane tabPane;
	@FXML
	private Label employeeLable;

	@FXML
	private Hyperlink employeefModifyLink;

	@FXML
	private Hyperlink exitLink;

	@FXML
	void initialize() {
		
		
		tabPane.setTabClosingPolicy(TabClosingPolicy.ALL_TABS);
		tabPane.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<Tab>() {
		    @Override
		    public void changed(ObservableValue<? extends Tab> observable, Tab oldValue, Tab newValue) {
		    	if(oldValue==null||newValue==null) {
		    		return;
		    	}
		       if(newValue.getText().equals(moudelSence)) {  //��ȡtab������
		    	   msController.initAndReflush();//ˢ��
		       }
		       if(newValue.getText().equals(questionSence)) {
		    	   qsController.initAndReflush();
		       }
		       if(newValue.getText().equals(patientSence)) {
		    	    
		       }
		       if(newValue.getText().equals(assessSence)) {
			    asController.initAndReflush();	  
		       }
		       if(newValue.getText().equals(buildingSence)){
				    bsController.initAndReflush();	  
			    }
		    }
		});
	
	}

	@FXML
	void employeefModifyEvent(ActionEvent event) {

		if (showEmployeeModifyDialog(employee)) {
			if (AlertUtils.newQureAlert("���ȷ������Ա����Ϣ", "�Ƿ񱣴��޸ģ�", employeeStage)) {
				employee = modifyController.getModifiedEmployee();
				EmployeeService.getEmployeeService().saveNewEmployeedata(employee);
				AlertUtils.newRmindAlert("�޸ĳɹ�", "�޸ĳɹ�", employeeStage);
				loadEmployee();
			}
		}
	}

	@FXML
	void exitEvent(ActionEvent event) {
		employeeStage.close();
		Main main = new Main();
		main.initLoginSceneAsExit(employee.getUsername(), employee.getPassword());
	}

	/**
	 * �������߹�������
	 * 
	 * @param event
	 */
	@FXML
	void patientSceneEvent(ActionEvent event) {
		patientTab = findTab(patientSence);
		if (patientTab != null) {
			int tabIndex = tabPane.getTabs().indexOf(patientTab); // �Ȼ�ȡ����tabs���ٻ�ȡindex
			tabPane.getSelectionModel().select(tabIndex);
			return;
		}
		patientTab = new Tab(patientSence);
		patientTab.setClosable(true);
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(getClass().getResource("/View/PatientScene.fxml"));
		try {
			AnchorPane root = (AnchorPane) loader.load();
		    psController = loader.getController();
			psController.setEmployeeStage(employeeStage);
			psController.setEmployeeName(employee.getName());  //��������Ա��������
			root.getStylesheets().add(getClass().getResource("/View/PatientScene.css").toExternalForm());
			patientTab.setContent(root);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		tabPane.getTabs().add(patientTab);
		int tabIndex = tabPane.getTabs().indexOf(patientTab);
		tabPane.getSelectionModel().select(tabIndex);
	}
	

	/**
	 * ���������������
	 * 
	 * @param event
	 */
	@FXML
	void questionSceneEvent(ActionEvent event) {
		questionTab = findTab(questionSence);
		if (questionTab != null) {
			int tabIndex = tabPane.getTabs().indexOf(questionTab); // �Ȼ�ȡ����tabs���ٻ�ȡindex
			tabPane.getSelectionModel().select(tabIndex);
			return;
		}
		questionTab = new Tab(questionSence);
		questionTab.setClosable(true);
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(getClass().getResource("/View/QuestionScene.fxml"));
		try {
			AnchorPane root = (AnchorPane) loader.load();
			qsController = loader.getController();
			qsController.setEmployeeStage(employeeStage);
			root.getStylesheets().add(getClass().getResource("/View/QuestionScene.css").toExternalForm());
			questionTab.setContent(root);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		tabPane.getTabs().add(questionTab);
		int tabIndex = tabPane.getTabs().indexOf(questionTab);
		tabPane.getSelectionModel().select(tabIndex);

	}
	
	@FXML
	void moudelSceneEvent(ActionEvent event) {
		moudelTab = findTab(moudelSence);
		if (moudelTab != null) {
			int tabIndex = tabPane.getTabs().indexOf(moudelTab); // �Ȼ�ȡ����tabs���ٻ�ȡindex
			tabPane.getSelectionModel().select(tabIndex);
			return;
		}
		moudelTab = new Tab(moudelSence);
		moudelTab.setClosable(true);
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(getClass().getResource("/View/MoudelScene.fxml"));
		try {
			AnchorPane root = (AnchorPane) loader.load();
			msController = loader.getController();
			msController.setEmployeeStage(employeeStage);
			root.getStylesheets().add(getClass().getResource("/View/MoudelScene.css").toExternalForm());
			moudelTab.setContent(root);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		tabPane.getTabs().add(moudelTab);
		int tabIndex = tabPane.getTabs().indexOf(moudelTab);
		tabPane.getSelectionModel().select(tabIndex);
		
	}
	@FXML
    void assessSceneEvent(ActionEvent event) {

		assessTab = findTab(assessSence);
		if (assessTab != null) {
			int tabIndex = tabPane.getTabs().indexOf(assessTab); // �Ȼ�ȡ����tabs���ٻ�ȡindex
			tabPane.getSelectionModel().select(tabIndex);
			return;
		}
		assessTab = new Tab(assessSence);
		assessTab.setClosable(true);
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(getClass().getResource("/View/assessScene.fxml"));
		try {
			AnchorPane root = (AnchorPane) loader.load();
			asController = loader.getController();
			asController.setEmployeeStage(employeeStage);
			root.getStylesheets().add(getClass().getResource("/View/assessScene.css").toExternalForm());
			assessTab.setContent(root);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		tabPane.getTabs().add(assessTab);
		int tabIndex = tabPane.getTabs().indexOf(assessTab);
		tabPane.getSelectionModel().select(tabIndex);
    }
	@FXML
    void buildingSceneEvent(ActionEvent event) {
		buildingTab = findTab(buildingSence);
		if (buildingTab != null) {
			int tabIndex = tabPane.getTabs().indexOf(buildingTab); // �Ȼ�ȡ����tabs���ٻ�ȡindex
			tabPane.getSelectionModel().select(tabIndex);
			return;
		}
		buildingTab = new Tab(buildingSence);
		buildingTab.setClosable(true);
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(getClass().getResource("/View/buildingScene.fxml"));
		try {
			AnchorPane root = (AnchorPane) loader.load();
			bsController = loader.getController();
			bsController.setEmployeeStage(employeeStage);
			root.getStylesheets().add(getClass().getResource("/View/BuildingScene.css").toExternalForm());
			buildingTab.setContent(root);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		tabPane.getTabs().add(buildingTab);
		int tabIndex = tabPane.getTabs().indexOf(buildingTab);
		tabPane.getSelectionModel().select(tabIndex);
	}
		

 
	
	/**
	 * ������tab�Ƿ񱻴�
	 * @param tabName
	 * @return
	 */
	public Tab findTab(String tabName) {
		ObservableList<Tab> tabList = tabPane.getTabs();
		for (Tab t : tabList) {
			if (t.getText().equals(tabName)) {
				return t;
			}
		}
		return null;
	}

	/**
	 * �޸ĵ�¼��Ա���Լ�����Ϣ
	 * @param modifiedEmployee
	 * @return
	 */
	boolean showEmployeeModifyDialog(Employee modifiedEmployee) {
		try {
			// Load the fxml file and create a new stage for the popup dialog.
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("/View/EmployeeModifyDialog.fxml"));
			AnchorPane page = (AnchorPane) loader.load();
			// Create the dialog Stage.
			Stage dialogStage = new Stage();
			dialogStage.setTitle("�޸�");
			dialogStage.initOwner(employeeStage);
			dialogStage.initModality(Modality.WINDOW_MODAL);
			dialogStage.setWidth(370.0);
			dialogStage.setHeight(400.0);
			dialogStage.setResizable(false);
			Scene scene = new Scene(page);
			scene.getStylesheets().add(getClass().getResource("/View/EmployeeModifyDialog.css").toExternalForm());
			dialogStage.setScene(scene);
			modifyController = loader.getController();
			modifyController.setDialogStage(dialogStage);
			modifyController.setModifiedEmployee(modifiedEmployee); // �ȴ���
			modifyController.loadOldEmployeeInfom(modifiedEmployee);// �����޸Ŀ�ĳ�ʼֵ
			// Show the dialog and wait until the user closes it
			dialogStage.showAndWait();

			return modifyController.isOkClicked();

		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}
	
//	public void loadFirstScene() {
//	
//		Tab tab = new Tab("��ʼ����");
//		tab.setClosable(true);
//		FXMLLoader loader = new FXMLLoader();
//		loader.setLocation(getClass().getResource("/View/Scene1.fxml"));
//		try {
//			AnchorPane root = (AnchorPane) loader.load();
//			tab.setContent(root);
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		tabPane.getTabs().add(tab);
//		int tabIndex = tabPane.getTabs().indexOf(tab);
//		tabPane.getSelectionModel().select(tabIndex);
//	}
	
	public void loadEmployee() {
		employeeLable.setText("Ա����" + employee.getName() + " " + employee.getProfession());
	}
	

}
