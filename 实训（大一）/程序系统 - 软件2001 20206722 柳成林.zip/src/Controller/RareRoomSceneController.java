package Controller;

import java.io.IOException;

import Entity.RareRoom;
import Service.RareRoomService;
import Util.AlertUtils;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Callback;

public class RareRoomSceneController {

	private Stage dialogStage;
	private RareRoomService rareRoomService;
	private ObservableList<RareRoom> rareRoomData;
	private ObservableList<RareRoom> rareRoomList;
	
	private RareRoomContentSceneController rareRoomContentController;

	public Stage getDialogStage() {
		return dialogStage;
	}

	public void setDialogStage(Stage dialogStage) {
		this.dialogStage = dialogStage;
	}

	@FXML
	private Button cancelButton;
	@FXML
	private TableColumn<RareRoom, String> max;
	@FXML
	private TableColumn<RareRoom, String> now;
	@FXML
	private TableColumn<RareRoom, String> name;
	@FXML
	private Button okButton;
	@FXML
	private TableColumn<RareRoom, String> type;
	@FXML
	private TableView<RareRoom> table;
	@FXML
	private Button searchButton;

	@FXML
	private Button clearButton;

	@FXML
	private Button contentButton;

	@FXML
	private TextField searchTextField;

	@FXML
	private void initialize() {

		rareRoomService = RareRoomService.getRareRooomService();
		rareRoomData = rareRoomService.getRareRoomDao().getRareRoomData();
		rareRoomList = rareRoomData;
		reflushRareRoomTableView(rareRoomList);
	}

	public void reflushRareRoomTableView(ObservableList<RareRoom> rareRoomList) {
		table.setItems(rareRoomList);

		name.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<RareRoom, String>, ObservableValue<String>>() {

					@Override
					public ObservableValue<String> call(CellDataFeatures<RareRoom, String> param) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty(param.getValue().getName());
						return name;
					}
				});
		type.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<RareRoom, String>, ObservableValue<String>>() {

					@Override
					public ObservableValue<String> call(CellDataFeatures<RareRoom, String> param) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty(param.getValue().getRareType());
						return name;
					}
				});
		max.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<RareRoom, String>, ObservableValue<String>>() {

					@Override
					public ObservableValue<String> call(CellDataFeatures<RareRoom, String> param) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty("" + param.getValue().getMax());
						return name;
					}
				});
		now.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<RareRoom, String>, ObservableValue<String>>() {

					@Override
					public ObservableValue<String> call(CellDataFeatures<RareRoom, String> param) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty("" + param.getValue().getNow());
						return name;
					}
				});

	}

	@FXML
	void clearEvent(ActionEvent event) {
		
		RareRoom r = table.getSelectionModel().getSelectedItem();
		if(r==null) {
			AlertUtils.newErrorAlert("error: δѡ��", "δѡ��", dialogStage);
			return;
		}
		int index=table.getItems().indexOf(r);
		r.setNow(0);
		table.getItems().set(index, r);
		rareRoomService.clearUser(r);
		AlertUtils.newRmindAlert("�������", "��ճɹ�", dialogStage);
		
	}

	@FXML
	void searchEvent(ActionEvent event) {

		if(searchTextField.getText()==null||searchTextField.getText().length()==0) {
			reflushRareRoomTableView(rareRoomData);
			return;
		}
		else {
			rareRoomList=rareRoomService.searchRareRoom(searchTextField.getText());
			if(rareRoomList.size()==0) {
				AlertUtils.newErrorAlert("�����Ÿı������ؼ���", "���Ҳ�����Ϣ", dialogStage);
			}
			reflushRareRoomTableView(rareRoomList);
		}
		
	}

	@FXML
	void contentEvent(ActionEvent event) {

		RareRoom r = table.getSelectionModel().getSelectedItem();
		if(r==null) {
			AlertUtils.newErrorAlert("error: δѡ��", "δѡ��", dialogStage);
			return;
		}
		if(showContentDialog(r)) {
			rareRoomService.saveRareRoomData(rareRoomData);
		}

	}
	
	public boolean showContentDialog(RareRoom r) {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("/View/RareRoomContentScene.fxml"));
			AnchorPane page = (AnchorPane) loader.load();
			Stage dialogStage = new Stage();
			dialogStage.setTitle("������");
			dialogStage.initOwner(this.dialogStage);
			dialogStage.setWidth(180.0);
			dialogStage.setHeight(260.0);
			dialogStage.setResizable(false);
			dialogStage.initModality(Modality.WINDOW_MODAL);
			Scene scene = new Scene(page);
			scene.getStylesheets().add(getClass().getResource("/View/Dialog.css").toExternalForm());
			dialogStage.setScene(scene);
			rareRoomContentController = loader.getController();
			rareRoomContentController.setStage(dialogStage);
			rareRoomContentController.setRareRoom(r);
			// Show the dialog and wait until the user closes it
			dialogStage.showAndWait();
		
			if(rareRoomContentController.isChanged()) {
				int index=rareRoomData.indexOf(r);
				rareRoomData.set(index, rareRoomContentController.getRareRoom());
				return true;
			}
			
		} catch (IOException e) {
			e.printStackTrace();
			
		}
		return false;
	}

}
