package Controller;

import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * ���������
 * @author Seirin
 *
 */
public class Main extends Application {

	private Stage primaryStage;	
	
	private LoginSceneController controller;
	@Override
	public void start(Stage primaryStage) {

		this.primaryStage=primaryStage;
		initLoginScene();
	}
	public static void main(String[] args) {
        
		launch(args);
	}
	
	/**
	 * ���ص�¼����
	 * @param primaryStage
	 */
	public void initLoginScene() {

		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(getClass().getResource("/View/LoginScene.fxml"));
		try {
			AnchorPane root = (AnchorPane) loader.load();
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/View/LoginScene.css").toExternalForm());
		    controller=loader.getController();
			primaryStage.setScene(scene);
			primaryStage.setTitle("��¼����");
			primaryStage.setWidth(640.0);
			primaryStage.setHeight(380.0);
			primaryStage.setResizable(false);    //���ô�С���ɸı�
			controller.setLoginStage(primaryStage);
			primaryStage.show();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * ע��ʱ���ص�¼����
	 * @param primaryStage
	 */
	public void initLoginSceneAsExit(String username,String password) {

		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(getClass().getResource("/View/LoginScene.fxml"));
		try {
			AnchorPane root = (AnchorPane) loader.load();
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/View/LoginScene.css").toExternalForm());
			controller=loader.getController();
			Stage loginStage=new Stage();
			loginStage.setScene(scene);
			loginStage.setTitle("��¼����");
			loginStage.setWidth(640.0);
			loginStage.setHeight(380.0);
			loginStage.setResizable(false);    //���ô�С���ɸı�
			controller.setLoginStage(loginStage);
			controller.getUsernameTextField().setText(username);
			controller.getPasswordTextField().setText(password);
			loginStage.show();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
