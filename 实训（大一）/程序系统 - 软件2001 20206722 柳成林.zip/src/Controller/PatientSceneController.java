package Controller;

import java.io.IOException;

import Entity.Assess;
import Entity.Moudel;
import Entity.Patient;
import Service.AssessService;
import Service.BuildingService;
import Service.PatientService;
import Util.AlertUtils;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Callback;

/**
 * ���߹�������
 * @author Seirin
 *
 */
public class PatientSceneController implements TabReLoadInterface,DeleteByCheckBox{

	private ObservableList<Patient> patientData;// ���ļ��ж�ȡ���б�

	private ObservableList<Patient> patientList;// ��ǰ��ʾ���б�����������ʱ����

	private PatientService patService;
	private AssessService assessService;
	private BuildingService buildingService;

	private Stage employeeStage;
	private String employeeName;   //��������ʱʹ��

	private PatientAddDialogController addController;
	private PatientModifyDialogController modifyController;
	private PatientAssessDialogController assessController;
	private PatientAssessStageController  assessStageController;
	private PatientAddBedDialogController addBedController;
	private PatientUseRareRoomDialogController rareRoomController;

	public Stage getEmployeeStage() {
		return employeeStage;
	}

	public void setEmployeeStage(Stage employeeStage) {
		this.employeeStage = employeeStage;
	}
	
	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	@FXML
	private Button searchButton;

	@FXML
	private TextField searchField;

	@FXML
	private TableView<Patient> patientTableView;

	@FXML
	private TableColumn<Patient, String> emConTelColumn;

	@FXML
	private TableColumn<Patient, String> birthdayColumn;

	@FXML
	private TableColumn<Patient, String> telColumn;

	@FXML
	private TableColumn<Patient, String> emConColumn;

	@FXML
	private TableColumn<Patient, String> nameColumn;

	@FXML
	private TableColumn<Patient, String> sexColumn;
	@FXML
	private TableColumn<Patient, CheckBox> checkBoxColumn;
	
	@FXML
	private TableColumn<Patient, String> idColumn;

	@FXML
	private Button addButton;
	@FXML
	private Button deletButton;
	@FXML
	private Button modifyButton;
    @FXML
    private Button addBedButton;
	@FXML
	private Button assessButton;
	
	 @FXML
	    private Button rareRoomButton;

	@FXML // ����
	void addEvent(ActionEvent event) {

		if (showPatientAddDialog()) {		
			Patient e = addController.getNewPatient();
			patientData.add(e);
			patService.savePatientData(patientData);
			AlertUtils.newRmindAlert("���ӳɹ�\n����ɹ�", "���ӳɹ�", employeeStage);
			reflushPatientTableView(patientData);
		}
	}

	@FXML // ɾ��
	void deleteEvent(ActionEvent event) {

		int key =deleteByCheckBox();
		if (key==1) {
			patService.savePatientData(patientData);
			AlertUtils.newRmindAlert("ɾ������\n����ɹ�", "ɾ������", employeeStage);
		} else if (key==0){
			AlertUtils.newErrorAlert("error��δѡ��ɾ������", "��ѡ��ɾ������", employeeStage);
			return;
		}
		else {
			return;
		}
	}

	@FXML // �޸�
	void modifyEvent(ActionEvent event) {
		Patient p = patientTableView.getSelectionModel().getSelectedItem();
		if (p == null) {
			AlertUtils.newErrorAlert("error��δѡ���޸Ķ���", "��ѡ���޸Ķ���", employeeStage);
			return;
		}
		int index = patientTableView.getItems().indexOf(p);
		if (showPatientModifyDialog(p)) {
			if (AlertUtils.newQureAlert("���ȷ���޸Ļ�����Ϣ", "�Ƿ�ȷ���޸ģ�", employeeStage)) {
			p = modifyController.getModifiedPatient(); // ��dialog�л�ȡpatient ���ڵ�p�Ѿ����޸���
			patientTableView.getItems().set(index, p); //��������λ��
			patService.savePatientData(patientData);   //����
			AlertUtils.newRmindAlert("�޸ĳɹ�\n����ɹ�", "�޸ĳɹ�", employeeStage);
			}
		}

	}



	@FXML
	void searchEvent(ActionEvent event) {

		if (searchField.getText() == null || searchField.getText().length() == 0) {
			reflushPatientTableView(patientData);
			return;
		}
		patientList = patService.getEmployeeListBySearch(searchField.getText());
		if (patientList.size() == 0) {
			AlertUtils.newErrorAlert("�����Ÿı������ؼ���", "���Ҳ�����Ϣ", employeeStage);
			return;
		}
		reflushPatientTableView(patientList);

	}

	@FXML
	void assessEvent(ActionEvent event) {
		Patient p = patientTableView.getSelectionModel().getSelectedItem();
		if (p == null) {
			AlertUtils.newErrorAlert("error��δѡ����������", "��ѡ����������", employeeStage);
			return;
		}
		if(showPatientAssessDialog(p)) {
			Moudel m=assessController.getSelectMoudel();
			if(showPatientAssessStage(m,p)) {
				Assess assess =assessStageController.getNewAssess();
				if(assess==null) {
					return;
				}
				//WriteUtils.writeNewAssess("Assesses", assess);
				assessService=AssessService.getAssessService();
				assessService.AddNewAssessData(assess);
				AlertUtils.newRmindAlert("����ɹ�", "�������", employeeStage);		
			}
		}	
	}
	
	 @FXML
	    void addBedEvent(ActionEvent event) {
	
		
		 Patient p = patientTableView.getSelectionModel().getSelectedItem();
		if (p == null) {
				AlertUtils.newErrorAlert("error��δѡ���޸Ķ���", "��ѡ���޸Ķ���", employeeStage);
				return;
			}
		 if(buildingService.isPatientHasBed(p.getName())) {
				AlertUtils.newErrorAlert("error���ò�������ס", "�޷���ס", employeeStage);
				return;
		 }
		
			if(showPatientAddBedDialog(p)) {
				AlertUtils.newRmindAlert("���ӳɹ�","���ӳɹ�", employeeStage);
			}
		 
	    }
	 
	 @FXML
	   void useRareRoomEvent(ActionEvent event) {
		 Patient p = patientTableView.getSelectionModel().getSelectedItem();
			if (p == null) {
				AlertUtils.newErrorAlert("error��δѡ������ϡ���豸����", "��ѡ�����", employeeStage);
				return;
			}
		if(showPatientUseRareRoomDialog(p)) {
			AlertUtils.newRmindAlert("����ɹ�", "����ɹ�", employeeStage);
		}
	 }

	@FXML
	void initialize() {
		patService = PatientService.getPatientService();
		buildingService=BuildingService.getBuildingService();
		patientData = patService.getPatientDao().getPatientData();
		patientList = patientData;
		reflushPatientTableView(patientList);

	}

	public void reflushPatientTableView(ObservableList<Patient> patientData) {

		patientTableView.setItems(patientData);

		checkBoxColumn.setCellValueFactory(new PropertyValueFactory<Patient, CheckBox>("checkBox"));

		nameColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Patient, String>, ObservableValue<String>>() {
					@Override
					public ObservableValue<String> call(CellDataFeatures<Patient, String> param) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty(param.getValue().getName());
						return name;
					}
				});
		birthdayColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Patient, String>, ObservableValue<String>>() {
					@Override
					public ObservableValue<String> call(CellDataFeatures<Patient, String> param) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty(param.getValue().getBirthday());
						return name;
					}
				});
		telColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Patient, String>, ObservableValue<String>>() {
					@Override
					public ObservableValue<String> call(CellDataFeatures<Patient, String> param) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty(param.getValue().getTel());
						return name;
					}
				});
		idColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Patient, String>, ObservableValue<String>>() {
					@Override
					public ObservableValue<String> call(CellDataFeatures<Patient, String> param) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty(param.getValue().getId());
						return name;
					}
				});
		emConColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Patient, String>, ObservableValue<String>>() {
					@Override
					public ObservableValue<String> call(CellDataFeatures<Patient, String> param) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty(param.getValue().getEmergencyContact());
						return name;
					}
				});
		emConTelColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Patient, String>, ObservableValue<String>>() {
					@Override
					public ObservableValue<String> call(CellDataFeatures<Patient, String> param) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty(param.getValue().getEmConTel());
						return name;
					}
				});
		sexColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Patient, String>, ObservableValue<String>>() {
					@Override
					public ObservableValue<String> call(CellDataFeatures<Patient, String> param) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty(param.getValue().getSex());
						return name;
					}
				});

	}
	/**
	 * ��checkbox������ɾ����ע��ɾ��ʱҪ��������1
	 * 
	 * @return
	 */
	public int deleteByCheckBox() {
		int i=0;   //�ȼ��㱻��ѡ������
		for (Patient p:patientList) {
			if(p.getCheckBox().isSelected()) {
				i++;break;
			}
		}
		if(i==0) {return 0;}     //�������Ϊ0,����0,ɾ��ʧ��
		if (AlertUtils.newQureAlert("���ȷ��ɾ��������Ϣ\n���ȡ������", "ȷ���Ƿ�ɾ����", employeeStage)) {
		int index = -1;
		patientList = patientTableView.getItems();
		Patient e;
		for ( i = 0; i < patientList.size(); i++) {
			e = patientList.get(i);
			if (e.getCheckBox().isSelected()) {
				 if(buildingService.isPatientHasBed(e.getName())) {
					 index = patientTableView.getItems().indexOf(e);
					 AlertUtils.newRmindAlert("�ò���������ס�����Ȱ�����Ժ", "�޷�ɾ�����ˣ�"+e.getName(), employeeStage);													
				 }
				 else {
					index = patientTableView.getItems().indexOf(e);
					patientTableView.getItems().remove(index);
					patientData.remove(e);
					i--;}	
			}
		}	
		if (index != -1) {
			return 1;   //ɾ���ɹ�
		} else {
			return 0;   //ɾ��ʧ��
		}
	}
		return 2;		
	}

	/**
	 * 
	 * @return addDialog�Ƿ�ɹ�����Ա��
	 */
	boolean showPatientAddDialog() {
		try {
			// Load the fxml file and create a new stage for the popup dialog.
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("/View/PatientAddDialog.fxml"));
			AnchorPane page = (AnchorPane) loader.load();
			// Create the dialog Stage.
			Stage dialogStage = new Stage();
			dialogStage.setTitle("����");
			dialogStage.initOwner(employeeStage);
			dialogStage.initModality(Modality.WINDOW_MODAL); // ��������Ժ���벻�ܵ�ԭ����stage
			dialogStage.setWidth(350.0);
			dialogStage.setHeight(400.0);
			dialogStage.setResizable(false);
			Scene scene = new Scene(page);
			dialogStage.setScene(scene);
			scene.getStylesheets().add(getClass().getResource("/View/Dialog.css").toExternalForm());
			addController = loader.getController();
			addController.setDialogStage(dialogStage);
			// Show the dialog and wait until the user closes it
			
			dialogStage.showAndWait();//�ȴ�satge�ر�

			return addController.isOkClicked();  //���ز���ֵ���Ƿ�ɹ�����
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}

	boolean showPatientModifyDialog(Patient modifiedPatient) {
		try {
			// Load the fxml file and create a new stage for the popup dialog.
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("/View/PatientModifyDialog.fxml"));
			AnchorPane page = (AnchorPane) loader.load();
			// Create the dialog Stage.
			Stage dialogStage = new Stage();
			dialogStage.setTitle("�޸�");
			dialogStage.initOwner(employeeStage);
			dialogStage.setWidth(350.0);
			dialogStage.setHeight(400.0);
			dialogStage.setResizable(false);
			dialogStage.initModality(Modality.WINDOW_MODAL);
			Scene scene = new Scene(page);
			scene.getStylesheets().add(getClass().getResource("/View/Dialog.css").toExternalForm());
			dialogStage.setScene(scene);
			modifyController = loader.getController();
			modifyController.setModifiedPatient(modifiedPatient);
			modifyController.setDialogStage(dialogStage);
			// Show the dialog and wait until the user closes it
			dialogStage.showAndWait();

			return modifyController.isOkClicked();
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	boolean showPatientAssessDialog(Patient patient) {
		
		try {
			// Load the fxml file and create a new stage for the popup dialog.
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("/View/PatientAssessDialog.fxml"));
			AnchorPane page = (AnchorPane) loader.load();
			// Create the dialog Stage.
			Stage dialogStage = new Stage();
			dialogStage.setTitle("����");
			dialogStage.initOwner(employeeStage);
			dialogStage.setWidth(240.0);
			dialogStage.setHeight(270.0);
			dialogStage.setResizable(false);
			dialogStage.initModality(Modality.WINDOW_MODAL);
			Scene scene = new Scene(page);
			scene.getStylesheets().add(getClass().getResource("/View/Dialog.css").toExternalForm());
			dialogStage.setScene(scene);
			assessController = loader.getController();
			assessController.setEmployeeName(employeeName);
			assessController.setDialogStage(dialogStage);
			assessController.setPatientName(patient.getName());
			assessController.loadData();
			// Show the dialog and wait until the user closes it
			dialogStage.showAndWait();
			return assessController.isOkClicked();
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}
	boolean showPatientAssessStage(Moudel moudel,Patient patient) {
		
		try {
			// Load the fxml file and create a new stage for the popup dialog.
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("/View/PatientAssessStage.fxml"));
			AnchorPane page = (AnchorPane) loader.load();
			// Create the dialog Stage.
			Stage dialogStage = new Stage();
			dialogStage.setTitle("����");
			dialogStage.initOwner(employeeStage);
			dialogStage.setWidth(510.0);
			dialogStage.setHeight(320.0);
			dialogStage.setResizable(false);
			dialogStage.initModality(Modality.WINDOW_MODAL);
			Scene scene = new Scene(page);
			scene.getStylesheets().add(getClass().getResource("/View/Dialog.css").toExternalForm());
			dialogStage.setScene(scene);
			assessStageController = loader.getController();
			assessStageController.setAssessStage(dialogStage);
			assessStageController.setMoudel(moudel);
			assessStageController.loadMoudelData();
			assessStageController.setEmployeeName(employeeName);
			assessStageController.setPatient(patient);
			// Show the dialog and wait until the user closes it
			dialogStage.showAndWait();
			return assessStageController.isOkClicked();
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}
	boolean showPatientAddBedDialog(Patient patient) {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("/View/PatientAddBedDialog.fxml"));
			AnchorPane page = (AnchorPane) loader.load();
			// Create the dialog Stage.
			Stage dialogStage = new Stage();
			dialogStage.setTitle("���Ӳ���");
			dialogStage.initOwner(employeeStage);
			dialogStage.setWidth(614.0);
			dialogStage.setHeight(400.0);
			dialogStage.setResizable(false);
			dialogStage.initModality(Modality.WINDOW_MODAL);
			Scene scene = new Scene(page);
			scene.getStylesheets().add(getClass().getResource("/View/Dialog.css").toExternalForm());
			dialogStage.setScene(scene);
			addBedController = loader.getController();
			addBedController.setPatient(patient);
			addBedController.setDialogStage(dialogStage);
			addBedController.loadData();
			// Show the dialog and wait until the user closes it
			dialogStage.showAndWait();
			return addBedController.isOkClicked();
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}
	boolean showPatientUseRareRoomDialog(Patient patient) {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("/View/PatientUseRareRoomDialog.fxml"));
			AnchorPane page = (AnchorPane) loader.load();
			// Create the dialog Stage.
			Stage dialogStage = new Stage();
			dialogStage.setTitle("����ϡ���豸");
			dialogStage.initOwner(employeeStage);
			dialogStage.setWidth(400.0);
			dialogStage.setHeight(450.0);
			dialogStage.setResizable(false);
			dialogStage.initModality(Modality.WINDOW_MODAL);
			Scene scene = new Scene(page);
			scene.getStylesheets().add(getClass().getResource("/View/Dialog.css").toExternalForm());
			dialogStage.setScene(scene);
			rareRoomController = loader.getController();	
			rareRoomController.setDialogStage(dialogStage);
			rareRoomController.setPatient(patient);
			// Show the dialog and wait until the user closes it
			dialogStage.showAndWait();
			return rareRoomController.isOkClicked();
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public void initAndReflush() {
		// TODO Auto-generated method stub
		
	}
	
}
