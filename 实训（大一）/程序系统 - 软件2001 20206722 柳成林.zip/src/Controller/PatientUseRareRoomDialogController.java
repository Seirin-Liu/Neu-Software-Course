package Controller;

import Entity.Patient;
import Entity.RareRoom;
import Service.RareRoomService;
import Util.AlertUtils;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.stage.Stage;
import javafx.util.Callback;


/**
 * ��������ϡ���豸
 * @author Seirin
 *
 */
public class PatientUseRareRoomDialogController {

	private Stage dialogStage;
	private RareRoomService rareRoomService;
	private ObservableList<RareRoom> rareRoomData;
	private Patient patient;

	public Patient getPatient() {
		return patient;
	}

	public void setPatient(Patient patient) {
		this.patient = patient;
		label.setText("�����ˣ�"+patient.getName());
	}

	private boolean okClicked = false;

	public Stage getDialogStage() {
		return dialogStage;
	}

	public void setDialogStage(Stage dialogStage) {
		this.dialogStage = dialogStage;
	}

	public boolean isOkClicked() {
		return okClicked;
	}

	public void setOkClicked(boolean okClicked) {
		this.okClicked = okClicked;
	}

	@FXML
	private Button cancelButton;
	@FXML
	private TableColumn<RareRoom, String> max;
	@FXML
	private TableColumn<RareRoom, String> now;
	@FXML
	private TableColumn<RareRoom, String> name;
	@FXML
	private Button okButton;
	@FXML
	private TableColumn<RareRoom, String> type;
	@FXML
	private TableView<RareRoom> table;
	@FXML
	private Label label;

	@FXML
	private void initialize() {

		rareRoomService = RareRoomService.getRareRooomService();
		rareRoomData = rareRoomService.getRareRoomDao().getRareRoomData();

		table.setItems(rareRoomData);

		name.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<RareRoom, String>, ObservableValue<String>>() {

					@Override
					public ObservableValue<String> call(CellDataFeatures<RareRoom, String> param) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty(param.getValue().getName());
						return name;
					}
				});
		type.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<RareRoom, String>, ObservableValue<String>>() {

					@Override
					public ObservableValue<String> call(CellDataFeatures<RareRoom, String> param) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty(param.getValue().getRareType());
						return name;
					}
				});
		max.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<RareRoom, String>, ObservableValue<String>>() {

					@Override
					public ObservableValue<String> call(CellDataFeatures<RareRoom, String> param) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty("" + param.getValue().getMax());
						return name;
					}
				});
		now.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<RareRoom, String>, ObservableValue<String>>() {

					@Override
					public ObservableValue<String> call(CellDataFeatures<RareRoom, String> param) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty("" + param.getValue().getNow());
						return name;
					}
				});

	}

	@FXML
	void okEvent(ActionEvent event) {
		RareRoom r = table.getSelectionModel().getSelectedItem();
		if (r == null) {
			dialogStage.close();
			return;
		}
		if(r.getUserId().contains(patient.getName()+"-"+patient.getId())) {
			AlertUtils.newErrorAlert("����������豸", "����ʧ��", dialogStage);
			return;
		}
		if (r.getNow() < r.getMax()) {
			int index = table.getItems().indexOf(r);
			int i = r.getNow() + 1;
			r.setNow(i);
			r.getUserId().add(patient.getName()+"-"+patient.getId());
			rareRoomData.set(index, r);
			rareRoomService.saveRareRoomData(rareRoomData);
			okClicked = true;
			dialogStage.close();
		} else {
			AlertUtils.newErrorAlert("�÷�����������", "����ʧ��", dialogStage);
		}

	}

	@FXML
	void cancelEvent(ActionEvent event) {

		dialogStage.close();
	}

	
}
