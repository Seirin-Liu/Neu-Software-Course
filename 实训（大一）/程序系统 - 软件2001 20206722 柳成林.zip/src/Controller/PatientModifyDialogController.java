package Controller;

import Entity.Patient;
import Util.AlertUtils;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * �޸Ļ��߽���
 * @author Seirin
 *
 */
public class PatientModifyDialogController implements InputValidInterface {

	
	  private  Stage dialogStage;
	  private Patient modifiedPatient;
	  private boolean okClicked=false;
	  
	  public Stage getDialogStage() {
		return dialogStage;
	}

	public void setDialogStage(Stage dialogStage) {
		this.dialogStage = dialogStage;
	}


	public Patient getModifiedPatient() {
		return modifiedPatient;
	}

	public void setModifiedPatient(Patient modifiedPatient) {
		this.modifiedPatient = modifiedPatient;
		nameTextField.setText(modifiedPatient.getName());
		birthdayTextField.setText(modifiedPatient.getBirthday());
		idTextField.setText(modifiedPatient.getId());
		telTextField.setText(modifiedPatient.getTel());
		ecTextField.setText(modifiedPatient.getEmergencyContact());
		ectTextField.setText(modifiedPatient.getEmConTel());
		sexComboBox.setValue(modifiedPatient.getSex());
	}

	public boolean isOkClicked() {
		return okClicked;
	}

	public void setOkClicked(boolean okClicked) {
		this.okClicked = okClicked;
	}

	@FXML
	    private TextField idTextField;

	    @FXML
	    private TextField birthdayTextField;

	    @FXML
	    private Button cancelButton;

	    @FXML
	    private TextField ectTextField;

	    @FXML
	    private ComboBox<String> sexComboBox;

	    @FXML
	    private TextField nameTextField;

	    @FXML
	    private TextField ecTextField;

	    @FXML
	    private Button okButton;

	    @FXML
	    private TextField telTextField;

	    
	    @FXML
		private void initialize() {ObservableList<String> options = 
	    FXCollections.observableArrayList(
		    	"��",
		        "Ů"        
		    );  	
	    	sexComboBox.setItems(options);
	    	
	    }
	    
	   
	    @FXML
	    void okEvent(ActionEvent event) {
          if(isInputValid()) {
        	  modifiedPatient=new Patient(nameTextField.getText(), sexComboBox.getValue(), birthdayTextField.getText(),
            idTextField.getText(), telTextField.getText(), ecTextField.getText(),
           ectTextField.getText());
        	  okClicked=true;
        	  dialogStage.close();
          }
	    	
	    }

	    @FXML
	    void cancelEvent(ActionEvent event) {
	    	
	    	  dialogStage.close();
	    	
	    }

		@Override
		public boolean isInputValid() {
			// TODO Auto-generated method stub
			 String errorMessage = "";

	    
	         if (nameTextField.getText() == null || nameTextField.getText().length() == 0) {
	             errorMessage += "����Ϊ��\n"; 
	         }	        
	         if (birthdayTextField.getText() == null || birthdayTextField.getText().length() == 0) {
	             errorMessage += "����Ϊ��\n"; 
	         }	
	         if (idTextField.getText() == null || idTextField.getText().length() == 0) {
	             errorMessage += "����֤Ϊ��\n"; 
	         }	        
	         if (ecTextField.getText() == null || ecTextField.getText().length() == 0) {
	             errorMessage += "������ϵ��Ϊ��\n"; 
	         }	        
	         if (ectTextField.getText() == null || ectTextField.getText().length() == 0) {
	             errorMessage += "������ϵ�˵绰Ϊ��\n"; 
	         }
	         if (sexComboBox.getValue()== null ||sexComboBox.getValue().length() == 0) {
	             errorMessage += "�Ա�Ϊ��\n"; 
	         }	        
	            
	           
	         if (errorMessage.length() == 0) {
	             return true;
	             
	         } else {
	        	 
	             AlertUtils.newErrorAlert(errorMessage, "��������Ч����", dialogStage);	             
	             return false;
	         }
	    	
	    }
}
