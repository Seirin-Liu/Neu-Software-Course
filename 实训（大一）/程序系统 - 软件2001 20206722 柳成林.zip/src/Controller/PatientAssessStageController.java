package Controller;

import java.text.SimpleDateFormat;
import java.util.Date;

import Entity.Assess;
import Entity.Moudel;
import Entity.Patient;
import Entity.Question;
import Service.PatientService;
import Util.AlertUtils;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.stage.Stage;

/**
 * �������
 * @author Seirin
 *
 */
public class PatientAssessStageController {
	
	private Stage assessStage;
	private Moudel moudel;  //ʹ�õ�ģ��
	private Assess newAssess;//�µ������¼
	private String employeeName;
	private Patient patient;
	
	private boolean okClicked=false;
	
	private ObservableList<Node> questions; //���ص�ListView��
	
	private int score;//����
	
	private PatientService patService;
	
    public Assess getNewAssess() {
		return newAssess;
	}

	public void setNewAssess(Assess newAssess) {
		this.newAssess = newAssess;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public Patient getPatient() {
		return patient;
	}

	public void setPatient(Patient patient) {
		this.patient = patient;
	}

	public boolean isOkClicked() {
		return okClicked;
	}

	public void setOkClicked(boolean okClicked) {
		this.okClicked = okClicked;
	}

	public Moudel getMoudel() {
		return moudel;
	}

	public void setMoudel(Moudel moudel) {
		this.moudel = moudel;
	}

	public Stage getAssessStage() {
		return assessStage;
	}

	public void setAssessStage(Stage assessStage) {
		this.assessStage = assessStage;
	}
	@FXML
    private Button cancelButton;

    @FXML
    private ListView<Node> questionListView;
    
    @FXML
    private Button okButton;
    
    @FXML
    private Button submitButton;

    @FXML
    private TextField adviceTextField;
    
    @FXML
    private Label scoreLabel;

    
    //���㲢��ʾ����
    @FXML
    void okEvent(ActionEvent event) {
    	score=0;
    	for(int i=0;i<questions.size();i++) {	
    		if(i%4!=0)
			{
				RadioButton r=(RadioButton)questions.get(i);
				if(r.isSelected()&&i%4==1)
				{
					score+=5;
				}
				if(r.isSelected()&&i%4==2)
				{
					score+=3;
				}
				if(r.isSelected()&&i%4==3)
				{
					score+=1;
				}
			}
    	} 
    scoreLabel.setText("������ "+score);
    }

    @FXML
    void cancelEvent(ActionEvent event) {

    	assessStage.close();
    }
    
    /**
     * ����������¼
     * @param event
     */
    @FXML
    void submitEvent(ActionEvent event) {

    	if(AlertUtils.newQureAlert("���ȷ�������¼", "��ȷ���Ƿ��ύ", assessStage)) {
    	Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
    	newAssess=new Assess(patient.getName(),patient.getSex(), moudel.getName(), moudel.getType(), employeeName, formatter.format(date),adviceTextField.getText());
    	Patient p=patient;
    	p.setAssessRecord(newAssess);
    	Patient modifiedPatient=p;
    	patService.saveModifiedPatient(patient, modifiedPatient); //���޸ĺ��patient���浽�ļ���
    	okClicked=true;
    	assessStage.close();
    	}
    }
    
    /**
     * ��ʼ���������������
     */
    public void loadMoudelData() {
    	questions=FXCollections.observableArrayList();
    	ObservableList<Question> questionData=FXCollections.observableArrayList(moudel.getQuestions());
    	patService=PatientService.getPatientService();
    	int index=0;
    	for(int i=0,j=i+1;i<questionData.size();i++) {  		
    		Question q=questionData.get(index);
    		questions.add(new Label(j+"."+q.getContent()));
    		RadioButton  button1=new RadioButton("ѡ��1: "+q.getChoose1());
    		RadioButton  button2=new RadioButton("ѡ��2: "+q.getChoose2());
    		RadioButton  button3=new RadioButton("ѡ��3: "+q.getChoose3());
    		ToggleGroup tg=new ToggleGroup();
    		button1.setToggleGroup(tg);
            button2.setToggleGroup(tg);
            button3.setToggleGroup(tg);
    		questions.addAll(button1,button2,button3);	 
    		index++;
    		j++;
    	}
    	questionListView.setItems(questions);
    }
    
}
