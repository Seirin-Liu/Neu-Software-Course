package Controller;

import java.io.IOException;

import Dao.ManagerDao;
import Entity.Employee;
import Entity.Manager;
import Service.EmployeeService;
import Util.AlertUtils;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Callback;

/**
 * ����Ա���������
 * @author Seirin
 *
 */
public class ManagerSceneController implements DeleteByCheckBox {

	private Manager manager; // ��¼�Ĺ���Ա
	private Stage managerStage; // ��ǰҳ��

	private EmployeeAddDialogController addController;
	private EmployeeModifyDialogController modifyController;
	private ManagerModifyDialogController managerModifyController;
	static String status; // (ȫ��Ա����ҽ������������ʿ�������б���

	private EmployeeService empService;

	ObservableList<Employee> employeeData; // ����Ա��
	ObservableList<Employee> employeeList; // �����б���ʾ��Ա��
											// ͨ����ȡstatus������EmployeeService�����ı�employeeList
											// �����¼����б�
	@FXML
	private Label managerName;
	@FXML
	private Label label1;
	@FXML
	private TableColumn<Employee, String> usernameColumn;
	@FXML
	private TableColumn<Employee, String> nameColumn;
	@FXML
	private TextField searchField;
	@FXML
	private Button searchButton;
	@FXML
	private TableColumn<Employee, CheckBox> checkColumn;
	@FXML
	private TableColumn<Employee, String> professionColumn;
	@FXML
	private TableColumn<Employee, String> birthdayColumn;
	@FXML
	private TableColumn<Employee, String> specialityColumn;
	@FXML
	private TableView<Employee> employeeTableView;
	@FXML
	private TableColumn<Employee, String> idColumn;
//	@FXML
//	private ComboBox<String> comboBox;
	@FXML
	private TreeView<String> treeView;
	@FXML
	private ImageView back;
	@FXML
	private AnchorPane mainPane;
	@FXML
	private Button deleteButton;
	@FXML
	private Button addButton;
	@FXML
	private Button modifyButton;
	@FXML
	private Button saveButton;
	@FXML
	private Button nurseButton;
	@FXML
	private Button doctorButton;
	@FXML
	private Button nursingAssistantButton;
	@FXML
	private Button seeAllButton;
	@FXML
	private Hyperlink exitLink;
	@FXML
	private Hyperlink managerModifyLink;

	public Manager getManager() {
		return manager;
	}

	public void setManager(Manager manager) {
		this.manager = manager;
	}

	public void setManagerStage(Stage managerStage) {
		this.managerStage = managerStage;
	}

	@FXML // ��ʼ��
	private void initialize() {

		empService = EmployeeService.getEmployeeService();
		employeeData = empService.getEmployeeDao().getEmployeeData();
		employeeList = employeeData;
		status = "ȫ��Ա��"; // ��ʼ״̬Ϊȫ��Ա��
//		ObservableList<String> options = FXCollections.observableArrayList("ȫ��Ա��", "ҽ��", "����", "��ʿ");
//		comboBox.setItems(options);
//		comboBox.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
//
//			@Override
//			public void changed(ObservableValue<? extends String> arg0, String arg1, String newValue) {
//				// TODO Auto-generated method stub
//				if (newValue.equals("ȫ��Ա��")) {
//					seeAllEvent(null);
//				}
//				if (newValue.equals("ҽ��")) {
//					doctorEvent(null);
//				}
//				if (newValue.equals("����")) {
//					nursingAssistantEvent(null);
//				}
//				if (newValue.equals("��ʿ")) {
//					nurseEvent(null);
//				}
//			}
//
//		});
		
		loadTree();
		//Ϊtree���Ӽ����¼�
		treeView.setOnMouseClicked(new EventHandler<MouseEvent>()
		{
		    @Override
		    public void handle(MouseEvent mouseEvent)
		    {
		        if(mouseEvent.getClickCount() == 1)
		        {
		            TreeItem<String> item = treeView.getSelectionModel().getSelectedItem();  //��ȡ�������
		            String newValue=item.getValue();
		            if (newValue.equals("ȫ��Ա��")) {
						seeAllEvent(null);
					}
					if (newValue.equals("ҽ������")) {
						doctorEvent(null);
					}
					if (newValue.equals("��������")) {
						nursingAssistantEvent(null);
					}
					if (newValue.equals("��ʿ����")) {
						nurseEvent(null);
					}
				}
		          	          
		        }
		});
		reflushEmployeeTableView(employeeList);

	}

	/**
	 * ���¼��ر������ݣ������employee��list
	 * 
	 * @param employeeData
	 */
	public void reflushEmployeeTableView(ObservableList<Employee> employeeData) {

		employeeTableView.setItems(employeeData);

		checkColumn.setCellValueFactory(new PropertyValueFactory<Employee, CheckBox>("checkBox"));

		nameColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Employee, String>, ObservableValue<String>>() {
					@Override
					public ObservableValue<String> call(CellDataFeatures<Employee, String> param) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty(param.getValue().getName());
						return name;
					}
				});
		usernameColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Employee, String>, ObservableValue<String>>() {

					@Override
					public ObservableValue<String> call(CellDataFeatures<Employee, String> param) {

						return new SimpleStringProperty(param.getValue().getUsername());
					}
				});
		professionColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Employee, String>, ObservableValue<String>>() {

					@Override
					public ObservableValue<String> call(CellDataFeatures<Employee, String> param) {

						return new SimpleStringProperty(param.getValue().getProfession());
					}
				});
		birthdayColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Employee, String>, ObservableValue<String>>() {

					@Override
					public ObservableValue<String> call(CellDataFeatures<Employee, String> param) {

						return new SimpleStringProperty(param.getValue().getBirthday());
					}
				});
		specialityColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Employee, String>, ObservableValue<String>>() {

					@Override
					public ObservableValue<String> call(CellDataFeatures<Employee, String> param) {

						return new SimpleStringProperty(param.getValue().getSpeciality());
					}
				});
		idColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Employee, String>, ObservableValue<String>>() {

					@Override
					public ObservableValue<String> call(CellDataFeatures<Employee, String> param) {

						return new SimpleStringProperty(param.getValue().getId());
					}
				});
	}

	
	@FXML
	void addEvent(ActionEvent event) {
		if (showEmployeeAddDialog()) {
			AlertUtils.newRmindAlert("���ӳɹ�", "���ӳɹ�", managerStage);
			Employee e = addController.getNewEmployee();
			employeeData.add(e);
			empService.saveEmployeeData(employeeData);
			reflushEmployeeTableView(employeeData);
		}

	}

	@FXML
	void modifyEvent(ActionEvent event) {
		Employee e = employeeTableView.getSelectionModel().getSelectedItem();
		if (e == null) {
			AlertUtils.newErrorAlert("error��δѡ���޸Ķ���", "��ѡ���޸Ķ���", managerStage);
			return;
		}

		if (showEmployeeModifyDialog(e)) {
			if (AlertUtils.newQureAlert("���ȷ���޸�Ա����Ϣ", "�Ƿ�ȷ���޸ģ�", managerStage)) {
				e = modifyController.getModifiedEmployee(); // ���ڵ�e�Ѿ����޸���
				int index = employeeTableView.getItems().indexOf(e);
				employeeTableView.getItems().set(index, e);
				empService.saveEmployeeData(employeeData);
				AlertUtils.newRmindAlert("�޸ĳɹ�", "�޸ĳɹ�", managerStage);
			}
			if (status.equals("ȫ��Ա��")) {
				reflushEmployeeTableView(employeeData);
			} else {
				reflushEmployeeTableView(empService.getEmployeeListOfProfession(status));
			}
		}
	}

	@FXML
	void deleteEvent(ActionEvent event) {
		int key = deleteByCheckBox();
		if (key == 1) {

			empService.saveEmployeeData(employeeData);
			AlertUtils.newRmindAlert("ɾ���ɹ�", "ɾ���ɹ�", managerStage);

		} else if (key == 0) {
			AlertUtils.newErrorAlert("error��δѡ��ɾ������", "��ѡ��ɾ������", managerStage);
			return;
		} else {
			return;
		}
	}

	@FXML
	void searchEvent(ActionEvent event) {

		if (searchField.getText() == null || searchField.getText().length() == 0) {
			reflushEmployeeTableView(employeeData);
			return;
		}
		employeeList = empService.getEmployeeListBySearch(searchField.getText());
		if (employeeList.size() == 0) {
			AlertUtils.newErrorAlert("�����Ÿı������ؼ���", "���Ҳ�����Ϣ", managerStage);
			return;
		}
		if (!(status.equals("�����б�"))) {
			status = "�����б�";
		}
		reflushEmployeeTableView(employeeList);
	}

	@FXML
	void saveEvent(ActionEvent event) {

		empService.saveEmployeeData(employeeData); // �ѵ�ǰ��Datalist���浽�ļ�
		AlertUtils.newRmindAlert("����ɹ�", "����ɹ�", managerStage);
	}

	@FXML
	void doctorEvent(ActionEvent event) {
		if (!(status.equals("ҽ��"))) {
			status = "ҽ��";
			employeeList = empService.getEmployeeListOfProfession(status);
		}
		reflushEmployeeTableView(employeeList);
	}

	@FXML
	void nursingAssistantEvent(ActionEvent event) {

		if (!(status.equals("����"))) {
			status = "����";
			employeeList = empService.getEmployeeListOfProfession(status);
		}
		reflushEmployeeTableView(employeeList);
	}

	@FXML
	void nurseEvent(ActionEvent event) {

		if (!(status.equals("��ʿ"))) {
			status = "��ʿ";
			employeeList = empService.getEmployeeListOfProfession(status);
		}
		reflushEmployeeTableView(employeeList);
	}

	@FXML
	void seeAllEvent(ActionEvent event) {

		if (!(status.equals("ȫ��Ա��"))) {
			status = "ȫ��Ա��";
			reflushEmployeeTableView(employeeData);
		}

	}

	/**
	 * �޸Ĺ���Ա��Ϣ
	 * 
	 * @param event
	 */
	@FXML
	void managerModifyEvent(ActionEvent event) {

		if (showManagerModifyDialog(manager)) {
			if (AlertUtils.newQureAlert("���ȷ���������Ա��Ϣ", "�Ƿ񱣴��޸ģ�", managerStage)) {
				manager = managerModifyController.getManager();
				ManagerDao.getManagerDao().saveNewManager(manager);
				AlertUtils.newRmindAlert("�޸ĳɹ�", "�޸ĳɹ�", managerStage);
				setManagerdata();
			}
		}
	}

	@FXML
	void exitEvent(ActionEvent event) {

		managerStage.close();
		Main main = new Main();
		AlertUtils.newRmindAlert("ע���ɹ�", "ע���ɹ�", null);
		main.initLoginSceneAsExit(manager.getUsername(), manager.getPassword());
	}

	/**
	 * ��checkbox������ɾ����ע��ɾ��ʱҪ��������1
	 * 
	 * @return
	 */
	public int deleteByCheckBox() {
		int i = 0;
		for (Employee p : employeeList) {
			if (p.getCheckBox().isSelected()) {
				i++;
				break;
			}
		}
		if (i == 0) {
			return 0;
		}
		if (AlertUtils.newQureAlert("���ȷ��ɾ��Ա����Ϣ\n���ȡ������", "ȷ���Ƿ�ɾ����", managerStage)) {
			int index = -1;
			employeeList = employeeTableView.getItems();
			Employee e;
			for (i = 0; i < employeeList.size(); i++) {
				e = employeeList.get(i);
				if (e.getCheckBox().isSelected()) {
					index = employeeTableView.getItems().indexOf(e);
					employeeTableView.getItems().remove(index);
					employeeData.remove(e);
					i--;
				}
			}
			if (index != -1) {
				return 1;
			} else {
				return 0;
			}
		}
		return -1;
	}

	/**
	 * 
	 * @return addDialog�Ƿ�ɹ�����Ա��
	 */
	boolean showEmployeeAddDialog() {
		try {
			// Load the fxml file and create a new stage for the popup dialog.
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("/View/EmployeeAddDialog.fxml"));
			AnchorPane page = (AnchorPane) loader.load();
			// Create the dialog Stage.
			Stage dialogStage = new Stage();
			dialogStage.setTitle("����");
			dialogStage.initOwner(managerStage);
			dialogStage.initModality(Modality.WINDOW_MODAL); // ��������Ժ���벻�ܵ�ԭ����stage
			dialogStage.setWidth(400.0);
			dialogStage.setHeight(240.0);
			dialogStage.setResizable(false);
			Scene scene = new Scene(page);
			scene.getStylesheets().add(getClass().getResource("/View/EmployeeAddDialog.css").toExternalForm());
			dialogStage.setScene(scene);
			addController = loader.getController();
			addController.setDialogStage(dialogStage);
			// Show the dialog and wait until the user closes it
			dialogStage.showAndWait();

			return addController.isOkClicked();
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}

	boolean showEmployeeModifyDialog(Employee modifiedEmployee) {
		try {
			// Load the fxml file and create a new stage for the popup dialog.
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("/View/EmployeeModifyDialog.fxml"));
			AnchorPane page = (AnchorPane) loader.load();
			// Create the dialog Stage.
			Stage dialogStage = new Stage();
			dialogStage.setTitle("�޸�");
			dialogStage.initOwner(managerStage);
			dialogStage.initModality(Modality.WINDOW_MODAL);
			dialogStage.setWidth(370.0);
			dialogStage.setHeight(400.0);
			dialogStage.setResizable(false);
			Scene scene = new Scene(page);
			scene.getStylesheets().add(getClass().getResource("/View/EmployeeModifyDialog.css").toExternalForm());
			dialogStage.setScene(scene);
			modifyController = loader.getController();
			modifyController.setDialogStage(dialogStage);
			modifyController.setModifiedEmployee(modifiedEmployee);
			modifyController.loadOldEmployeeInfom(modifiedEmployee);
			// Show the dialog and wait until the user closes it
			dialogStage.showAndWait();

			return modifyController.isOkClicked();

		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}

	boolean showManagerModifyDialog(Manager manager) {
		try {
			// Load the fxml file and create a new stage for the popup dialog.
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("/View/ManagerModifyDialog.fxml"));
			AnchorPane page = (AnchorPane) loader.load();
			// Create the dialog Stage.
			Stage dialogStage = new Stage();
			dialogStage.setTitle("�޸�");
			dialogStage.initOwner(managerStage);
			dialogStage.initModality(Modality.WINDOW_MODAL);
			dialogStage.setWidth(400.0);
			dialogStage.setHeight(240.0);
			dialogStage.setResizable(false);
			Scene scene = new Scene(page);
			scene.getStylesheets().add(getClass().getResource("/View/Dialog.css").toExternalForm());
			dialogStage.setScene(scene);
			managerModifyController = loader.getController();
			managerModifyController.setDialogStage(dialogStage);
			managerModifyController.setManager(manager);
			managerModifyController.loadManager();
			// Show the dialog and wait until the user closes it
			dialogStage.showAndWait();

			return managerModifyController.isOkClicked();

		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public void loadTree() {
		
		 Image depIcon = new Image("file:pictures\\�û�.png");
		 ImageView img=new ImageView(depIcon);
		 img.setFitHeight(20.0);
		 img.setFitWidth(20.0);
		 TreeItem<String> hosItem = new TreeItem<String>("����Ա����",img);
		 hosItem.setExpanded(true);
		 TreeItem<String> item1 = new TreeItem<String>("ҽ������");
		 TreeItem<String> item2 = new TreeItem<String>("��ʿ����");
		 TreeItem<String> item3 = new TreeItem<String>("��������");
		 TreeItem<String> item4 = new TreeItem<String>("ȫ��Ա��");
		 hosItem.getChildren().add(item1);
		 hosItem.getChildren().add(item2);
		 hosItem.getChildren().add(item3);
		 hosItem.getChildren().add(item4);
		 treeView.setRoot(hosItem);
		}

	public void setManagerdata() {
		managerName.setText("����Ա ��" + manager.getUsername());
	}

}
