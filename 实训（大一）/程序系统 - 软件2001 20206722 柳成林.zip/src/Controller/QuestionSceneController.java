package Controller;


import java.io.IOException;

import Entity.Question;
import Service.MoudelService;
import Service.QuestionService;
import Util.AlertUtils;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Callback;

public class QuestionSceneController  implements TabReLoadInterface,DeleteByCheckBox{


	private Stage employeeStage;
	private ObservableList<Question> questionData; 
	private ObservableList<Question> questionList;
	private QuestionService queService;
	
	private QuestionAddDialogController addController;
	private QuestionModifyDialogController modifyController;
	private MoudelService mouService;
	
	
    public Stage getEmployeeStage() {
		return employeeStage;
	}

	public void setEmployeeStage(Stage employeeStage) {
		this.employeeStage = employeeStage;
	}

	@FXML
    private Button searchButton;

    @FXML
    private TextField searchField;

    @FXML
    private Button addButton;

    @FXML
    private TableColumn<Question, String> typeColumn;

    @FXML
    private TableView<Question> questionTableView;

    @FXML
    private TableColumn<Question, String> choose1Column;

    @FXML
    private Button deletButton;

    @FXML
    private Button modifyButton;

    @FXML
    private TableColumn<Question, CheckBox> checkBoxColumn;

    @FXML
    private TableColumn<Question, String> choose2Column;

    @FXML
    private TableColumn<Question, String> contentColumn;


    @FXML
    private TableColumn<Question, String> choose3Column;

    @FXML
    private TableColumn<Question, String> idColumn;

    @FXML
    void addEvent(ActionEvent event) {

    	if (showQuestionAddDialog()) {
    		if (AlertUtils.newQureAlert("���ȷ���������Ⲣ����\n", "�Ƿ�ȷ�����������棿", employeeStage)) {
			Question e = addController.getNewQuestion();
			questionData.add(e);
			 queService.saveQuestionData(questionData);  //���� 
			AlertUtils.newRmindAlert("���ӳɹ�\n����ɹ�", "���ӳɹ�", employeeStage);
			reflushQuestionTableView(questionData);
    		}
		}
    	
    }

    @FXML
    void deleteEvent(ActionEvent event) {

    	int key =deleteByCheckBox();
		if (key==1) {		
		    queService.saveQuestionData(questionData);  //����  //ͬʱdao�������Ҳ���޸�
			AlertUtils.newRmindAlert("ɾ���ɹ�\n����ɹ�", "ɾ���ɹ�", employeeStage);	
		} else if (key==0){
			AlertUtils.newErrorAlert("error��δѡ��ɾ������", "��ѡ��ɾ������", employeeStage);
			return;
		}
		else {
			return;
		}
    }

    @FXML
    void modifyEvent(ActionEvent event) {
    	Question q =questionTableView.getSelectionModel().getSelectedItem();
    	if(q==null) {
    		AlertUtils.newErrorAlert("error��δѡ���޸Ķ���", "��ѡ���޸Ķ���", employeeStage);
    		return;
    	}
    	int index =questionTableView.getItems().indexOf(q);
    	if(showQuestionModifyDialog(q)) {
    		if (AlertUtils.newQureAlert("���ȷ���޸���Ϣ������\n��Ҳ��ı�ģ���е�������Ϣ", "�Ƿ�ȷ���޸Ĳ����棿", employeeStage)) {
    		q=modifyController.getModifiedQuestion();  //��ȡ��dialog�е�question
    		questionTableView.getItems().set(index, q);  //�ı�table�е�question
    		modifyQuestionInMoudel(q);//�ı�moudel�е�question		
    		queService.saveQuestionData(questionData);  //���� 
    		AlertUtils.newRmindAlert("�޸ĳɹ�\n����ɹ�", "�޸ĳɹ�", employeeStage);
    		}
    	}
    	
    }

   

    @FXML
    void searchEvent(ActionEvent event) {
    	if (searchField.getText() == null || searchField.getText().length() == 0) {
    		reflushQuestionTableView(questionData);
    		return;    	
    		}
    	questionList=queService.getQuestionBySearch(searchField.getText());
    	if(questionList.size()==0) {
    		AlertUtils.newErrorAlert("�����Ÿı������ؼ���", "���Ҳ�������", employeeStage);
			return;
    	}
    	reflushQuestionTableView(questionList);
    	
    }

	@FXML
	void initialize() {
		
		queService=new QuestionService();
		questionData=queService.getQuestionDao().getQuestionData();
		questionList=questionData;
		reflushQuestionTableView(questionList);
		for(Question q:questionData) {
			q.getCheckBox().setSelected(false);
		}
	}
    
    public void reflushQuestionTableView(ObservableList<Question> questionData) {
    	
    	questionTableView.setItems(questionData);
    	
    	idColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Question, String>, ObservableValue<String>>() {
					@Override
					public ObservableValue<String> call(CellDataFeatures<Question, String> param) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty(""+param.getValue().getId());
						return name;
					}
				});
    	typeColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Question, String>, ObservableValue<String>>() {
					@Override
					public ObservableValue<String> call(CellDataFeatures<Question, String> param) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty(param.getValue().getType());
						return name;
					}
				});
    	contentColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Question, String>, ObservableValue<String>>() {
					@Override
					public ObservableValue<String> call(CellDataFeatures<Question, String> param) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty(param.getValue().getContent());
						return name;
					}
				});
    	choose1Column.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Question, String>, ObservableValue<String>>() {
					@Override
					public ObservableValue<String> call(CellDataFeatures<Question, String> param) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty(param.getValue().getChoose1());
						return name;
					}
				});
    	choose2Column.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Question, String>, ObservableValue<String>>() {
					@Override
					public ObservableValue<String> call(CellDataFeatures<Question, String> param) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty(param.getValue().getChoose2());
						return name;
					}
				});
    	choose3Column.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Question, String>, ObservableValue<String>>() {
					@Override
					public ObservableValue<String> call(CellDataFeatures<Question, String> param) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty(param.getValue().getChoose3());
						return name;
					}
				});
    	checkBoxColumn.setCellValueFactory(new PropertyValueFactory<Question, CheckBox>("checkBox"));
    }
       
	public int deleteByCheckBox() {
		int i=0;
		for (Question p:questionList) {
			if(p.getCheckBox().isSelected()) {
				i++;break;
			}
		}
		if(i==0) {return 0;}
		if (AlertUtils.newQureAlert("��Ҳ��ı�ģ���е�������Ϣ", "ȷ���Ƿ�ɾ�������棿", employeeStage)) {
		int index = -1;
		questionList = questionTableView.getItems();
		Question q;
		for ( i = 0; i < questionList.size(); i++) {
			q = questionList.get(i);
			if (q.getCheckBox().isSelected()) {
				index = questionTableView.getItems().indexOf(q);
				questionTableView.getItems().remove(index);
				questionData.remove(q);
				deleteQuestionInMoudel(q);
				i--;
			}
		}	
		if (index != -1) {
			return 1;
		} else {
			return 0;
		}
	}
		return 2;		
	}
	
	boolean showQuestionAddDialog() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("/View/QuestionAddDialog.fxml"));
			AnchorPane page = (AnchorPane) loader.load();
			// Create the dialog Stage.
			Stage dialogStage = new Stage();
			dialogStage.setTitle("����");
			dialogStage.initOwner(employeeStage);
			dialogStage.initModality(Modality.WINDOW_MODAL); // ��������Ժ���벻�ܵ�ԭ����stage
			dialogStage.setWidth(350.0);
			dialogStage.setHeight(400.0);
			dialogStage.setResizable(false);
			Scene scene = new Scene(page);
			scene.getStylesheets().add(getClass().getResource("/View/Dialog.css").toExternalForm());
			dialogStage.setScene(scene);
			addController = loader.getController();
			addController.setDialogStage(dialogStage);
			addController.setQueService(queService);
			// Show the dialog and wait until the user closes it
			dialogStage.showAndWait();
			return addController.isOkClicked();
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	boolean showQuestionModifyDialog(Question modifiedQuestion) {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("/View/QuestionModifyDialog.fxml"));
			AnchorPane page = (AnchorPane) loader.load();
			Stage dialogStage = new Stage();
			dialogStage.setTitle("����");
			dialogStage.initOwner(employeeStage);
			dialogStage.initModality(Modality.WINDOW_MODAL);  //��������Ժ���벻�ܵ�ԭ����stage
			dialogStage.setWidth(350.0);
			dialogStage.setHeight(400.0);
			dialogStage.setResizable(false);
			Scene scene = new Scene(page);
			dialogStage.setScene(scene);
			scene.getStylesheets().add(getClass().getResource("/View/Dialog.css").toExternalForm());
			modifyController = loader.getController();
			modifyController.setDialogStage(dialogStage);
			modifyController.setModifiedQuestion(modifiedQuestion);
			modifyController.setQueService(queService);
			// Show the dialog and wait until the user closes it
			dialogStage.showAndWait();
			return modifyController.isOkClicked();
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	
	void deleteQuestionInMoudel(Question q) {
		if(mouService==null) {
		mouService=MoudelService.getMoudelService();}
		mouService.DeleteQuestion(q);
		
	}
	
	void modifyQuestionInMoudel(Question q) {
		if(mouService==null) {
		mouService=MoudelService.getMoudelService();}
		mouService.modifyQuestion(q);
	}
	/**
	 * �л�tabʱ���¼���
	 */
	  public void initAndReflush(){
		    queService=new QuestionService();
			queService=new QuestionService();
			questionData=queService.getQuestionDao().getQuestionData();
			questionList=questionData;
			reflushQuestionTableView(questionList);
			
	   }
	
	
	
}
