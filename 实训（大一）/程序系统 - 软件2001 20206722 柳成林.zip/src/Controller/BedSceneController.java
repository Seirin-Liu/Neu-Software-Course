package Controller;

import Entity.Bed;
//import Service.BedService;
import Service.BuildingService;
import Util.AlertUtils;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.util.Callback;


/**
 * ��λ�������棬��ʾ���д�λ��������ס��δ��ס��
 * @author Seirin
 *
 */
public class BedSceneController {

	private ObservableList<Bed> bedData;
	private ObservableList<Bed> bedList;

	private Stage stage;
	//private BedService bedService;
	private BuildingService buildingService;
	
	private boolean isChanaged;
	

	public boolean isChanaged() {
		return isChanaged;
	}

	public void setChanaged(boolean isChanaged) {
		this.isChanaged = isChanaged;
	}

	public Stage getStage() {
		return stage;
	}

	public void setStage(Stage stage) {
		this.stage = stage;
	}

	@FXML
	private Button deletButton;

	@FXML
	private Button searchButton;

	@FXML
	private TableColumn<Bed, String> startTimeColumn;

	@FXML
	private TextField searchField;

	@FXML
	private TableColumn<Bed, String> nameColumn;

	@FXML
	private TableColumn<Bed, String> statusColumn;

	@FXML
	private TableColumn<Bed, String> sexColumn;

	@FXML
	private TableColumn<Bed, String> recordIdColumn;

	@FXML
	private TableColumn<Bed, String> birthdayColumn;

	@FXML
	private TableView<Bed> bedTableView;

	@FXML
	private TableColumn<Bed, String> bedNameColumn;

	@FXML
	private TableColumn<Bed, String> endTimeColumn;
	@FXML
	private ComboBox<String> comboBox;


	
	@FXML
	void deleteEvent(ActionEvent event) {
		Bed b=bedTableView.getSelectionModel().getSelectedItem();
		if(b==null) {
			AlertUtils.newErrorAlert("error��δѡ��", "��ѡ����Ժ��λ", stage);
			return;
		}
		if(b.getPatientName()==null) {
			AlertUtils.newErrorAlert("error��δ��ס", "�ò���û�в���", stage);
			return;
		}
		String patientName= b.getPatientName();
		bedList.remove(b);
		bedData.remove(b);
		buildingService.clearBed(b.getName()); //����Ҳ�������ļ�
		//bedService.saveBedData(bedData);
		AlertUtils.newRmindAlert(patientName+"��Ժ�ɹ�", "��Ժ�ɹ�", stage);
		if(isChanaged==false) {
		isChanaged=true;}
	}

	@FXML
	void searchEvent(ActionEvent event) {
		
		if (searchField.getText() == null || searchField.getText().length() == 0) {
			reflushBedTableView(bedData);
			return;
		}
		bedList = buildingService.searchBeds(searchField.getText());
		if (bedList.size() == 0) {
			AlertUtils.newErrorAlert("�����Ÿı������ؼ���", "���Ҳ�����Ϣ", stage);
			return;
		}
		reflushBedTableView(bedList);
		
	}

	/**
	 * ��ʼ������
	 */
	@FXML
	void initialize() {
		//bedService = BedService.getBedService();
		
		buildingService=BuildingService.getBuildingService();   //ͨ��Service��ȡ�ļ�����
		bedData = buildingService.getPatientBeds();
		bedList = bedData;
		
		//��ʼ��comboBox�����Ӽ���
		ObservableList<String> options = FXCollections.observableArrayList("ȫ����λ", "��ס��", "δ��ס");
		comboBox.setItems(options);
		comboBox.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
			@Override
			public void changed(ObservableValue<? extends String> arg0, String arg1, String newValue) {
				// TODO Auto-generated method stub
				if (newValue.equals("ȫ����λ")) {
					bedList=buildingService.getAllBeds();
				    reflushBedTableView(bedList);
				}
				if (newValue.equals("��ס��")) {
					bedList=buildingService.getPatientBeds();
					reflushBedTableView(bedList);
				}
				if (newValue.equals("δ��ס")) {
					bedList=buildingService.getFreeBeds();
					reflushBedTableView(bedList);
				}
			}
		});
		
		reflushBedTableView(bedList);
		
	}

	/**
	 * ���غ�ˢ��
	 * @param bedList
	 */
	public void reflushBedTableView(ObservableList<Bed> bedList) {
		bedTableView.setItems(bedList);
		nameColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Bed, String>, ObservableValue<String>>() {

					@Override
					public ObservableValue<String> call(CellDataFeatures<Bed, String> arg0) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty(arg0.getValue().getPatientName());
						return name;
					}
				});
		sexColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Bed, String>, ObservableValue<String>>() {

					@Override
					public ObservableValue<String> call(CellDataFeatures<Bed, String> arg0) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty(arg0.getValue().getPatientSex());
						return name;
					}
				});
	birthdayColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Bed, String>, ObservableValue<String>>() {

					@Override
					public ObservableValue<String> call(CellDataFeatures<Bed, String> arg0) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty(arg0.getValue().getPatientAge());
						return name;
					}
				});
		startTimeColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Bed, String>, ObservableValue<String>>() {

					@Override
					public ObservableValue<String> call(CellDataFeatures<Bed, String> arg0) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty(arg0.getValue().getStartTime());
						return name;
					}
				});
		endTimeColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Bed, String>, ObservableValue<String>>() {

					@Override
					public ObservableValue<String> call(CellDataFeatures<Bed, String> arg0) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty(arg0.getValue().getEndTime());
						return name;
					}
				});
		recordIdColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Bed, String>, ObservableValue<String>>() {

					@Override
					public ObservableValue<String> call(CellDataFeatures<Bed, String> arg0) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty(arg0.getValue().getRecordId());
						return name;
					}
				});
		statusColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Bed, String>, ObservableValue<String>>() {

					@Override
					public ObservableValue<String> call(CellDataFeatures<Bed, String> arg0) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty(arg0.getValue().getStatus());
						return name;
					}
				});
		bedNameColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Bed, String>, ObservableValue<String>>() {

					@Override
					public ObservableValue<String> call(CellDataFeatures<Bed, String> arg0) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty(arg0.getValue().getName());
						return name;
					}
				});

	}
}
