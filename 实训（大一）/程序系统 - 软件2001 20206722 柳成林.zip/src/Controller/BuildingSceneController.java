package Controller;

import java.io.IOException;
import java.util.List;

import Entity.Bed;
import Entity.Building;
import Entity.Floor;
import Entity.RareRoom;
import Entity.Room;
import Service.BuildingService;
import Service.RareRoomService;
import Util.AlertUtils;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class BuildingSceneController  implements TabReLoadInterface{

	private Stage employeeStage;
	private BuildingService buildingService;
	private RareRoomService rarService;
	private List<Building> buildingData;

	private Building building;  //��ǰѡ���¥��
	private Floor floor;//��ǰѡ���¥��
	private Room room;//����
	// private RareRoom rareRoom;
	private Bed bed;

	final static int newBuilding = 1;    //��ͬ��״̬
	final static int newFloor = 2;
	final static int newRoom = 3;
	final static int newBed = 4;
	final static int newRareRoom = 5;

	final static int deleteBuilding = 6;
	final static int deleteFloor = 7;
	final static int deleteRoom = 8;
	final static int deleteBed = 9;     //���жϵ�ǰҪ���е���ʲô��������ִ����Ӧ�ķ���

	static int status = 0;

	public Stage getEmployeeStage() {
		return employeeStage;
	}

	public void setEmployeeStage(Stage employeeStage) {
		this.employeeStage = employeeStage;
	}

	@FXML
	private ComboBox<String> buildingComboBox;
	@FXML
	private ComboBox<String> bedComboBox;
	@FXML
	private RadioButton rareButton;
	@FXML
	private TextField maxContent;
	@FXML
	private TreeView<String> treeView;
	@FXML
	private ComboBox<String> roomComboBox;
	@FXML
	private ComboBox<String> floorComboBox;
	@FXML
	private ComboBox<String> rareTypeComboBox;
	@FXML
	private Button bedSceneButton;
	@FXML
	private Button rareRoomSceneButton;
	@FXML
	private TextField nameTextField;
	@FXML
	private Button addButton;
	@FXML
	private Button deleteButton;
	@FXML
	private Button clearButton;
	@FXML
	private Label label;
	@FXML
	private TextField textField;
	
	@FXML
	void addEvent(ActionEvent event) {    //�½� �жϲ�ͬ��״̬��ִ�в�ͬ�ķ���
		status = getNewStatus();  //�½�ʱ����״̬
		if (status == newBuilding) {
			addNewBuilding();
			reloadBuildingData();
			loadTree();
			return;
		}
		if (status == newFloor) {
			addNewFloor();
			reloadBuildingData();
			loadTree();
			return;
		}
		if (status == newRoom) {  //��������ʱ���������
			if (rareButton.isSelected() == false) {
				addNewRoom();
				reloadBuildingData();
				loadTree();
				return;
			}
			if (rareButton.isSelected() == true) {
				status = newRareRoom;
				addNewRareRoom();
				reloadBuildingData();
				loadTree();
				return;
			}
		}
		if (status == newBed) {
			addNewBed();
			reloadBuildingData();
			loadTree();
			return;
		} else {
			return;
		}
	}

	/**
	 * �������������
	 * @param event
	 */
	@FXML
	void clearEvent(ActionEvent event) {  
		roomComboBox.setValue(null);
		floorComboBox.setValue(null);
		buildingComboBox.setValue(null);
		building = null;
		textField.setText("");
		nameTextField.setText("");

	}

	/**
	 * ɾ�������жϲ�ͬ��ɾ��״̬����ִ�в�ͬ��ɾ������
	 */
	@FXML
	void deleteEvent() {
		status = getDeleteStatus();
		if (status == deleteBuilding) {
			deleteBuilding();
			reloadBuildingData();
			loadTree();
			return;
		}
		if (status == deleteFloor) {
			deleteFloor();
			reloadBuildingData();
			loadTree();
			return;
		}
		if (status == deleteRoom) {
			deleteRoom();
			reloadBuildingData();
			loadTree();
			return;
		}
		if (status == deleteBed) {
			deleteBed();
			reloadBuildingData();
			loadTree();
		} else {
			return;
		}
	}
	
	
	@FXML
	private void initialize() {
		buildingService = BuildingService.getBuildingService();
		buildingData = buildingService.getBuildingDao().getBuildingData();
		loadTree();    //��ȡ¥�����ݣ�����¥���б�
		
		ObservableList<String> options = FXCollections.observableArrayList("������", "ԡ��", "������");
		
		maxContent.setEditable(false); // ��û��ѡ��ϡ�з���֮ǰ������������ѡ��
		rareTypeComboBox.setEditable(false);
		
		textField.setEditable(false);
		
		buildingComboBox.setItems(buildingService.getBuildingNames());  //�Ȱ�¥������Ƽ��ص���������

		//���ü�����ÿ����һ����ֵ�ı䣬���������һ����Ȼ��ͨ����һ����ֵ������һ��������������
		buildingComboBox.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
			@Override
			public void changed(ObservableValue<? extends String> observable, String oldValue, String buildingName) {
				// TODO Auto-generated method stub
				floorComboBox.setValue(null); // ÿ�θ���buildingNameʱ���¥���¥�������
				floorComboBox.setItems(null);
				floor = null;
				rareButton.setSelected(false);
				if (buildingName != null) {
					textField.setText(buildingName + "-");
					building = buildingService.getBuilding(buildingName);
					floorComboBox.setItems(buildingService.getFloorNames(building));
				}
			}
		});		
		floorComboBox.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
			@Override
			public void changed(ObservableValue<? extends String> observable, String oldValue, String floorName) {
				// TODO Auto-generated method stub
				roomComboBox.setValue(null);
				roomComboBox.setItems(null);
				room = null;
				if (floorName != null) {
					textField.setText(floorName + "-");
					floor = buildingService.getFloor(building, floorName);
					roomComboBox.setItems(buildingService.getRoomNames(floor));
				}

			}
		});
		roomComboBox.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
			@Override
			public void changed(ObservableValue<? extends String> arg0, String oldValue, String roomName) {
				// TODO Auto-generated method stub
				bedComboBox.setValue(null);
				bedComboBox.setItems(null);
				bed = null;
				if (roomName != null) {
					textField.setText(roomName + "-");
					room =buildingService.getRoom(floor, roomName);
					bedComboBox.setItems(buildingService.getBedNames(room));
				}
			}
		});
		bedComboBox.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
			@Override
			public void changed(ObservableValue<? extends String> arg0, String oldValue, String bedName) {
				// TODO Auto-generated method stub
				if (bedName != null) {
					bed = buildingService.getBed(room, bedName);
				}
			}
		});
		
		/*
		 * ��ϡ�з��䰴ť���ü�����������У�
		 * ���жϵ�ǰ�������ǲ��Ƿ��䣬������ǣ��ͷ���
		 *                          ����ǣ�����ϡ�����ԣ�����������ȿ��Ա༭
		 */
		rareButton.selectedProperty().addListener(new ChangeListener<Boolean>() {
			@Override
			public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
				// TODO Auto-generated method stub
				if (newValue) {
					if (getNewStatus() != newRoom) {
						AlertUtils.newErrorAlert("��ǰ�����Ĳ��Ƿ���", "�޷�ѡ��ϡ�з���", employeeStage);
						rareButton.setSelected(false);
						return;
					}
					maxContent.setEditable(true);
					rareTypeComboBox.setEditable(true);
					rareTypeComboBox.setItems(options);
					roomComboBox.setEditable(false);
				} else {
					maxContent.setEditable(false); // ��û��ѡ��ϡ�з���֮ǰ������������ѡ��
					rareTypeComboBox.setEditable(false);
					rareTypeComboBox.setItems(null);
					roomComboBox.setEditable(true);
				}
			}
		});
		/*
		 * ��treeView���м���
		 */
		treeView.setOnMouseClicked(new EventHandler<MouseEvent>()
		{
		    @Override
		    public void handle(MouseEvent mouseEvent)
		    {
		        if(mouseEvent.getClickCount() == 1)
		        {
		            TreeItem<String> item = treeView.getSelectionModel().getSelectedItem();  //��ȡ�������
		            bedComboBox.setValue(null);    //�Ȱѳ���¥��֮��Ŀ���Ϊ��
		            roomComboBox.setValue(null);
		            floorComboBox.setValue(null);
		            
		            if(item!=null) {
		            setTreeSelect(item.getValue());   //ͨ����������ѡ��Ķ���
		            } 
		        }
		    }
		});

	}

	@FXML
	void bedSceneEvent(ActionEvent event) {
		BedSceneController bedController;
		try {
			// Load the fxml file and create a new stage for the popup dialog.
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("/View/BedScene.fxml"));
			AnchorPane page = (AnchorPane) loader.load();
			// Create the dialog Stage.
			Stage dialogStage = new Stage();
			dialogStage.setTitle("��λ����");
			dialogStage.initOwner(employeeStage);
			dialogStage.setWidth(800.0);
			dialogStage.setHeight(360.0);
			dialogStage.setResizable(false);
			//dialogStage.initModality(Modality.WINDOW_MODAL);
			Scene scene = new Scene(page);
			scene.getStylesheets().add(getClass().getResource("/View/Dialog2.css").toExternalForm());
			dialogStage.setScene(scene);
			bedController = loader.getController();
			bedController.setStage(dialogStage);
			// Show the dialog and wait until the user closes it
			dialogStage.showAndWait();
			
			if(bedController.isChanaged()) {   //����������˴�����
				reloadBuildingData();
				loadTree();
			}
		} catch (IOException e) {
			e.printStackTrace();
		
			
		}
	}

	@FXML
	void rareRoomSceneEvent(ActionEvent event) {

		RareRoomSceneController rarController;
		try {
			// Load the fxml file and create a new stage for the popup dialog.
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("/View/RareRoomScene.fxml"));
			AnchorPane page = (AnchorPane) loader.load();
			// Create the dialog Stage.
			Stage dialogStage = new Stage();
			dialogStage.setTitle("ϡ���豸����");
			dialogStage.initOwner(employeeStage);
			dialogStage.setWidth(400.0);
			dialogStage.setHeight(357.0);
			dialogStage.setResizable(false);
			//dialogStage.initModality(Modality.WINDOW_MODAL);
			Scene scene = new Scene(page);
			scene.getStylesheets().add(getClass().getResource("/View/Dialog2.css").toExternalForm());
			dialogStage.setScene(scene);
			rarController = loader.getController();
			rarController.setDialogStage(dialogStage);
			// Show the dialog and wait until the user closes it
			dialogStage.show();
			

		} catch (IOException e) {
			e.printStackTrace();
		
			
		}
		
	}

	/**
	 * �½�ʱ����״̬
	 * @return
	 */
	public int getNewStatus() {

		if ((buildingComboBox.getValue() == null || buildingComboBox.getValue().length() == 0)) {
			return newBuilding;
		}
		if ((buildingComboBox.getValue() != null || buildingComboBox.getValue().length() != 0)
				&& (floorComboBox.getValue() == null || floorComboBox.getValue().length() == 0)) {
			return newFloor;
		}
		if ((buildingComboBox.getValue() != null || buildingComboBox.getValue().length() != 0)
				&& (floorComboBox.getValue() != null || floorComboBox.getValue().length() != 0)
				&& (roomComboBox.getValue() == null || roomComboBox.getValue().length() == 0)) {
			return newRoom;
		}
		if ((buildingComboBox.getValue() != null || buildingComboBox.getValue().length() != 0)
				&& (floorComboBox.getValue() != null || floorComboBox.getValue().length() != 0)
				&& (roomComboBox.getValue() != null || roomComboBox.getValue().length() != 0)
				&& (bedComboBox.getValue() == null || bedComboBox.getValue().length() == 0)) {
			return newBed;
		}

		else {
			return 0;
		}

	}

	/**
	 * ɾ��ʱ����״̬
	 * @return
	 */
	public int getDeleteStatus() {

		if ((buildingComboBox.getValue() != null || buildingComboBox.getValue().length() != 0)
				&& (floorComboBox.getValue() == null || floorComboBox.getValue().length() == 0)) {
			return deleteBuilding;
		}
		if ((buildingComboBox.getValue() != null || buildingComboBox.getValue().length() != 0)
				&& (floorComboBox.getValue() != null || floorComboBox.getValue().length() != 0)
				&& (roomComboBox.getValue() == null || roomComboBox.getValue().length() == 0)) {
			return deleteFloor;
		}
		if ((buildingComboBox.getValue() != null || buildingComboBox.getValue().length() != 0)
				&& (floorComboBox.getValue() != null || floorComboBox.getValue().length() != 0)
				&& (roomComboBox.getValue() != null || roomComboBox.getValue().length() != 0)
				&& (bedComboBox.getValue() == null || bedComboBox.getValue().length() == 0)) {
			return deleteRoom;
		}
		if ((buildingComboBox.getValue() != null || buildingComboBox.getValue().length() != 0)
				&& (floorComboBox.getValue() != null || floorComboBox.getValue().length() != 0)
				&& (roomComboBox.getValue() != null || roomComboBox.getValue().length() != 0)
				&& (bedComboBox.getValue() != null || bedComboBox.getValue().length() != 0)) {
			return deleteBed;
		}

		else {
			return 0;
		}

	}


	/**
	 * �½�¥��
	 */
	public void addNewBuilding() {
		if (isInputValid()) {
			Building newBuilding = new Building(textField.getText() + nameTextField.getText());
			buildingData.add(newBuilding);
			buildingService.saveBuildingData(buildingData);
			AlertUtils.newRmindAlert("�½�¥�" + newBuilding.getName(), "�½��ɹ�", employeeStage);
		}

	}

	public void addNewFloor() {
		if (isInputValid()) {
			Floor newFloor = new Floor(textField.getText() + nameTextField.getText());
			int index = buildingData.indexOf(building);
			building.getFloors().add(newFloor);
			buildingData.set(index, building);
			buildingService.saveBuildingData(buildingData);
			AlertUtils.newRmindAlert("�½�¥�㣻" + newFloor.getName(), "�½��ɹ�", employeeStage);

		}
	}

	public void addNewRoom() {
		if (isInputValid()) {
			Room newRoom = new Room(textField.getText() + nameTextField.getText());
			int buildingIndex = buildingData.indexOf(building);
			int floorIndex = building.getFloors().indexOf(floor);
			floor.getRooms().add(newRoom);
			building.getFloors().set(floorIndex, floor);
			buildingData.set(buildingIndex, building);
			buildingService.saveBuildingData(buildingData);
			AlertUtils.newRmindAlert("�½���ͨ���䣻" + newRoom.getName(), "�½��ɹ�", employeeStage);

		}
	}

	public void addNewBed() {
		
		if (isInputValid()) {
			Bed newBed = new Bed(textField.getText() + nameTextField.getText());
			
			int roomIndex = floor.getRooms().indexOf(room);
			int floorIndex = building.getFloors().indexOf(floor);
			int buildingIndex = buildingData.indexOf(building);
			room.getBeds().add(newBed);
			floor.getRooms().set(roomIndex, room);
			building.getFloors().set(floorIndex, floor);
			buildingData.set(buildingIndex, building);
			buildingService.saveBuildingData(buildingData);
			AlertUtils.newRmindAlert("�½���λ��" + newBed.getName(), "�½��ɹ�", employeeStage);

		}
	}

	public void addNewRareRoom() {
		if(rarService==null) {
			rarService=RareRoomService.getRareRooomService();
		}
		if (isInputValid()) {
			RareRoom newRareRoom = new RareRoom(textField.getText() + nameTextField.getText(),
					rareTypeComboBox.getValue(), Integer.parseInt(maxContent.getText()));
			int buildingIndex = buildingData.indexOf(building);
			int floorIndex = building.getFloors().indexOf(floor);
			floor.getRooms().add(newRareRoom);
			building.getFloors().set(floorIndex, floor);
			buildingData.set(buildingIndex, building);
			buildingService.saveBuildingData(buildingData);
			
			rarService.addNewRareRoom(newRareRoom);
			
			AlertUtils.newRmindAlert("�½�ϡ�з��䣻" + newRareRoom.getName(), "�½��ɹ�", employeeStage);
			maxContent.clear();
			rareTypeComboBox.setItems(null);
		}
	}

	public void deleteBuilding() {
		if (building.getFloors().size() != 0) {
			AlertUtils.newErrorAlert("�����ӽڵ�", "ɾ��ʧ��", employeeStage);
			return;
		} else {
			buildingData.remove(building);
			buildingService.saveBuildingData(buildingData);
			AlertUtils.newRmindAlert("ɾ���ɹ�", "ɾ���ɹ�", employeeStage);
		}
	}

	public void deleteFloor() {
		if (floor.getRooms().size() != 0) {
			AlertUtils.newErrorAlert("�����ӽڵ�", "ɾ��ʧ��", employeeStage);
			return;
		} else {
			int index = buildingData.indexOf(building);
			building.getFloors().remove(floor);
			buildingData.set(index, building);
			buildingService.saveBuildingData(buildingData);
			AlertUtils.newRmindAlert("ɾ���ɹ�", "ɾ���ɹ�", employeeStage);
		}
	}

	public void deleteRoom() {
		if(rarService==null) {
			rarService=RareRoomService.getRareRooomService();
		}
		if (room.isRare() == true) {  //ϡ�з���ֱ��ɾ���������ж��ֽڵ�
			int buildingIndex = buildingData.indexOf(building);
			int floorIndex = building.getFloors().indexOf(floor);
			floor.getRooms().remove(room);
			building.getFloors().set(floorIndex, floor);
			buildingData.set(buildingIndex, building);
			buildingService.saveBuildingData(buildingData);
			
			rarService.deleteRareRoom(room.getName());
			
			AlertUtils.newRmindAlert("ɾ���ɹ�", "ɾ���ɹ�", employeeStage);
			return;
		}
		if (room.getBeds().size() != 0) {
			AlertUtils.newErrorAlert("�����ӽڵ�", "ɾ��ʧ��", employeeStage);
			return;
		} else {
			int buildingIndex = buildingData.indexOf(building);
			int floorIndex = building.getFloors().indexOf(floor);
			floor.getRooms().remove(room);
			building.getFloors().set(floorIndex, floor);
			buildingData.set(buildingIndex, building);
			buildingService.saveBuildingData(buildingData);
			AlertUtils.newRmindAlert("ɾ���ɹ�", "ɾ���ɹ�", employeeStage);
			return;
		}
	}

	public void deleteBed() {
		int roomIndex = floor.getRooms().indexOf(room);
		int floorIndex = building.getFloors().indexOf(floor);
		int buildingIndex = buildingData.indexOf(building);
		room.getBeds().remove(bed);
		floor.getRooms().set(roomIndex, room);
		building.getFloors().set(floorIndex, floor);
		buildingData.set(buildingIndex, building);
		buildingService.saveBuildingData(buildingData);
		AlertUtils.newRmindAlert("ɾ���ɹ�", "ɾ���ɹ�", employeeStage);
	}

	/**
	 * ����ʱ�ж������Ƿ���Ч
	 * @return
	 */
	public boolean isInputValid() {
		String errorMessage = "";

		if (status == newBuilding) {
			if (nameTextField.getText() == null || nameTextField.getText().length() == 0) {
				errorMessage += "¥��Ϊ��\n";
			}
			if (buildingService.getBuildingNames().contains(textField.getText() + nameTextField.getText())) {
				errorMessage += "��¥���Ѵ���\n";
			}
			if (errorMessage.length() == 0) {
				return true;
			} else {
				AlertUtils.newErrorAlert(errorMessage, "�½�¥��ʧ��", employeeStage);
				return false;
			}
		}

		if (status == newFloor) {
			if (nameTextField.getText() == null || nameTextField.getText().length() == 0) {
				errorMessage += "¥��Ϊ��\n";
			}
			if (buildingService.getFloorNames(building).contains(textField.getText() + nameTextField.getText())) {
				errorMessage += "��¥���Ѵ���\n";
			}
			if (errorMessage.length() == 0) {
				return true;
			} else {
				AlertUtils.newErrorAlert(errorMessage, "�½�¥��ʧ��", employeeStage);
				return false;
			}
		}
		if (status == newRoom) {
			if (nameTextField.getText() == null || nameTextField.getText().length() == 0) {
				errorMessage += "�����Ϊ��\n";
			}
			if (buildingService.getRoomNames(floor).contains(textField.getText() + nameTextField.getText())) {
				errorMessage += "�÷����Ѵ���\n";
			}
			if (errorMessage.length() == 0) {
				return true;
			} else {
				AlertUtils.newErrorAlert(errorMessage, "�½�����ʧ��", employeeStage);
				return false;
			}
		}
		if (status == newRareRoom) {
			if (nameTextField.getText() == null || nameTextField.getText().length() == 0) {
				errorMessage += "ϡ�з�������Ϊ��\n";
			}
			if (buildingService.getRoomNames(floor).contains(textField.getText() + nameTextField.getText())) {
				errorMessage += "�÷����Ѵ���\n";
			}
			if (maxContent.getText() == null || maxContent.getText().length() == 0) {
				errorMessage += "�������Ϊ��\n";
			}
			if (rareTypeComboBox.getValue() == null || rareTypeComboBox.getValue().length() == 0) {
				errorMessage += "ϡ������Ϊ��\n";
			}
			if (errorMessage.length() == 0) {
				return true;
			} else {
				AlertUtils.newErrorAlert(errorMessage, "�½�ϡ�з���ʧ��", employeeStage);
				return false;
			}
		}
		if (status == newBed) {
			if (room.isRare() == true) {
				errorMessage += "�÷�����ϡ�з��䣬�������Ӵ�λ\n";
				AlertUtils.newErrorAlert(errorMessage, "�½���λʧ��", employeeStage);
				return false;
			}
			if (nameTextField.getText() == null || nameTextField.getText().length() == 0) {
				errorMessage += "��λ��Ϊ��\n";
			}

			if (buildingService.getBedNames(room) != null
					&& buildingService.getBedNames(room).contains(textField.getText() + nameTextField.getText())) {
				errorMessage += "�ô�λ���Ѵ���\n";
			}
			if (errorMessage.length() == 0) {
				return true;
			} else {
				AlertUtils.newErrorAlert(errorMessage, "�½���λʧ��", employeeStage);
				return false;
			}
		}
		return false;
	}

	/**
	 * ÿ�����ӻ���ɾ�����������¼�������
	 */
	public void reloadBuildingData() {
		
		buildingData = buildingService.getBuildingDao().getBuildingData();
		buildingComboBox.setItems(buildingService.getBuildingNames());
		nameTextField.setText(null);
		
	}

	/**
	 * ����������б�
	 */
	public void loadTree() {
		 Image depIcon = new Image("file:pictures\\¥���Զ���.png");
		 ImageView img=new ImageView(depIcon);
		 img.setFitHeight(20.0);
		 img.setFitWidth(20.0);
		 TreeItem<String> hosItem = new TreeItem<String>("ҽԺ",img);
			hosItem.setExpanded(true);
			for (Building b : buildingData) {
				TreeItem<String> buildingItem = new TreeItem<String>(b.getName());
				buildingItem.setExpanded(true);
				for (Floor f : b.getFloors()) {
					TreeItem<String> floorItem = new TreeItem<String>(f.getName());
					floorItem.setExpanded(true);
					for (Room r : f.getRooms()) {
						TreeItem<String> roomItem = new TreeItem<String>(r.getName());
						roomItem.setExpanded(true);
						if (r.isRare() == true) {
							floorItem.getChildren().add(roomItem);
							continue;
						}
						for (Bed bed : r.getBeds()) {
							if(bed.getStatus().equals("δ��ס")) {
							TreeItem<String> bedItem = new TreeItem<String>(bed.getName());
							bedItem.setExpanded(true);
							roomItem.getChildren().add(bedItem);
							}
							if(bed.getStatus().equals("��ס��")) {
								TreeItem<String> bedItem = new TreeItem<String>(bed.getName()+"-(F)");
								bedItem.setExpanded(true);
								roomItem.getChildren().add(bedItem);
							}
						}
						floorItem.getChildren().add(roomItem);
					}
					buildingItem.getChildren().add(floorItem);
				}
				hosItem.getChildren().add(buildingItem);
			}
			treeView.setRoot(hosItem);
		}
	
	/**
	 * �����л�ȡѡ���ֵ,����������
	 * @param value
	 */
	public void setTreeSelect(String value) {
		String[] name=value.split("-");
		if(value.equals("ҽԺ")) {
			return;
		}
		if(name.length==1) {
			buildingComboBox.setValue(name[0]);
		}
		if(name.length==2) {
			buildingComboBox.setValue(name[0]);		
			floorComboBox.setValue(value);
		}
		if(name.length==3) {
			buildingComboBox.setValue(name[0]);
			floorComboBox.setValue(name[0]+"-"+name[1]);
			roomComboBox.setValue(value);
		}
		if(name.length>=4) {
			buildingComboBox.setValue(name[0]);
			floorComboBox.setValue(name[0]+"-"+name[1]);
			roomComboBox.setValue(name[0]+"-"+name[1]+"-"+name[2]);
			bedComboBox.setValue(name[0]+"-"+name[1]+"-"+name[2]+"-"+name[3]);
			
		}
		
	}

	@Override
	public void initAndReflush() {
		// TODO Auto-generated method stub
		buildingData = buildingService.getBuildingDao().getBuildingData();
		loadTree();    //��ȡ¥�����ݣ�����¥���б�
	}
}
