package Controller;

import Entity.Assess;
import Service.AssessService;
import Util.AlertUtils;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.util.Callback;

public class AssessSceneController implements TabReLoadInterface{

	private ObservableList<Assess> assessData;   //��������
	private ObservableList<Assess> assessList;   //����ʱ����
	private AssessService assessService; 
	
	private Stage employeeStage;//Ա��Stage
	
    public Stage getEmployeeStage() {
		return employeeStage;
	}
	public void setEmployeeStage(Stage employeeStage) {
		this.employeeStage = employeeStage;
	}
	@FXML
    private TableColumn<Assess,String> adviceColumn;

    @FXML
    private TableColumn<Assess,String> timeColumn;

    @FXML
    private Button searchButton;

    @FXML
    private TableColumn<Assess,String> moudelTypeColumn;

    @FXML
    private TableColumn<Assess,String> modelNameColumn1;

    @FXML
    private TextField searchField;

    @FXML
    private TableColumn<Assess,String> nameColumn;

    @FXML
    private TableView<Assess> assessTableView;

    @FXML
    private TableColumn<Assess,String> checkColumn;

    @FXML
    private TableColumn<Assess,String> sexColumn;

    @FXML
    private TableColumn<Assess,String> employeeNameColumn;

    @FXML
    void searchEvent(ActionEvent event) {

    	if (searchField.getText() == null || searchField.getText().length() == 0) {
    		reflushAssessTableView(assessData);
    		return;    	
    		}
 	        assessList=assessService.getAssessBySearch(searchField.getText());
 	        if(assessList==null) {
 	        	AlertUtils.newErrorAlert("�����Ÿı������ؼ���", "���Ҳ�������", employeeStage);
 				return;
 	        }
 	        reflushAssessTableView(assessList);
    }
    
    
    /**
     * ��ʼ��
     */
    @FXML
    private void initialize() {
    	assessService=AssessService.getAssessService();
    	assessData=assessService.getAssessDao().getAssessData();
    	assessList=assessData;
    	reflushAssessTableView(assessList);
    	
    }
    
    /**
     * ˢ�ºͼ���table�ķ���
     * @param assessList
     */
    public void reflushAssessTableView(ObservableList<Assess> assessList) {
    	assessTableView.setItems(assessList);
    	nameColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Assess,String>, ObservableValue<String>>() {

			@Override
			public ObservableValue<String> call(CellDataFeatures<Assess, String> arg0) {
				// TODO Auto-generated method stub
				return new SimpleStringProperty(arg0.getValue().getName());
			}
		});
    	sexColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Assess,String>, ObservableValue<String>>() {

			@Override
			public ObservableValue<String> call(CellDataFeatures<Assess, String> arg0) {
				// TODO Auto-generated method stub
				return new SimpleStringProperty(arg0.getValue().getSex());
			}
		});
    	moudelTypeColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Assess,String>, ObservableValue<String>>() {

			@Override
			public ObservableValue<String> call(CellDataFeatures<Assess, String> arg0) {
				// TODO Auto-generated method stub
				return new SimpleStringProperty(arg0.getValue().getMoudelType());
			}
		});
    	modelNameColumn1.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Assess,String>, ObservableValue<String>>() {

			@Override
			public ObservableValue<String> call(CellDataFeatures<Assess, String> arg0) {
				// TODO Auto-generated method stub
				return new SimpleStringProperty(arg0.getValue().getMoudelName());
			}
		});
    	employeeNameColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Assess,String>, ObservableValue<String>>() {

			@Override
			public ObservableValue<String> call(CellDataFeatures<Assess, String> arg0) {
				// TODO Auto-generated method stub
				return new SimpleStringProperty(arg0.getValue().getEmployeeName());
			}
		});
    	timeColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Assess,String>, ObservableValue<String>>() {
			@Override
			public ObservableValue<String> call(CellDataFeatures<Assess, String> arg0) {
				// TODO Auto-generated method stub
				return new SimpleStringProperty(arg0.getValue().getTime());
			}
		});
    	adviceColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Assess,String>, ObservableValue<String>>() {
			@Override
			public ObservableValue<String> call(CellDataFeatures<Assess, String> arg0) {
				// TODO Auto-generated method stub
				return new SimpleStringProperty(arg0.getValue().getAdvice());
			}
		});  	
    }
    
    /**
     * �л�tabʱ���¼���
     */
    public void initAndReflush(){
    	assessService=AssessService.getAssessService();
    	assessData=assessService.getAssessDao().getAssessData();
    	assessList=assessData;
    	reflushAssessTableView(assessList);
	   
   }

    
}
