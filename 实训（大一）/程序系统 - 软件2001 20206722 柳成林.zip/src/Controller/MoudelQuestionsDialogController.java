package Controller;


import Entity.Moudel;
import Entity.Question;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.stage.Stage;
import javafx.util.Callback;

/**
 * ��ʾ���ģ�����������
 * @author Seirin
 *
 */
public class MoudelQuestionsDialogController {


	private Stage dialogStage;
	
	private ObservableList<Question> questionList;  //�����б�
	
    public ObservableList<Question> getQuestionList() {
		return questionList;
	}

	public void setQuestionList(ObservableList<Question> questionList) {
		this.questionList = questionList;
	}

	
    public Stage getDialogStage() {
		return dialogStage;
	}

	public void setDialogStage(Stage dialogStage) {
		this.dialogStage = dialogStage;
	}


	@FXML
    private TableColumn<Question, String> typeColumn;

    @FXML
    private TableView<Question> questionTableView;

    @FXML
    private TableColumn<Question, String> choose1Column;


    @FXML
    private TableColumn<Question, CheckBox> checkBoxColumn;

    @FXML
    private TableColumn<Question, String> choose2Column;

    @FXML
    private TableColumn<Question, String> contentColumn;

  
    @FXML
    private TableColumn<Question, String> choose3Column;

    @FXML
    private TableColumn<Question, String> idColumn;

    @FXML
    private Button okButton;
    
    @FXML
    private Label label;
    
    @FXML
    void okEvent(ActionEvent event) {

    	dialogStage.close();
    	
    }

	@FXML
	void initialize() {
		
	}
    
    public void reflushQuestionTableView(ObservableList<Question> questionData) {
    	
    	questionTableView.setItems(questionData);
    	
    	idColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Question, String>, ObservableValue<String>>() {
					@Override
					public ObservableValue<String> call(CellDataFeatures<Question, String> param) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty(""+param.getValue().getId());
						return name;
					}
				});
    	typeColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Question, String>, ObservableValue<String>>() {
					@Override
					public ObservableValue<String> call(CellDataFeatures<Question, String> param) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty(param.getValue().getType());
						return name;
					}
				});
    	contentColumn.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Question, String>, ObservableValue<String>>() {
					@Override
					public ObservableValue<String> call(CellDataFeatures<Question, String> param) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty(param.getValue().getContent());
						return name;
					}
				});
    	choose1Column.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Question, String>, ObservableValue<String>>() {
					@Override
					public ObservableValue<String> call(CellDataFeatures<Question, String> param) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty(param.getValue().getChoose1());
						return name;
					}
				});
    	choose2Column.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Question, String>, ObservableValue<String>>() {
					@Override
					public ObservableValue<String> call(CellDataFeatures<Question, String> param) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty(param.getValue().getChoose2());
						return name;
					}
				});
    	choose3Column.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Question, String>, ObservableValue<String>>() {
					@Override
					public ObservableValue<String> call(CellDataFeatures<Question, String> param) {
						// TODO Auto-generated method stub
						SimpleStringProperty name = new SimpleStringProperty(param.getValue().getChoose3());
						return name;
					}
				});
    	
    }
      
    
    public void setMoudelData(Moudel moudel) {
    	ObservableList<Question> questionList=FXCollections.observableArrayList(moudel.getQuestions());
    	label.setText(moudel.getName());
    	reflushQuestionTableView(questionList);
    }
	
    
	
}
